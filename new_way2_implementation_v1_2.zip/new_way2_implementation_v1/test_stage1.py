"""
Verification script for Stage 1: Geometry, Channel Model, and Baseline AirComp MSE.
Replication of:
"Federated learning via over-the-air computation in IRS-assisted UAV communications"
(Scientific Reports, 2023)
"""

import sys
import numpy as np

from config import (
    SystemConfig,
    generate_user_locations,
    generate_straight_line_trajectory,
)
from channel_model import (
    compute_d_UnI,
    compute_d_IB,
    compute_path_loss,
    compute_ula_steering_vectors,
    generate_rician_fading,
    compute_decomposed_channel,
    compute_cascaded_channel,
    compute_aircomp_mse,
    compute_optimal_eta,
    compute_optimal_beta,
)


def run_verification():
    print("=" * 80)
    print("STAGE 1 VERIFICATION: SYSTEM GEOMETRY & CHANNEL MODEL")
    print("=" * 80)

    # 1. Configuration & Parameter Validation
    cfg = SystemConfig()
    print("\n--- 1. CONFIGURATION PARAMETERS ---")
    print(f"Base Station (BS): pos = {cfg.bs_pos}, height h_B = {cfg.h_B} m")
    print(f"UAV Altitude: h_I = {cfg.h_I} m")
    print(f"UAV Trajectory: q_0 = {cfg.q_0}, q_F = {cfg.q_F}")
    print(f"Time: delta = {cfg.delta} s, T = {cfg.T} s -> M = {cfg.M} slots")
    print(f"Max UAV Speed: V_max = {cfg.V_max} m/s (Max step = {cfg.max_displacement:.2f} m)")
    print(f"Channel Power Gain h_0: {cfg.h_0_dB} dB -> {cfg.h_0:.2e}")
    print(f"Noise Power sigma^2: {cfg.sigma2_dBm} dBm -> {cfg.sigma2:.2e} W")
    print(f"Max Transmit Power p_max: {cfg.p_max} W (10 dBm)")
    print(f"Number of Users N: {cfg.N}, IRS Elements K: {cfg.K}")
    print(f"Rician Factor kappa: {cfg.kappa} (10 dB)")
    print(f"Learning Rate zeta: {cfg.zeta}")
    print(f"IRS Gain Scale: {cfg.irs_gain_scale}")

    assert cfg.M == 300, f"Expected M=300 slots, got {cfg.M}"
    assert np.isclose(cfg.h_0, 1e-4), f"Expected h_0=1e-4, got {cfg.h_0}"
    assert np.isclose(cfg.sigma2, 1e-14), f"Expected sigma2=1e-14, got {cfg.sigma2}"
    assert cfg.max_displacement == 6.0, f"Expected max displacement 6.0 m, got {cfg.max_displacement}"

    # 2. Geometry & User Distribution
    print("\n--- 2. SYSTEM GEOMETRY & USER POSITIONS ---")
    users = generate_user_locations(cfg)
    print(f"Generated {users.shape[0]} ground users with seed {cfg.user_seed}.")
    print(f"User positions shape: {users.shape}")
    dist_from_center = np.linalg.norm(users - cfg.user_center, axis=1)
    print(f"User distances from center ({cfg.user_center}): min={dist_from_center.min():.2f} m, max={dist_from_center.max():.2f} m")
    assert users.shape == (cfg.N, 2), f"Expected user shape ({cfg.N}, 2), got {users.shape}"
    assert np.all(dist_from_center <= cfg.user_radius + 1e-9), "User exceeds circular radius!"

    # 3. UAV Trajectory
    print("\n--- 3. UAV TRAJECTORY ---")
    q_traj = generate_straight_line_trajectory(cfg)
    print(f"Straight-line trajectory shape: {q_traj.shape}")
    assert q_traj.shape == (cfg.M, 2), f"Expected q shape ({cfg.M}, 2), got {q_traj.shape}"
    assert np.allclose(q_traj[0], cfg.q_0), f"q[0] should be {cfg.q_0}"
    assert np.allclose(q_traj[-1], cfg.q_F), f"q[M-1] should be {cfg.q_F}"

    disp_per_slot = np.linalg.norm(q_traj[1:] - q_traj[:-1], axis=1)
    max_disp = np.max(disp_per_slot)
    print(f"Trajectory max displacement per slot: {max_disp:.4f} m (Allowed: {cfg.max_displacement:.4f} m)")
    assert max_disp <= cfg.max_displacement + 1e-9, "UAV speed constraint violated!"

    # 4. 3D Distances (Eq. 1 & Eq. 2)
    print("\n--- 4. 3D DISTANCES (Eq. 1 & Eq. 2) ---")
    d_UnI = compute_d_UnI(q_traj, users, cfg.h_I)
    d_IB = compute_d_IB(q_traj, cfg.h_I, cfg.h_B)
    print(f"d_UnI shape: {d_UnI.shape} (N={cfg.N}, M={cfg.M})")
    print(f"d_UnI range: [{d_UnI.min():.2f} m, {d_UnI.max():.2f} m]")
    print(f"d_IB shape: {d_IB.shape} (M={cfg.M})")
    print(f"d_IB range: [{d_IB.min():.2f} m, {d_IB.max():.2f} m]")

    assert d_UnI.shape == (cfg.N, cfg.M), f"Unexpected d_UnI shape {d_UnI.shape}"
    assert d_IB.shape == (cfg.M,), f"Unexpected d_IB shape {d_IB.shape}"
    assert np.all(d_UnI >= cfg.h_I), f"d_UnI must be >= h_I ({cfg.h_I})"
    assert np.all(d_IB >= (cfg.h_I - cfg.h_B)), f"d_IB must be >= h_I - h_B ({cfg.h_I - cfg.h_B})"
    assert not np.any(np.isnan(d_UnI)), "NaN found in d_UnI!"
    assert not np.any(np.isnan(d_IB)), "NaN found in d_IB!"

    # 5. Steering Vectors & Fading
    print("\n--- 5. ULA STEERING VECTORS & RICIAN FADING ---")
    a_IB, a_UnI = compute_ula_steering_vectors(q_traj, users, cfg.h_I, cfg.h_B, cfg.K)
    print(f"a_IB shape: {a_IB.shape}, a_UnI shape: {a_UnI.shape}")
    assert np.allclose(np.abs(a_IB), 1.0), "LoS steering vector elements must have unit modulus!"
    assert np.allclose(np.abs(a_UnI), 1.0), "LoS steering vector elements must have unit modulus!"

    h_IB_tilde, h_UnI_tilde = generate_rician_fading(q_traj, users, cfg, seed=123)
    print(f"h_IB_tilde shape: {h_IB_tilde.shape}, h_UnI_tilde shape: {h_UnI_tilde.shape}")
    print(f"Mean power |h_IB_tilde|^2: {np.mean(np.abs(h_IB_tilde)**2):.4f} (Theoretical ~ 1.0)")
    print(f"Mean power |h_UnI_tilde|^2: {np.mean(np.abs(h_UnI_tilde)**2):.4f} (Theoretical ~ 1.0)")
    assert h_IB_tilde.shape == (cfg.M, cfg.K)
    assert h_UnI_tilde.shape == (cfg.N, cfg.M, cfg.K)

    # 6. Decomposed Channel Vector mu_tilde (Eq. 4, Eq. 12)
    print("\n--- 6. DECOMPOSED CHANNEL VECTOR mu_tilde ---")
    mu_tilde = compute_decomposed_channel(h_IB_tilde, h_UnI_tilde, normalize_elements=True)
    print(f"mu_tilde shape: {mu_tilde.shape} (N={cfg.N}, M={cfg.M}, K={cfg.K})")
    assert mu_tilde.shape == (cfg.N, cfg.M, cfg.K)
    assert np.allclose(np.abs(mu_tilde), 1.0, atol=1e-10), "All elements of mu_tilde must have unit modulus!"
    print(f"Unit modulus test passed: max error from 1.0 = {np.max(np.abs(np.abs(mu_tilde) - 1.0)):.2e}")

    # Verify Coherent Array Gain
    # If beta matches user 0 at slot m: beta[m] = exp(j * arg(mu_tilde[0, m]))
    # then mu_tilde[0, m]^H @ beta[m] = sum_k 1.0 = K
    beta_coherent_user0 = np.exp(1j * np.angle(mu_tilde[0]))  # shape (M, K)
    coherent_gain = np.sum(np.conj(mu_tilde[0]) * beta_coherent_user0, axis=-1)  # shape (M,)
    print(f"Coherent array gain for matched single user: {np.real(coherent_gain[0]):.4f} (Expected exactly K={cfg.K})")
    assert np.allclose(coherent_gain, cfg.K), f"Coherent gain should equal K={cfg.K}"

    # 7. Cascaded Channel under Different Phase Shift Designs (Legacy Benchmarks)
    # NOTE: compute_optimal_beta produces slot-dependent phases of shape (M, K)
    # as defined in the original paper formulation for per-slot benchmarking.
    # The audited production architecture enforces a single common phase vector
    # of shape (K,) across all mission slots.
    print("\n--- 7. CASCADED CHANNEL GAINS (LEGACY PER-SLOT BENCHMARKS) ---")
    # A. Legacy per-slot closed-form phase vector beta* (Eq. 15)
    beta_opt = compute_optimal_beta(mu_tilde)
    print(f"beta_opt shape: {beta_opt.shape}, all unit modulus: {np.allclose(np.abs(beta_opt), 1.0)}")
    h_opt, h_opt_mag = compute_cascaded_channel(q_traj, users, beta_opt, cfg, mu_tilde=mu_tilde)
    print(f"Cascaded channel |h_n| with beta* (optimal): min={h_opt_mag.min():.4e}, max={h_opt_mag.max():.4e}, mean={h_opt_mag.mean():.4e}")

    # B. Random phase baseline
    rng = np.random.default_rng(42)
    random_theta = rng.uniform(0, 2 * np.pi, (cfg.M, cfg.K))
    beta_random = np.exp(1j * random_theta)
    h_rand, h_rand_mag = compute_cascaded_channel(q_traj, users, beta_random, cfg, mu_tilde=mu_tilde)
    print(f"Cascaded channel |h_n| with random phase: min={h_rand_mag.min():.4e}, max={h_rand_mag.max():.4e}, mean={h_rand_mag.mean():.4e}")

    ratio_opt_to_rand = np.mean(h_opt_mag) / np.mean(h_rand_mag)
    print(f"Average channel gain improvement from optimized phase: {ratio_opt_to_rand:.2f}x")
    assert ratio_opt_to_rand > 2.0, "Optimized phase must significantly outperform random phase!"

    # 8. AirComp Mean Squared Error (Eq. 9) & Worst-Case MSE
    print("\n--- 8. AIRCOMP MSE EVALUATION (Eq. 9) ---")
    p_full = np.full((cfg.N, cfg.M), cfg.p_max)  # Transmit at p_max

    # Optimal denoising factor eta*[m]
    eta_opt = compute_optimal_eta(p_full, h_opt_mag, cfg.sigma2)
    print(f"eta_opt shape: {eta_opt.shape}, range: [{eta_opt.min():.4e}, {eta_opt.max():.4e}]")
    assert eta_opt.shape == (cfg.M,)
    assert np.all(eta_opt > 0), "eta must be strictly positive!"

    mse_m_opt, worst_mse_opt = compute_aircomp_mse(p_full, h_opt_mag, eta_opt, cfg.sigma2, cfg.N)
    print(f"Optimal Phase: worst-case MSE = {worst_mse_opt:.6e}, min MSE = {mse_m_opt.min():.6e}, mean MSE = {mse_m_opt.mean():.6e}")

    # Compare with random phase
    eta_rand = compute_optimal_eta(p_full, h_rand_mag, cfg.sigma2)
    mse_m_rand, worst_mse_rand = compute_aircomp_mse(p_full, h_rand_mag, eta_rand, cfg.sigma2, cfg.N)
    print(f"Random Phase:  worst-case MSE = {worst_mse_rand:.6e}, min MSE = {mse_m_rand.min():.6e}, mean MSE = {mse_m_rand.mean():.6e}")

    assert worst_mse_opt < worst_mse_rand, "Optimized phase must yield lower worst-case MSE than random phase!"
    assert not np.isnan(worst_mse_opt) and not np.isinf(worst_mse_opt), "NaN or Inf in MSE!"
    assert not np.isnan(worst_mse_rand) and not np.isinf(worst_mse_rand), "NaN or Inf in MSE!"

    print("\n" + "=" * 80)
    print("ALL STAGE 1 VERIFICATIONS PASSED SUCCESSFULLY!")
    print("=" * 80)
    return True


if __name__ == "__main__":
    success = run_verification()
    sys.exit(0 if success else 1)
