"""
Channel model module for IRS-assisted UAV Federated Learning via Over-the-Air Computation.
Replication of:
"Federated learning via over-the-air computation in IRS-assisted UAV communications"
(Scientific Reports, 2023)

Implements:
- 3D distance calculations (Eq. 1 & Eq. 2)
- Large-scale path loss model (Eq. 4)
- Uniform Linear Array (ULA) steering vectors and Rician small-scale fading
- Decomposed cascaded channel vector mu_n[n, m] (Eq. 4, Eq. 12)
- Cascaded channel with IRS phase shift vector beta[m] (Eq. 4)
- AirComp Mean Squared Error (MSE) calculation (Eq. 9)
- Optimal closed-form phase shift beta* (Eq. 15)
- Optimal denoising factor eta* (Eq. 17)
"""

from typing import Optional, Tuple
import numpy as np

from config import SystemConfig


def compute_d_UnI(q: np.ndarray, r: np.ndarray, h_I: float) -> np.ndarray:
    """
    Compute 3D distance between ground users (Un) and IRS-UAV (Eq. 1).

    d_UnI[n, m] = sqrt(||q[m] - r_n||^2 + h_I^2)

    Parameters
    ----------
    q : np.ndarray
        UAV horizontal coordinates of shape (M, 2) or (2,).
    r : np.ndarray
        User horizontal coordinates of shape (N, 2) or (2,).
    h_I : float
        UAV flight altitude in meters.

    Returns
    -------
    np.ndarray
        Distance array of shape (N, M) if 2D inputs, or corresponding squeezed shape.
    """
    q_arr = np.atleast_2d(q)  # shape (M, 2)
    r_arr = np.atleast_2d(r)  # shape (N, 2)

    # Difference vectors: shape (N, M, 2)
    diff = r_arr[:, None, :] - q_arr[None, :, :]
    dist_sq = np.sum(diff ** 2, axis=-1) + (h_I ** 2)
    d = np.sqrt(dist_sq)

    if q.ndim == 1 and r.ndim == 1:
        return float(d[0, 0])
    if q.ndim == 1:
        return d[:, 0]
    if r.ndim == 1:
        return d[0, :]
    return d


def compute_d_IB(q: np.ndarray, h_I: float, h_B: float) -> np.ndarray:
    """
    Compute 3D distance between IRS-UAV and Base Station (BS) (Eq. 2).

    d_IB[m] = sqrt(||q[m]||^2 + (h_I - h_B)^2)

    Parameters
    ----------
    q : np.ndarray
        UAV horizontal coordinates of shape (M, 2) or (2,).
    h_I : float
        UAV flight altitude in meters.
    h_B : float
        Base Station antenna height in meters.

    Returns
    -------
    np.ndarray or float
        Distance array of shape (M,) or float if single coordinate.
    """
    q_arr = np.atleast_2d(q)  # shape (M, 2)
    dist_sq = np.sum(q_arr ** 2, axis=-1) + ((h_I - h_B) ** 2)
    d = np.sqrt(dist_sq)

    if q.ndim == 1:
        return float(d[0])
    return d


def compute_path_loss(
    d_UnI: np.ndarray,
    d_IB: np.ndarray,
    h_0: float,
    alpha: float = 2.0
) -> np.ndarray:
    """
    Compute large-scale cascaded path loss factor (amplitude) from Eq. 4:

    PL_amp[n, m] = sqrt(h_0) / ((d_UnI[n, m] * d_IB[m]) ** (alpha / 2))

    Parameters
    ----------
    d_UnI : np.ndarray
        User-to-IRS distance array of shape (N, M).
    d_IB : np.ndarray
        IRS-to-BS distance array of shape (M,).
    h_0 : float
        Reference channel power gain at d0 = 1 m.
    alpha : float, optional
        Path loss exponent, default 2.0.

    Returns
    -------
    np.ndarray
        Path loss amplitude factor of shape (N, M).
    """
    # Product of distances: shape (N, M)
    prod = d_UnI * d_IB[None, :]
    return np.sqrt(h_0) / (prod ** (alpha / 2.0))


def compute_ula_steering_vectors(
    q: np.ndarray,
    r: np.ndarray,
    h_I: float,
    h_B: float,
    K: int
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute LoS ULA steering vectors for IRS-to-BS and User-to-IRS links.
    Elements have half-wavelength spacing (d_elem / lambda = 0.5) along the x-axis.

    Parameters
    ----------
    q : np.ndarray
        UAV positions of shape (M, 2).
    r : np.ndarray
        User positions of shape (N, 2).
    h_I : float
        UAV flight altitude in meters.
    h_B : float
        Base station height in meters.
    K : int
        Number of IRS elements.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        a_IB : shape (M, K), steering vector for IRS -> BS
        a_UnI : shape (N, M, K), steering vector for User n -> IRS
    """
    M = q.shape[0]
    N = r.shape[0]
    k_indices = np.arange(K)

    # Distances
    d_IB = compute_d_IB(q, h_I, h_B)  # shape (M,)
    d_UnI = compute_d_UnI(q, r, h_I)  # shape (N, M)

    # Direction cosine with respect to array along x-axis:
    # Vector from IRS to BS: (-q_x, -q_y, h_B - h_I)
    cos_theta_IB = -q[:, 0] / d_IB  # shape (M,)
    # a_IB[m, k] = exp(j * pi * k * cos_theta_IB[m])
    phase_IB = np.pi * cos_theta_IB[:, None] * k_indices[None, :]  # (M, K)
    a_IB = np.exp(1j * phase_IB)

    # Vector from IRS to User n: (r_nx - q_x, r_ny - q_y, 0 - h_I)
    # Direction cosine along x-axis: (r_nx - q_x) / d_UnI
    cos_theta_UnI = (r[:, None, 0] - q[None, :, 0]) / d_UnI  # (N, M)
    # a_UnI[n, m, k] = exp(j * pi * k * cos_theta_UnI[n, m])
    phase_UnI = np.pi * cos_theta_UnI[:, :, None] * k_indices[None, None, :]  # (N, M, K)
    a_UnI = np.exp(1j * phase_UnI)

    return a_IB, a_UnI


def generate_rician_fading(
    q: np.ndarray,
    r: np.ndarray,
    config: SystemConfig,
    seed: Optional[int] = None
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Generate small-scale Rician fading vectors h_IB_tilde and h_UnI_tilde.

    h_tilde = sqrt(kappa / (kappa + 1)) * a_LoS + sqrt(1 / (kappa + 1)) * g_NLoS
    where g_NLoS ~ CN(0, I).

    Parameters
    ----------
    q : np.ndarray
        UAV positions of shape (M, 2).
    r : np.ndarray
        User positions of shape (N, 2).
    config : SystemConfig
        System configuration.
    seed : int, optional
        Random seed for reproducibility.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        h_IB_tilde : shape (M, K), small-scale fading vector from IRS to BS
        h_UnI_tilde : shape (N, M, K), small-scale fading vector from User n to IRS
    """
    M = q.shape[0]
    N = r.shape[0]
    K = config.K
    kappa = config.kappa

    a_IB, a_UnI = compute_ula_steering_vectors(q, r, config.h_I, config.h_B, K)

    rng = np.random.default_rng(seed)

    # Complex Gaussian NLoS components ~ CN(0, 1)
    g_IB_nlos = (rng.standard_normal((M, K)) + 1j * rng.standard_normal((M, K))) / np.sqrt(2.0)
    g_UnI_nlos = (rng.standard_normal((N, M, K)) + 1j * rng.standard_normal((N, M, K))) / np.sqrt(2.0)

    # Blend LoS and NLoS with Rician factor kappa
    los_weight = np.sqrt(kappa / (kappa + 1.0))
    nlos_weight = np.sqrt(1.0 / (kappa + 1.0))

    h_IB_tilde = los_weight * a_IB + nlos_weight * g_IB_nlos
    h_UnI_tilde = los_weight * a_UnI + nlos_weight * g_UnI_nlos

    return h_IB_tilde, h_UnI_tilde


def compute_decomposed_channel(
    h_IB_tilde: np.ndarray,
    h_UnI_tilde: np.ndarray,
    normalize_elements: bool = True
) -> np.ndarray:
    """
    Compute decomposed channel vector mu_n[n, m] (shape N, M, K).

    According to the paper Eq. 12:
    h_IB[m] @ Theta @ h_UnI[n, m] = mu_n[n, m]^H @ beta[m]
    where Theta = diag(beta[m]), beta[m] = [e^(j*theta_1), ..., e^(j*theta_K)]^T.

    Since:
    sum_k h_IB,k * beta_k * h_UnI,k = sum_k (h_IB,k * h_UnI,k) * beta_k
                                    = sum_k mu_n,k^* * beta_k
    we have:
    mu_n,k = (h_IB,k * h_UnI,k)^* = h_IB,k^* * h_UnI,k^*

    If normalize_elements is True:
    mu_tilde_n[n, m, k] = mu_n[n, m, k] / |mu_n[n, m, k]|
    such that |mu_tilde_n[n, m, k]| = 1, ensuring coherent phase alignment
    yields an IRS array gain of K.

    Parameters
    ----------
    h_IB_tilde : np.ndarray
        IRS-to-BS small-scale fading, shape (M, K).
    h_UnI_tilde : np.ndarray
        User-to-IRS small-scale fading, shape (N, M, K).
    normalize_elements : bool, optional
        Whether each element has unit modulus |mu_tilde| = 1. Default True.

    Returns
    -------
    np.ndarray
        mu_tilde_n of shape (N, M, K).
    """
    # h_IB_tilde is (M, K) -> broadcast to (1, M, K)
    # mu_raw[n, m, k] = conj(h_IB_tilde[m, k] * h_UnI_tilde[n, m, k])
    mu_raw = np.conj(h_IB_tilde[None, :, :] * h_UnI_tilde)  # (N, M, K)

    if normalize_elements:
        mod = np.abs(mu_raw)
        mod = np.where(mod < 1e-12, 1.0, mod)
        return mu_raw / mod

    return mu_raw


def compute_cascaded_channel(
    q: np.ndarray,
    r: np.ndarray,
    beta: np.ndarray,
    config: SystemConfig,
    mu_tilde: Optional[np.ndarray] = None,
    seed: Optional[int] = None
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute the cascaded channel h_n[n, m] and magnitude |h_n[n, m]| (Eq. 4).

    h_n[n, m] = (sqrt(h_0) / ((d_UnI[n, m] * d_IB[m]) ** (alpha / 2)))
                * irs_gain_scale * (mu_tilde_n[n, m]^H @ beta[m])

    Parameters
    ----------
    q : np.ndarray
        UAV positions of shape (M, 2).
    r : np.ndarray
        User positions of shape (N, 2).
    beta : np.ndarray
        IRS reflection phase vector of canonical shape (K,) (common phase)
        or shape (M, K) (slot-dependent). |beta_k| = 1.
    config : SystemConfig
        System configuration.
    mu_tilde : np.ndarray, optional
        Precomputed decomposed channel of shape (N, M, K). If None, generated.
    seed : int, optional
        Seed for Rician fading generation if mu_tilde is None.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        h_n : shape (N, M), complex cascaded channel
        h_mag : shape (N, M), magnitude |h_n|
    """
    if q.ndim != 2 or q.shape[1] != 2:
        raise ValueError(f"UAV position q must have shape (M, 2), got {q.shape}")
    if r.ndim != 2 or r.shape[1] != 2:
        raise ValueError(f"User positions r must have shape (N, 2), got {r.shape}")

    M = q.shape[0]
    N = r.shape[0]
    K = config.K

    # Validate beta shape and unit modulus
    if beta.ndim == 1:
        if beta.shape[0] != K:
            raise ValueError(f"Common beta must have shape ({K},), got {beta.shape}")
        if not np.allclose(np.abs(beta), 1.0, atol=1e-5):
            raise ValueError("All elements of beta must satisfy unit modulus |beta_k| = 1")
        # Direct broadcast: (N, M, K) * (1, 1, K) -> (N, M, K)
        beta_factor = beta[None, None, :]
    elif beta.ndim == 2:
        if beta.shape != (M, K):
            raise ValueError(f"Slot-dependent beta must have shape ({M}, {K}), got {beta.shape}")
        if not np.allclose(np.abs(beta), 1.0, atol=1e-5):
            raise ValueError("All elements of beta must satisfy unit modulus |beta_k| = 1")
        beta_factor = beta[None, :, :]
    else:
        raise ValueError(f"beta must have dimension 1 (K,) or 2 (M, K), got dimension {beta.ndim}")

    d_IB = compute_d_IB(q, config.h_I, config.h_B)  # (M,)
    d_UnI = compute_d_UnI(q, r, config.h_I)          # (N, M)
    path_loss = compute_path_loss(d_UnI, d_IB, config.h_0, config.alpha)  # (N, M)

    if mu_tilde is None:
        h_IB_tilde, h_UnI_tilde = generate_rician_fading(q, r, config, seed=seed)
        mu_tilde = compute_decomposed_channel(h_IB_tilde, h_UnI_tilde, normalize_elements=True)

    if mu_tilde.shape != (N, M, K):
        raise ValueError(f"mu_tilde must have shape ({N}, {M}, {K}), got {mu_tilde.shape}")

    # Inner product: mu_tilde_n[n, m]^H @ beta
    # sum_k conj(mu_tilde_n[n, m, k]) * beta_k
    inner_prod = np.sum(np.conj(mu_tilde) * beta_factor, axis=2)  # shape (N, M)

    h_n = path_loss * config.irs_gain_scale * inner_prod
    h_mag = np.abs(h_n)

    return h_n, h_mag


def compute_aircomp_mse(
    p: np.ndarray,
    h_mag: np.ndarray,
    eta: np.ndarray,
    sigma2: float,
    N: int
) -> Tuple[np.ndarray, float]:
    """
    Compute AirComp Mean Squared Error (MSE) from Eq. 9:

    MSE[m] = (1 / N^2) * ( sum_{n=1}^N ( (sqrt(p_n[m]) * |h_n[m]| / sqrt(eta[m])) - 1 )^2
                           + (sigma2 / eta[m]) )

    Parameters
    ----------
    p : np.ndarray
        Transmit power array of shape (N, M).
    h_mag : np.ndarray
        Cascaded channel magnitude |h_n[n, m]| of shape (N, M).
    eta : np.ndarray
        Denoising factor array of shape (M,) or float.
    sigma2 : float
        Noise power in Watts.
    N : int
        Number of users.

    Returns
    -------
    Tuple[np.ndarray, float]
        mse_m : shape (M,), MSE for each time slot m
        worst_mse : float, max_m MSE[m]
    """
    eta_arr = np.atleast_1d(eta)
    sqrt_eta = np.sqrt(eta_arr)

    # Distortion term: (sqrt(p_n[m]) * |h_n[m]| / sqrt(eta[m]) - 1)^2
    signal_ratio = (np.sqrt(p) * h_mag) / sqrt_eta[None, :]
    distortion_sum = np.sum((signal_ratio - 1.0) ** 2, axis=0)  # (M,)

    # Noise term: sigma2 / eta[m]
    noise_term = sigma2 / eta_arr  # (M,)

    mse_m = (1.0 / (N ** 2)) * (distortion_sum + noise_term)
    worst_mse = float(np.max(mse_m))

    return mse_m, worst_mse


def compute_optimal_eta(
    p: np.ndarray,
    h_mag: np.ndarray,
    sigma2: float
) -> np.ndarray:
    """
    Compute the exact optimal denoising factor eta[m] for fixed p and |h_n| (Eq. 17).

    Minimizing MSE[m] with respect to gamma = 1 / sqrt(eta):
    d/d(gamma) [ sum_n (gamma * sqrt(p_n) * |h_n| - 1)^2 + sigma2 * gamma^2 ] = 0
    => gamma*[m] = sum_n (sqrt(p_n) * |h_n|) / ( sum_n (p_n * |h_n|^2) + sigma2 )
    => eta*[m] = 1 / (gamma*[m])^2

    Parameters
    ----------
    p : np.ndarray
        Transmit power of shape (N, M).
    h_mag : np.ndarray
        Channel magnitudes of shape (N, M).
    sigma2 : float
        Noise power in Watts.

    Returns
    -------
    np.ndarray
        Optimal eta of shape (M,).
    """
    term1 = np.sum(np.sqrt(p) * h_mag, axis=0)  # (M,)
    term2 = np.sum(p * (h_mag ** 2), axis=0) + sigma2  # (M,)
    gamma_opt = term1 / term2
    eta_opt = 1.0 / (gamma_opt ** 2)
    return eta_opt


def compute_optimal_beta(
    mu_tilde: np.ndarray,
    p: Optional[np.ndarray] = None,
    eta: Optional[np.ndarray] = None
) -> np.ndarray:
    """
    Compute the closed-form optimal IRS phase shift vector beta*[m] (Eq. 15).

    xi[m] = sum_{n=1}^N sqrt(p_n[m] / eta[m]) * mu_tilde_n[n, m]
    beta*[m] = [e^(j * arg(xi_1[m])), ..., e^(j * arg(xi_K[m]))]^T

    Parameters
    ----------
    mu_tilde : np.ndarray
        Decomposed channel vector of shape (N, M, K).
    p : np.ndarray, optional
        Transmit power of shape (N, M). If None, equal power assumed.
    eta : np.ndarray, optional
        Denoising factor of shape (M,). If None, equal weight assumed.

    Returns
    -------
    np.ndarray
        Optimal beta of shape (M, K) with unit modulus |beta_{m, k}| = 1.
    """
    N, M, K = mu_tilde.shape

    if p is not None and eta is not None:
        weights = np.sqrt(p / eta[None, :])  # shape (N, M)
        weighted_mu = weights[:, :, None] * mu_tilde  # shape (N, M, K)
        xi = np.sum(weighted_mu, axis=0)  # shape (M, K)
    else:
        # Uniform weighting (e.g. initial phase alignment)
        xi = np.sum(mu_tilde, axis=0)  # shape (M, K)

    # beta*[m, k] = exp(j * angle(xi[m, k]))
    beta_opt = np.exp(1j * np.angle(xi))
    return beta_opt
