"""
Optimization sub-problems for IRS-assisted UAV Federated Learning via AirComp.
Replication of Algorithm 2 from:
"Federated learning via over-the-air computation in IRS-assisted UAV communications"
(Scientific Reports, 2023)

Implements:
1. Sub-problem 1: IRS Phase Shift Optimization (Eqs. 11-15)
   - Proposed closed-form solution: beta*[m] = exp(j * arg(xi[m])) (Eq. 15)
   - Benchmark: Random phase shifts in [0, 2*pi) (Figs. 3 & 4)
   - Benchmark: Semi-Definite Relaxation (SDR) with Gaussian randomization (Figs. 3 & 4)
2. Sub-problem 2: Denoising Factor Optimization eta[m] (Eqs. 16-18)
   - Exact analytical solution (Eq. 17)
   - CVXPY QCQP formulation with epigraph variable chi (Eq. 18)
3. Sub-problem 3: User Transmit Power Optimization p_n[m] (Eqs. 19-20)
   - Exact analytical truncated channel inversion
   - CVXPY QCQP formulation parameterized by s_n[m] = sqrt(p_n[m]) (Eq. 20)
"""

from typing import Optional, Tuple, Union, Sequence, Dict, Any
import numpy as np
import cvxpy as cp

from config import SystemConfig
from channel_model import compute_cascaded_channel, compute_aircomp_mse, compute_optimal_eta


# ==============================================================================
# SUB-PROBLEM 1: IRS Phase Shift Optimization (Eqs. 11-15 & Common Phase Architecture)
# ==============================================================================

def generate_common_phase_candidate(
    p: np.ndarray,
    eta: np.ndarray,
    mu: np.ndarray,
    mse_per_slot: np.ndarray,
    prev_beta: Optional[np.ndarray] = None
) -> Tuple[np.ndarray, int]:
    """
    Generate a common (slot-independent) IRS phase vector candidate of shape (K,).

    Paper Inconsistency Resolution (Part B1 & B2):
    The paper's formal problem formulation (Eqs. 10-12) specifies a single common
    IRS phase vector beta across all slots. However, the closed-form update
    in Eq. (15) relies on xi[m], retaining an unaggregated slot index m.
    
    To resolve this without inventing arbitrary heuristic slot combinations:
    1. Identify the worst-MSE slot under the current profile:
       m* = argmax_m MSE[m].
    2. Form the Eq. (15)-style phase alignment vector at slot m*:
       xi[m*] = sum_{n=1}^N sqrt(p_n[m*] / eta[m*]) * mu_n[n, m*].
    3. Generate the candidate:
       beta_k^cand = exp(j * arg(xi_k[m*])).
    
    IMPORTANT NOTE:
    This candidate is a heuristic alignment candidate for the minimax common-phase
    problem. It is NOT a proven exact minimizer of the common-phase minimax subproblem.
    Its global worst-slot performance is safeguarded by the profile acceptance test.

    Parameters
    ----------
    p : np.ndarray
        User transmit power of shape (N, M).
    eta : np.ndarray
        Denoising factor of shape (M,).
    mu : np.ndarray
        Effective decomposed cascaded channel of shape (N, M, K).
    mse_per_slot : np.ndarray
        Current exact MSE for each time slot m, shape (M,).
    prev_beta : np.ndarray, optional
        Previous common phase vector of shape (K,). Used as fallback for
        near-zero components of xi.

    Returns
    -------
    Tuple[np.ndarray, int]
        beta_cand : shape (K,), candidate common phase vector with |beta_k| = 1.
        m_star : int, slot index where worst MSE occurred and alignment was evaluated.
    """
    N, M, K = mu.shape
    if p.shape != (N, M):
        raise ValueError(f"p shape must be ({N}, {M}), got {p.shape}")
    if eta.shape != (M,):
        raise ValueError(f"eta shape must be ({M},), got {eta.shape}")
    if mse_per_slot.shape != (M,):
        raise ValueError(f"mse_per_slot shape must be ({M},), got {mse_per_slot.shape}")

    # 1. Select worst-MSE slot m*
    m_star = int(np.argmax(mse_per_slot))

    # 2. Form xi at slot m*
    sqrt_eta_m = np.sqrt(max(1e-18, float(eta[m_star])))
    weights = np.sqrt(p[:, m_star]) / sqrt_eta_m  # shape (N,)
    xi_m = np.sum(weights[:, None] * mu[:, m_star, :], axis=0)  # shape (K,)

    # 3. Handle near-zero components safely
    abs_xi = np.abs(xi_m)
    beta_cand = np.zeros(K, dtype=complex)
    valid_mask = abs_xi >= 1e-12

    beta_cand[valid_mask] = np.exp(1j * np.angle(xi_m[valid_mask]))

    if np.any(~valid_mask):
        if prev_beta is not None and prev_beta.shape == (K,):
            beta_cand[~valid_mask] = prev_beta[~valid_mask]
        else:
            beta_cand[~valid_mask] = 1.0 + 0j

    # Ensure exact unit modulus
    beta_cand = beta_cand / np.abs(beta_cand)

    assert beta_cand.shape == (K,), f"beta_cand shape must be ({K},), got {beta_cand.shape}"
    assert np.allclose(np.abs(beta_cand), 1.0, atol=1e-5), "Unit modulus violated in beta_cand"

    return beta_cand, m_star


def optimize_phase_common_with_profile_safeguard(
    beta_curr: np.ndarray,
    p: np.ndarray,
    q: np.ndarray,
    users: np.ndarray,
    config: SystemConfig,
    mu_tilde: np.ndarray,
    mse_per_slot: np.ndarray,
    tol: float = 1e-9
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    """
    Sub-problem 1 (Corrected): Common-Phase IRS Optimization with Profile Safeguard (Part D2).

    1. Generates candidate common phase beta^cand of shape (K,) using worst slot m*.
    2. Evaluates exact profile objective F*(beta) = max_m MSE_m(beta, eta*(beta), p, q)
       for both candidate and current phase vectors.
    3. Accepts candidate only if F*(beta^cand) <= F*(beta_curr) + tol.
    4. Updates eta to exact optimal eta*(beta_accepted).

    Parameters
    ----------
    beta_curr : np.ndarray
        Current common phase vector of shape (K,).
    p : np.ndarray
        User transmit power of shape (N, M).
    q : np.ndarray
        UAV trajectory of shape (M, 2).
    users : np.ndarray
        User positions of shape (N, 2).
    config : SystemConfig
        System parameters.
    mu_tilde : np.ndarray
        Decomposed channel of shape (N, M, K).
    mse_per_slot : np.ndarray
        Current per-slot MSE array of shape (M,).
    tol : float, optional
        Numerical tolerance for profile acceptance test. Default 1e-9.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray, Dict[str, Any]]
        beta_next : shape (K,), accepted or retained common phase vector
        eta_next : shape (M,), optimal denoising factors for beta_next
        diag : Dict[str, Any], diagnostics of the profile test
    """
    N, M = p.shape
    K = config.K

    if beta_curr.shape != (K,):
        raise ValueError(f"beta_curr must have shape ({K},), got {beta_curr.shape}")

    # Compute effective channel for candidate generation
    d_IB = np.sqrt(np.sum(q ** 2, axis=-1) + (config.h_I - config.h_B) ** 2)  # (M,)
    diff_u = users[:, None, :] - q[None, :, :]  # (N, M, 2)
    d_UnI = np.sqrt(np.sum(diff_u ** 2, axis=-1) + (config.h_I ** 2))  # (N, M)
    prod = d_UnI * d_IB[None, :]  # (N, M)
    path_loss = np.sqrt(config.h_0) / (prod ** (config.alpha / 2.0))  # (N, M)
    mu_effective = path_loss[:, :, None] * mu_tilde  # (N, M, K)

    # Denoising factors at current state
    _, h_mag_curr = compute_cascaded_channel(q, users, beta_curr, config, mu_tilde=mu_tilde)
    eta_curr_opt = compute_optimal_eta(p, h_mag_curr, config.sigma2)
    _, F_curr = compute_aircomp_mse(p, h_mag_curr, eta_curr_opt, config.sigma2, N)

    # 1. Generate candidate common phase
    beta_cand, m_star = generate_common_phase_candidate(
        p, eta_curr_opt, mu_effective, mse_per_slot, prev_beta=beta_curr
    )

    # 2. Evaluate candidate profile objective
    _, h_mag_cand = compute_cascaded_channel(q, users, beta_cand, config, mu_tilde=mu_tilde)
    eta_cand_opt = compute_optimal_eta(p, h_mag_cand, config.sigma2)
    _, F_cand = compute_aircomp_mse(p, h_mag_cand, eta_cand_opt, config.sigma2, N)

    # 3. Profile acceptance test
    accepted = bool(F_cand <= F_curr + tol)
    if accepted:
        beta_next = beta_cand
        eta_next = eta_cand_opt
        F_next = F_cand
        reason = f"Candidate accepted: profile worst MSE ({F_cand:.6e}) <= current ({F_curr:.6e})"
    else:
        beta_next = np.copy(beta_curr)
        eta_next = eta_curr_opt
        F_next = F_curr
        reason = f"Candidate rejected: candidate profile worst MSE ({F_cand:.6e}) > current ({F_curr:.6e})"

    diag = {
        "accepted": accepted,
        "m_star": m_star,
        "F_curr": float(F_curr),
        "F_cand": float(F_cand),
        "F_next": float(F_next),
        "reason": reason,
    }
    return beta_next, eta_next, diag


def optimize_phase_proposed(
    p: np.ndarray,
    eta: np.ndarray,
    mu: np.ndarray,
    q: Optional[np.ndarray] = None
) -> np.ndarray:
    """
    Sub-problem 1: Closed-form IRS Phase Shift Optimization (Eq. 15).
    NOTE: Evaluated per-slot. Kept for legacy benchmarks and comparisons.

    xi[m] = sum_{n=1}^N sqrt(p_n[m] / eta[m]) * mu_n[n, m]
    theta_k*[m] = arg(xi_k[m])
    beta*[m] = exp(j * theta*[m])

    Parameters
    ----------
    p : np.ndarray
        User transmit power of shape (N, M).
    eta : np.ndarray
        Denoising factor of shape (M,).
    mu : np.ndarray
        Decomposed cascaded channel of shape (N, M, K).
    q : np.ndarray, optional
        UAV horizontal positions of shape (M, 2), unused for phase calculation.

    Returns
    -------
    np.ndarray
        Optimal IRS reflection vector beta* of shape (M, K) with |beta_k| = 1.
    """
    N, M, K = mu.shape
    eta_arr = np.atleast_1d(eta)
    weights = np.sqrt(p / eta_arr[None, :])  # shape (N, M)

    # xi[m, k] = sum_n weights[n, m] * mu[n, m, k]
    xi = np.sum(weights[:, :, None] * mu, axis=0)  # shape (M, K)

    # Closed-form optimal phase (Eq. 15)
    beta_opt = np.exp(1j * np.angle(xi))
    return beta_opt


def optimize_phase_random(
    K: int,
    M: int,
    seed: Optional[int] = 42
) -> np.ndarray:
    """
    Benchmark Phase Method: Random IRS phase shifts in [0, 2*pi) (Figs. 3 & 4).

    Parameters
    ----------
    K : int
        Number of IRS reflecting elements.
    M : int
        Number of time slots.
    seed : int, optional
        Random seed for reproducibility.

    Returns
    -------
    np.ndarray
        Random phase vector beta_rand of shape (M, K) with |beta_k| = 1.
    """
    rng = np.random.default_rng(seed)
    theta_rand = rng.uniform(0.0, 2.0 * np.pi, size=(M, K))
    return np.exp(1j * theta_rand)


def optimize_phase_sdr(
    p: np.ndarray,
    eta: np.ndarray,
    mu: np.ndarray,
    num_rand: int = 20,
    seed: Optional[int] = 42,
    mode: str = "auto"
) -> np.ndarray:
    """
    Benchmark Phase Method: Semi-Definite Relaxation (SDR) with Gaussian randomization
    for the phase shift sub-problem (Eqs. 11-12) used in Figs. 3 and 4.

    Formulates the quadratic cost per slot m:
    min_{beta} beta^H Omega beta - 2 Re{beta^H xi} + N  s.t. |beta_k|^2 = 1.
    Lifts to (K+1) x (K+1) matrix M = [[Omega, -xi], [-xi^H, 0]] and solves
    the rank-1 relaxation followed by Gaussian randomization.

    Parameters
    ----------
    p : np.ndarray
        User transmit power of shape (N, M).
    eta : np.ndarray
        Denoising factor of shape (M,).
    mu : np.ndarray
        Decomposed cascaded channel of shape (N, M, K).
    num_rand : int, optional
        Number of Gaussian randomization candidates, default 20.
    seed : int, optional
        Random seed for Gaussian randomization.
    mode : str, optional
        'auto' or 'eigen' (fast principal eigenvector + randomization),
        or 'sdp' (solves CVXPY SDP using SCS). Default 'auto'.

    Returns
    -------
    np.ndarray
        SDR-optimized phase vector beta_sdr of shape (M, K) with |beta_k| = 1.
    """
    N, M, K = mu.shape
    eta_arr = np.atleast_1d(eta)
    weights = np.sqrt(p / eta_arr[None, :])  # shape (N, M)
    xi_all = np.sum(weights[:, :, None] * mu, axis=0)  # shape (M, K)

    rng = np.random.default_rng(seed)
    beta_sdr = np.zeros((M, K), dtype=complex)

    for m in range(M):
        w_m = weights[:, m]  # (N,)
        mu_m = mu[:, m, :]   # (N, K)
        xi_m = xi_all[m]     # (K,)

        # Formulate Omega_m = sum_n (p_n / eta) mu_n mu_n^H
        # Vectorized outer products:
        p_over_eta = p[:, m] / eta_arr[m]  # (N,)
        Omega_m = np.einsum("n,nk,nl->kl", p_over_eta, mu_m, np.conj(mu_m))

        # Augmented matrix M_mat of size (K+1, K+1)
        M_mat = np.zeros((K + 1, K + 1), dtype=complex)
        M_mat[:K, :K] = Omega_m
        M_mat[:K, K] = -xi_m
        M_mat[K, :K] = -np.conj(xi_m)

        if mode == "sdp" and K <= 50:
            # Full SDP relaxation via CVXPY SCS
            V = cp.Variable((K + 1, K + 1), hermitian=True)
            obj = cp.Minimize(cp.real(cp.trace(M_mat @ V)))
            prob = cp.Problem(obj, [V >> 0, cp.diag(V) == 1.0])
            prob.solve(solver=cp.SCS, eps=1e-3, verbose=False)
            if V.value is not None:
                V_val = V.value
            else:
                evals, evecs = np.linalg.eigh(M_mat)
                v_min = evecs[:, 0]
                V_val = np.outer(v_min, np.conj(v_min))
        else:
            # Rank-1 relaxation via minimum eigenvalue/eigenvector of M_mat
            evals, evecs = np.linalg.eigh(M_mat)
            v_min = evecs[:, 0]
            V_val = np.outer(v_min, np.conj(v_min))

        # Extract principal component
        evals_v, evecs_v = np.linalg.eigh(V_val)
        v_top = evecs_v[:, -1] * np.sqrt(max(0.0, float(np.real(evals_v[-1]))))
        t_ref = v_top[-1]
        phase_base = np.angle(v_top[:K]) - np.angle(t_ref) if abs(t_ref) > 1e-12 else np.angle(v_top[:K])
        b_best = np.exp(1j * phase_base)

        # Base objective evaluation
        best_val = np.sum((w_m * np.abs(mu_m.conj() @ b_best) - 1.0) ** 2)

        # Gaussian randomization candidates
        for _ in range(num_rand):
            noise = (rng.standard_normal(K + 1) + 1j * rng.standard_normal(K + 1)) * 0.1
            cand = v_top + noise
            t_cand = cand[-1]
            phase_cand = np.angle(cand[:K]) - np.angle(t_cand) if abs(t_cand) > 1e-12 else np.angle(cand[:K])
            b_cand = np.exp(1j * phase_cand)
            val = np.sum((w_m * np.abs(mu_m.conj() @ b_cand) - 1.0) ** 2)
            if val < best_val:
                best_val = val
                b_best = b_cand

        beta_sdr[m] = b_best

    return beta_sdr


# ==============================================================================
# SUB-PROBLEM 2: Denoising Factor Optimization eta[m] (Eqs. 16-18)
# ==============================================================================

def optimize_eta_analytical(
    p: np.ndarray,
    h_mag: np.ndarray,
    sigma2: float
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Sub-problem 2: Exact Analytical Solution for Denoising Factor eta[m] (Eq. 17).

    Minimizing MSE[m] with respect to gamma[m] = 1 / sqrt(eta[m]):
    gamma*[m] = sum_n (sqrt(p_n[m]) * |h_n[m]|) / (sigma2 + sum_n p_n[m] * |h_n[m]|^2)
    eta*[m] = 1 / (gamma*[m])^2

    Parameters
    ----------
    p : np.ndarray
        User transmit power of shape (N, M).
    h_mag : np.ndarray
        Cascaded channel magnitudes |h_n[n, m]| of shape (N, M).
    sigma2 : float
        Noise power in Watts.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        eta : shape (M,), optimal denoising factors
        gamma : shape (M,), optimal inverse root factors gamma = 1 / sqrt(eta)
    """
    num = np.sum(np.sqrt(p) * h_mag, axis=0)  # shape (M,)
    den = sigma2 + np.sum(p * (h_mag ** 2), axis=0)  # shape (M,)
    gamma_opt = num / den  # shape (M,)
    eta_opt = 1.0 / (gamma_opt ** 2)
    return eta_opt, gamma_opt


def optimize_eta_cvx(
    p: np.ndarray,
    h_mag: np.ndarray,
    sigma2: float,
    slots: Optional[Union[Sequence[int], int]] = None
) -> Tuple[np.ndarray, np.ndarray, float]:
    """
    Sub-problem 2: CVXPY QCQP Formulation for Denoising Factor (Eq. 18).

    min_{gamma, chi} chi
    s.t. sum_{n=1}^N (sqrt(p_n[m]) * |h_n[m]| * gamma[m] - 1)^2 + sigma2 * gamma[m]^2 <= chi,
         gamma[m] >= 0, for all m.

    Variables are scaled to O(1) for numerical stability and solved via CLARABEL.

    Parameters
    ----------
    p : np.ndarray
        User transmit power of shape (N, M).
    h_mag : np.ndarray
        Cascaded channel magnitudes of shape (N, M).
    sigma2 : float
        Noise power in Watts.
    slots : Sequence[int] or int, optional
        Subset of time slot indices to solve. If None, solves for all M slots.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray, float]
        eta_cvx : shape (M_eval,)
        gamma_cvx : shape (M_eval,)
        chi_val : float, optimal epigraph objective
    """
    N, M_total = p.shape
    if slots is None:
        slot_indices = np.arange(M_total)
    elif isinstance(slots, int):
        slot_indices = np.array([slots])
    else:
        slot_indices = np.array(slots)

    M_eval = len(slot_indices)
    p_sub = p[:, slot_indices]
    h_sub = h_mag[:, slot_indices]

    # Pre-scale gamma by analytical order of magnitude for O(1) solver conditioning
    _, gamma_ref = optimize_eta_analytical(p_sub, h_sub, sigma2)
    scale = gamma_ref  # shape (M_eval,)
    sigma = np.sqrt(sigma2)

    # Scaled coefficients:
    coeff_a = (np.sqrt(p_sub) * h_sub) * scale[None, :]  # shape (N, M_eval)
    coeff_b = sigma * scale  # shape (M_eval,)

    g_norm = cp.Variable(M_eval, nonneg=True)
    chi = cp.Variable()

    constraints = []
    slot_costs = []
    for idx in range(M_eval):
        res = coeff_a[:, idx] * g_norm[idx] - 1.0
        noise = coeff_b[idx] * g_norm[idx]
        cost_m = cp.sum_squares(res) + cp.square(noise)
        slot_costs.append(cost_m)
        constraints.append(cost_m <= chi)

    # Tie-breaker regularization to uniquely pull non-bottleneck slots to their global minimum
    obj = cp.Minimize(chi + 1e-7 * cp.sum(slot_costs))
    prob = cp.Problem(obj, constraints)
    prob.solve(solver=cp.CLARABEL)

    if prob.status not in ["optimal", "optimal_inaccurate"]:
        prob.solve(solver=cp.SCS, eps=1e-4)

    gamma_cvx = g_norm.value * scale
    eta_cvx = 1.0 / (gamma_cvx ** 2)
    chi_val = float(chi.value)

    return eta_cvx, gamma_cvx, chi_val


# ==============================================================================
# SUB-PROBLEM 3: User Transmit Power Optimization p_n[m] (Eqs. 19-20)
# ==============================================================================

def optimize_power_analytical(
    eta: np.ndarray,
    h_mag: np.ndarray,
    p_max: float
) -> np.ndarray:
    """
    Sub-problem 3: Exact Analytical Solution for Transmit Power p_n[m] (Eq. 19).

    Minimizing sum_{n=1}^N (sqrt(p_n[m]) * |h_n[m]| / sqrt(eta[m]) - 1)^2
    subject to 0 <= p_n[m] <= p_max.
    Unconstrained minimizer: sqrt(p_n*[m]) = sqrt(eta[m]) / |h_n[m]|
    With box constraint: p_n*[m] = min(p_max, eta[m] / |h_n[m]|^2).

    Parameters
    ----------
    eta : np.ndarray
        Denoising factor of shape (M,).
    h_mag : np.ndarray
        Cascaded channel magnitudes of shape (N, M).
    p_max : float
        Maximum user transmit power in Watts.

    Returns
    -------
    np.ndarray
        Optimal transmit power array p* of shape (N, M).
    """
    eta_arr = np.atleast_1d(eta)
    channel_inversion = eta_arr[None, :] / (h_mag ** 2 + 1e-30)
    p_opt = np.minimum(p_max, channel_inversion)
    return p_opt


def optimize_power_cvx(
    eta: np.ndarray,
    h_mag: np.ndarray,
    p_max: float,
    slots: Optional[Union[Sequence[int], int]] = None
) -> Tuple[np.ndarray, float]:
    """
    Sub-problem 3: CVXPY QCQP Formulation for Transmit Power (Eq. 20).

    min_{s, w} w
    s.t. sum_{n=1}^N (s_n[m] * |h_n[m]| / sqrt(eta[m]) - 1)^2 <= w, for all m,
         0 <= s_n[m] <= sqrt(p_max),
    where s_n[m] = sqrt(p_n[m]).

    Parameters
    ----------
    eta : np.ndarray
        Denoising factor of shape (M,).
    h_mag : np.ndarray
        Cascaded channel magnitudes of shape (N, M).
    p_max : float
        Maximum user transmit power in Watts.
    slots : Sequence[int] or int, optional
        Subset of time slot indices to solve. If None, solves for all M slots.

    Returns
    -------
    Tuple[np.ndarray, float]
        p_cvx : shape (N, M_eval), optimal transmit powers
        w_val : float, optimal epigraph objective
    """
    N, M_total = h_mag.shape
    if slots is None:
        slot_indices = np.arange(M_total)
    elif isinstance(slots, int):
        slot_indices = np.array([slots])
    else:
        slot_indices = np.array(slots)

    M_eval = len(slot_indices)
    eta_sub = np.atleast_1d(eta)[slot_indices]
    h_sub = h_mag[:, slot_indices]

    s_max = np.sqrt(p_max)
    coeff = h_sub / np.sqrt(eta_sub[None, :])  # shape (N, M_eval)

    s = cp.Variable((N, M_eval), nonneg=True)
    w = cp.Variable()

    constraints = [s <= s_max]
    slot_costs = []
    for idx in range(M_eval):
        cost_m = cp.sum_squares(cp.multiply(coeff[:, idx], s[:, idx]) - 1.0)
        slot_costs.append(cost_m)
        constraints.append(cost_m <= w)

    # Tie-breaker regularization to uniquely pull non-bottleneck slots to their global minimum
    obj = cp.Minimize(w + 1e-7 * cp.sum(slot_costs))
    prob = cp.Problem(obj, constraints)
    prob.solve(solver=cp.CLARABEL)

    if prob.status not in ["optimal", "optimal_inaccurate"]:
        prob.solve(solver=cp.SCS, eps=1e-4)

    s_val = np.maximum(0.0, s.value)
    p_cvx = s_val ** 2
    w_val = float(w.value)

    return p_cvx, w_val


# ==============================================================================
# SUB-PROBLEM 1 (rigorous variants): majorization-minimization phase updates
# ==============================================================================
#
# Slot objective (p, eta fixed):   f_m(beta) = sum_n ( w_n |nu_n^H beta| - 1 )^2 + sigma2/eta
#   with nu_n = pathloss_n * irs_gain_scale * mu_tilde_n  and  w_n = sqrt(p_n / eta).
#   = beta^H Phi beta - 2 sum_n w_n |nu_n^H beta| + N + sigma2/eta,   Phi = sum_n w_n^2 nu_n nu_n^H.
#
# NOTE on the paper's Eqs. (13)-(15): Eq. (13) replaces |nu_n^H beta|^2 by nu_n^H nu_n ||beta||^2 and drops the
# absolute value in the cross term, which is only valid if every user's effective channel is already phase
# aligned. It also drops the linear term (lambda_max I - Phi) beta_tilde of the standard MM bound. Eq. (15) is
# therefore a maximum-ratio-combining heuristic, not a descent step on (11)/(12). The update below is the
# standard two-step majorization:
#   (i)  -|x| <= -Re{ x * conj(x_tilde) / |x_tilde| }       (tight at x = x_tilde)
#   (ii) beta^H Phi beta <= lambda_max ||beta||^2 - 2 Re{beta^H (lambda_max I - Phi) beta_tilde} + const
# giving the closed form   beta+ = exp( j arg( xi_tilde + (lambda_max I - Phi) beta_tilde ) ),
#   xi_tilde = sum_n w_n nu_n x_n/|x_n|,  x_n = nu_n^H beta_tilde,
# which never increases f_m for fixed (p, eta).

def _effective_nu(q: np.ndarray, users: np.ndarray, config: SystemConfig, mu_tilde: np.ndarray) -> np.ndarray:
    """nu[n, m, k] = pathloss[n, m] * irs_gain_scale * mu_tilde[n, m, k]  so that |h_n[m]| = |nu_n^H beta|."""
    d_IB = np.sqrt(np.sum(q ** 2, axis=-1) + (config.h_I - config.h_B) ** 2)
    d_UnI = np.sqrt(np.sum((users[:, None, :] - q[None, :, :]) ** 2, axis=-1) + config.h_I ** 2)
    pl = np.sqrt(config.h_0) / ((d_UnI * d_IB[None, :]) ** (config.alpha / 2.0))
    return (pl * config.irs_gain_scale)[:, :, None] * mu_tilde


def _slot_mse_exact_eta(beta: np.ndarray, p: np.ndarray, nu: np.ndarray, sigma2: float):
    """Exact per-slot MSE with eta re-optimised in closed form. beta is (K,) or (M, K)."""
    N = nu.shape[0]
    b = beta[None, None, :] if beta.ndim == 1 else beta[None, :, :]
    h = np.abs(np.sum(np.conj(nu) * b, axis=2))                       # (N, M)
    eta = compute_optimal_eta(p, h, sigma2)
    mse, _ = compute_aircomp_mse(p, h, eta, sigma2, N)
    return mse, eta


def optimize_phase_per_slot_mm(
    beta_curr: np.ndarray,
    p: np.ndarray,
    eta: np.ndarray,
    q: np.ndarray,
    users: np.ndarray,
    config: SystemConfig,
    mu_tilde: np.ndarray,
    n_inner: int = 10,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    """
    Per-slot IRS phase update (slots decouple when beta[m] is slot dependent). Runs `n_inner` MM steps per slot
    (vectorised over slots), re-optimises eta[m] in closed form, and keeps a slot's new phase only if that slot's
    exact MSE does not increase -- so every slot, and hence the worst slot, is monotone.
    """
    N, M, K = mu_tilde.shape
    if beta_curr.shape != (M, K):
        raise ValueError(f"beta_curr must have shape ({M}, {K}), got {beta_curr.shape}")
    nu = _effective_nu(q, users, config, mu_tilde)                    # (N, M, K)
    w = np.sqrt(p / eta[None, :])                                      # (N, M)

    # lambda_max(Phi_m) = lambda_max(A^H A), A = [w_n nu_n]  (N x N Gram, cheap)
    A = w[:, :, None] * nu                                             # (N, M, K)
    gram = np.einsum("nmk,lmk->mnl", np.conj(A), A)                    # (M, N, N)
    lam = np.linalg.eigvalsh(gram)[:, -1].real                         # (M,)

    beta = beta_curr.copy()
    for _ in range(n_inner):
        x = np.einsum("nmk,mk->nm", np.conj(nu), beta)                 # (N, M)  nu^H beta
        ph = x / np.maximum(np.abs(x), 1e-30)
        xi = np.einsum("nm,nmk->mk", w * ph, nu)                       # (M, K)
        Phi_beta = np.einsum("nm,nmk->mk", (w ** 2) * x, nu)           # (M, K)
        z = xi + lam[:, None] * beta - Phi_beta
        beta = np.exp(1j * np.angle(z))

    mse_old, eta_old = _slot_mse_exact_eta(beta_curr, p, nu, config.sigma2)
    mse_new, eta_new = _slot_mse_exact_eta(beta, p, nu, config.sigma2)
    take = mse_new <= mse_old + 1e-15
    beta_next = np.where(take[:, None], beta, beta_curr)
    eta_next = np.where(take, eta_new, eta_old)
    mse_next = np.where(take, mse_new, mse_old)
    diag = {
        "mode": "per_slot_mm",
        "accepted_slots": int(take.sum()), "num_slots": int(M),
        "F_curr": float(mse_old.max()), "F_next": float(mse_next.max()),
        "accepted": bool(mse_next.max() <= mse_old.max() + 1e-15),
    }
    return beta_next, eta_next, diag


def optimize_phase_common_aggregate(
    beta_curr: np.ndarray,
    p: np.ndarray,
    q: np.ndarray,
    users: np.ndarray,
    config: SystemConfig,
    mu_tilde: np.ndarray,
    eta: np.ndarray,
    n_inner: int = 20,
    tau_frac: float = 0.05,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    """
    Common (slot-independent) phase update using ALL slots: MM on the softmax-weighted sum of the slot objectives,
    omega_m = softmax(F_m / (tau_frac * F_max)), which is a smoothed surrogate for max_m F_m. A candidate is accepted
    only if the exact worst-slot MSE (eta re-optimised) does not increase.
    """
    N, M, K = mu_tilde.shape
    if beta_curr.shape != (K,):
        raise ValueError(f"beta_curr must have shape ({K},), got {beta_curr.shape}")
    nu = _effective_nu(q, users, config, mu_tilde)
    w = np.sqrt(p / eta[None, :])                                      # (N, M)

    mse_cur, eta_cur = _slot_mse_exact_eta(beta_curr, p, nu, config.sigma2)
    F_cur = float(mse_cur.max())
    tau = max(tau_frac * F_cur, 1e-12)
    om = np.exp((mse_cur - F_cur) / tau); om /= om.sum()               # (M,)

    wo2 = (w ** 2) * om[None, :]                                       # (N, M)
    Phi = np.einsum("nm,nmk,nml->kl", wo2, nu, np.conj(nu))            # (K, K) = sum_m om_m Phi_m
    lam = float(np.linalg.eigvalsh(Phi)[-1].real)

    beta = beta_curr.copy()
    for _ in range(n_inner):
        x = np.einsum("nmk,k->nm", np.conj(nu), beta)
        ph = x / np.maximum(np.abs(x), 1e-30)
        xi = np.einsum("nm,nmk->k", (w * om[None, :]) * ph, nu)
        Phi_beta = np.einsum("nm,nmk->k", wo2 * x, nu)
        beta = np.exp(1j * np.angle(xi + lam * beta - Phi_beta))

    mse_new, eta_new = _slot_mse_exact_eta(beta, p, nu, config.sigma2)
    F_new = float(mse_new.max())
    ok = F_new <= F_cur + 1e-12
    diag = {"mode": "common_aggregate", "accepted": bool(ok), "F_curr": F_cur, "F_next": F_new if ok else F_cur}
    if ok:
        return beta, eta_new, diag
    return beta_curr.copy(), eta_cur, diag
