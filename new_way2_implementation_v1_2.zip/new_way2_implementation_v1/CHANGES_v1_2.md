# Changes vs v1_1

## trajectory_sca.py (SP4)
- Root cause of "SP4 never accepted": the unscaled conic program was ill-conditioned; CLARABEL/SCS returned
  points whose surrogate value exceeded the exact MSE at q_curr, which the majorizer forbids. The surrogate math
  itself was verified tight (matches exact MSE to 1e-16 at q_curr).
- Fix: variables scaled by the trust-region radius (q = q_curr + s*z, ||z|| <= 1), objective scaled by F_old,
  constraints vectorised (no per-slot Python loop). ~6x faster per solve; status `optimal` at all tolerances.
- New `phase_mode` argument ("common" default | "per_slot"); per-slot beta of shape (M, K) now supported.

## subproblems.py
- `optimize_phase_per_slot_mm`: per-slot MM phase update (monotone per slot) + per-slot acceptance.
- `optimize_phase_common_aggregate`: common beta, MM on softmax-weighted sum of ALL slot objectives.
- Note on paper Eqs. (13)-(15): derivation drops |.| and the linear MM term; Eq. (15) is an MRC heuristic.

## algorithm2.py
- `run_alternating_optimization(..., phase_mode="common_worst_slot" | "common_aggregate" | "per_slot")`.
  Default unchanged (legacy) so old tests/behaviour are preserved.

## tests
- test_audit_v1.py T11: use realistic eta (1e-6 left nothing to improve for a 1e-4-accuracy fallback solver).
- test_phase_mm_v1.py (new): MM monotonicity without safeguard, MM vs paper Eq.15, SP4 majorizer guarantee
  without safeguard, full-loop monotonicity for all three phase modes.
