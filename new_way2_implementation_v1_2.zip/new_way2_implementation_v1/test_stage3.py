"""
Verification script for Stage 3: UAV Trajectory Optimization via SCA and Full Algorithm 2.
Replication of:
"Federated learning via over-the-air computation in IRS-assisted UAV communications"
(Scientific Reports, 2023)
"""

import sys
import numpy as np

from config import (
    SystemConfig,
    generate_user_locations,
    generate_straight_line_trajectory
)
from trajectory_sca import (
    compute_Q_and_gradient,
    solve_trajectory_sca,
)
from algorithm2 import (
    run_alternating_optimization,
)


def run_stage3_verification():
    print("=" * 80)
    print("STAGE 3 VERIFICATION: UAV TRAJECTORY SCA & ALGORITHM 2")
    print("=" * 80)

    cfg = SystemConfig()
    users = generate_user_locations(cfg)

    # --------------------------------------------------------------------------
    # 1. ANALYTICAL VS NUMERICAL GRADIENT OF Q_n[m] (Eq. 25 typo fix)
    # --------------------------------------------------------------------------
    print("\n--- 1. ANALYTICAL GRADIENT VERIFICATION (Eq. 25 gamma_n -> r_n) ---")
    q_sample = np.array([[120.0, 15.0], [50.0, -10.0]])  # shape (2, 2)
    Q, grad_Q, _, _ = compute_Q_and_gradient(q_sample, users, cfg.h_I, cfg.h_B)

    # Compute numerical finite-difference gradient
    eps = 1e-6
    grad_num = np.zeros_like(grad_Q)
    for m in range(q_sample.shape[0]):
        for dim in range(2):
            q_plus = np.copy(q_sample)
            q_plus[m, dim] += eps
            Q_plus, _, _, _ = compute_Q_and_gradient(q_plus, users, cfg.h_I, cfg.h_B)

            q_minus = np.copy(q_sample)
            q_minus[m, dim] -= eps
            Q_minus, _, _, _ = compute_Q_and_gradient(q_minus, users, cfg.h_I, cfg.h_B)

            grad_num[:, m, dim] = (Q_plus[:, m] - Q_minus[:, m]) / (2.0 * eps)

    grad_diff = np.max(np.abs(grad_Q - grad_num) / (np.abs(grad_num) + 1e-12))
    print(f"Max relative gradient error between Analytical and Finite Differences: {grad_diff:.2e}")
    assert grad_diff < 1e-6, f"Gradient verification failed with relative error: {grad_diff}"
    print("Gradient formula and typo fix (gamma_n -> r_n) successfully verified!")

    # --------------------------------------------------------------------------
    # 2. SCA TRAJECTORY OPTIMIZATION & CONSTRAINT SATISFACTION
    # --------------------------------------------------------------------------
    print("\n--- 2. SUB-PROBLEM 4: SCA TRAJECTORY OPTIMIZATION & CONSTRAINTS ---")
    q_straight = generate_straight_line_trajectory(cfg)
    p_init = np.full((cfg.N, cfg.M), cfg.p_max)
    eta_init = np.full(cfg.M, 1e-12)
    beta_init = np.ones(cfg.K, dtype=complex)
    mu_tilde_dummy = np.ones((cfg.N, cfg.M, cfg.K), dtype=complex)

    step_max = 8.0
    res = solve_trajectory_sca(
        q_curr=q_straight,
        p=p_init,
        eta=eta_init,
        beta=beta_init,
        mu_tilde=mu_tilde_dummy,
        config=cfg,
        users=users,
        step_max=step_max,
        solver="CLARABEL"
    )
    if isinstance(res, tuple) and len(res) == 2 and isinstance(res[1], dict):
        q_updated, diag = res
        status = diag["solver_status"]
        obj_val = diag["surrogate_objective"]
    else:
        q_updated, obj_val, status = res

    print(f"SCA Solver Status: {status}")
    print(f"Objective value:   {obj_val:.4f}")
    assert status in ["optimal", "optimal_inaccurate"], f"SCA failed with status {status}"

    # Constraint C4: Initial position
    err_c4 = np.linalg.norm(q_updated[0] - cfg.q_0)
    print(f"Constraint C4 (q[0] == q_0): err = {err_c4:.2e}")
    assert err_c4 < 1e-6, "Constraint C4 violated!"

    # Constraint C5: Destination position
    err_c5 = np.linalg.norm(q_updated[-1] - cfg.q_F)
    print(f"Constraint C5 (q[M-1] == q_F): err = {err_c5:.2e}")
    assert err_c5 < 1e-6, "Constraint C5 violated!"

    # Constraint C6: Velocity / displacement constraint
    disp_slots = np.linalg.norm(q_updated[1:] - q_updated[:-1], axis=1)
    max_disp = np.max(disp_slots)
    print(f"Constraint C6 (Max step <= {cfg.max_displacement:.2f} m): observed = {max_disp:.4f} m")
    assert max_disp <= cfg.max_displacement + 1e-6, "Constraint C6 violated!"

    # Trust-region step constraint
    shift_slots = np.linalg.norm(q_updated - q_straight, axis=1)
    max_shift = np.max(shift_slots)
    print(f"Trust-Region constraint (shift <= {step_max:.2f} m): observed = {max_shift:.4f} m")
    assert max_shift <= step_max + 1e-6, "Trust-region constraint violated!"

    # --------------------------------------------------------------------------
    # 3. FULL ALTERNATING OPTIMIZATION (ALGORITHM 2) RUN
    # --------------------------------------------------------------------------
    print("\n--- 3. FULL ALTERNATING OPTIMIZATION (ALGORITHM 2) EXECUTION ---")
    res_bcd = run_alternating_optimization(
        config=cfg,
        max_iters=15,
        tol=1e-5,
        step_max=6.0,
        verbose=True
    )

    bcd_history = res_bcd["mse_history"]
    print(f"\nCompleted {len(bcd_history) - 1} BCD outer iterations.")
    print(f"Initial worst-case MSE:   {bcd_history[0]:.6e}")
    print(f"Final worst-case MSE:     {bcd_history[-1]:.6e}")
    reduction = (bcd_history[0] - bcd_history[-1]) / bcd_history[0] * 100.0
    print(f"Total MSE reduction:      {reduction:.2f}%")
    assert bcd_history[-1] <= bcd_history[0] + 1e-9, "Algorithm 2 must not increase worst-case MSE!"
    assert not np.any(np.isnan(bcd_history)), "NaN encountered during Algorithm 2!"

    print("\n" + "=" * 80)
    print("ALL STAGE 3 VERIFICATIONS PASSED SUCCESSFULLY (GENUINE TRAJECTORY & AO)!")
    print("=" * 80)
    return True


if __name__ == "__main__":
    success = run_stage3_verification()
    sys.exit(0 if success else 1)
