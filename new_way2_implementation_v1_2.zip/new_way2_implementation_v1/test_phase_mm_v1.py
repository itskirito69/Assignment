"""
Tests for the rigorous phase updates and the rescaled SP4 program.
Run: python test_phase_mm_v1.py
"""
import unittest
import numpy as np

from config import SystemConfig, generate_user_locations, generate_straight_line_trajectory
from channel_model import (generate_rician_fading, compute_decomposed_channel, compute_cascaded_channel,
                           compute_aircomp_mse, compute_optimal_eta)
from subproblems import (optimize_phase_per_slot_mm, optimize_phase_common_aggregate, _effective_nu,
                         optimize_eta_analytical, optimize_power_analytical)
from trajectory_sca import solve_trajectory_sca
from algorithm2 import run_alternating_optimization


def _setup(T=12.0, seed=123, q0=(-50.0, 0.0), qF=(250.0, 0.0)):
    cfg = SystemConfig(T=T, q_0=np.array(q0), q_F=np.array(qF))
    users = generate_user_locations(cfg)
    q = generate_straight_line_trajectory(cfg)
    h1, h2 = generate_rician_fading(q, users, cfg, seed=seed)
    mu = compute_decomposed_channel(h1, h2, True)
    return cfg, users, q, mu


def _fixed_eta_slot_cost(beta, p, eta, nu, N):
    """f_m(beta) for FIXED (p, eta): sum_n (sqrt(p/eta)|nu^H beta| - 1)^2 (noise term is constant in beta)."""
    h = np.abs(np.einsum("nmk,mk->nm", np.conj(nu), beta))
    return np.sum((np.sqrt(p / eta[None, :]) * h - 1.0) ** 2, axis=0)


class TestPhaseMM(unittest.TestCase):
    def test_P01_per_slot_mm_is_monotone_without_safeguard(self):
        """The MM step alone (before the acceptance test) must never increase any slot's cost for fixed p, eta."""
        for seed in (1, 2, 3):
            cfg, users, q, mu = _setup(seed=seed)
            M, K, N = cfg.M, cfg.K, cfg.N
            rng = np.random.default_rng(seed)
            beta0 = np.exp(1j * rng.uniform(0, 2 * np.pi, (M, K)))
            p = rng.uniform(0.2, 1.0, (N, M)) * cfg.p_max
            nu = _effective_nu(q, users, cfg, mu)
            h = np.abs(np.einsum("nmk,mk->nm", np.conj(nu), beta0))
            eta = compute_optimal_eta(p, h, cfg.sigma2)
            # replicate the raw MM iterations used inside optimize_phase_per_slot_mm
            w = np.sqrt(p / eta[None, :]); A = w[:, :, None] * nu
            lam = np.linalg.eigvalsh(np.einsum("nmk,lmk->mnl", np.conj(A), A))[:, -1].real
            beta = beta0.copy(); prev = _fixed_eta_slot_cost(beta, p, eta, nu, N)
            for _ in range(15):
                x = np.einsum("nmk,mk->nm", np.conj(nu), beta); ph = x / np.maximum(np.abs(x), 1e-30)
                xi = np.einsum("nm,nmk->mk", w * ph, nu); Pb = np.einsum("nm,nmk->mk", (w ** 2) * x, nu)
                beta = np.exp(1j * np.angle(xi + lam[:, None] * beta - Pb))
                cur = _fixed_eta_slot_cost(beta, p, eta, nu, N)
                self.assertTrue(np.all(cur <= prev + 1e-9), f"MM increased a slot cost (seed {seed})")
                prev = cur
        print("  [P01] Raw per-slot MM monotone for all slots (3 seeds x 15 steps), no safeguard involved.")

    def test_P02_per_slot_beats_paper_eq15_heuristic(self):
        cfg, users, q, mu = _setup()
        N, M, K = mu.shape
        p = np.full((N, M), cfg.p_max)
        beta0 = np.ones((M, K), dtype=complex)
        nu = _effective_nu(q, users, cfg, mu)
        h = np.abs(np.einsum("nmk,mk->nm", np.conj(nu), beta0)); eta = compute_optimal_eta(p, h, cfg.sigma2)
        b_mm, _, d = optimize_phase_per_slot_mm(beta0, p, eta, q, users, cfg, mu)
        w = np.sqrt(p / eta[None, :]); xi = np.einsum("nm,nmk->mk", w, nu)
        b_eq15 = np.exp(1j * np.angle(xi))
        def worst(b):
            hh = np.abs(np.einsum("nmk,mk->nm", np.conj(nu), b)); e = compute_optimal_eta(p, hh, cfg.sigma2)
            return compute_aircomp_mse(p, hh, e, cfg.sigma2, N)[1]
        print(f"  [P02] worst MSE: init {worst(beta0):.4e} | paper Eq.15 {worst(b_eq15):.4e} | MM {worst(b_mm):.4e}")
        self.assertLessEqual(worst(b_mm), worst(beta0) + 1e-12)
        self.assertLess(worst(b_mm), worst(b_eq15))

    def test_P03_common_aggregate_never_increases_worst_mse(self):
        cfg, users, q, mu = _setup()
        N, M, K = mu.shape
        p = np.full((N, M), cfg.p_max); beta = np.ones(K, dtype=complex)
        nu = _effective_nu(q, users, cfg, mu)
        for _ in range(5):
            h = np.abs(np.einsum("nmk,k->nm", np.conj(nu), beta)); eta = compute_optimal_eta(p, h, cfg.sigma2)
            F0 = compute_aircomp_mse(p, h, eta, cfg.sigma2, N)[1]
            beta, eta, d = optimize_phase_common_aggregate(beta, p, q, users, cfg, mu, eta)
            self.assertLessEqual(d["F_next"], F0 + 1e-12)
            self.assertEqual(beta.shape, (K,)); self.assertTrue(np.allclose(np.abs(beta), 1.0))
        print("  [P03] Common aggregate update: worst MSE non-increasing, unit modulus preserved.")


class TestSP4Rescaled(unittest.TestCase):
    def test_S01_majorizer_guarantee_holds_without_the_safeguard(self):
        """The solver's own candidate must have exact worst MSE <= current exact worst MSE (MM guarantee)."""
        for seed in (1, 2, 3, 4):
            cfg, users, q, mu = _setup(seed=seed)
            N, M, K = mu.shape
            beta = np.ones(K, dtype=complex); p = np.full((N, M), cfg.p_max)
            _, h = compute_cascaded_channel(q, users, beta, cfg, mu_tilde=mu)
            eta, _ = optimize_eta_analytical(p, h, cfg.sigma2); p = optimize_power_analytical(eta, h, cfg.p_max)
            qn, d = solve_trajectory_sca(q, p, eta, beta, mu, cfg, users, step_max=6.0)
            self.assertEqual(d["solver_status"], "optimal")
            self.assertLessEqual(d["candidate_exact_worst_mse"], d["old_exact_worst_mse"] + 1e-12)
            self.assertLessEqual(d["surrogate_objective"], d["old_exact_worst_mse"] * (1 + 1e-6))
            self.assertLessEqual(d["candidate_exact_worst_mse"], d["surrogate_objective"] * (1 + 1e-6))
        print("  [S01] SP4: surrogate opt <= old exact, and candidate exact <= surrogate opt (4 seeds).")


class TestFullLoop(unittest.TestCase):
    def test_F01_all_modes_monotone_and_trajectory_moves(self):
        res = {}
        for mode in ("common_worst_slot", "common_aggregate", "per_slot"):
            r = run_alternating_optimization(max_iters=8, verbose=False, tol=1e-12, phase_mode=mode)
            ms = np.array(r["mse_history"])
            self.assertTrue(np.all(np.diff(ms) <= 1e-12), f"{mode}: MSE not monotone")
            q0 = generate_straight_line_trajectory(SystemConfig())
            self.assertGreater(np.abs(r["q"] - q0).max(), 1.0, f"{mode}: trajectory never moved")
            res[mode] = ms[-1]
        print("  [F01] Final MSE by mode after 8 its: " + ", ".join(f"{k}={v:.3e}" for k, v in res.items()))
        self.assertLess(res["per_slot"], res["common_worst_slot"])
        self.assertLess(res["common_aggregate"], res["common_worst_slot"])


if __name__ == "__main__":
    unittest.main(verbosity=0)
