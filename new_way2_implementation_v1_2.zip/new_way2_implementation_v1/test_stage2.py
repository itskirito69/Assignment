"""
Verification script for Stage 2: Optimization Sub-problems 1, 2, and 3.
Replication of:
"Federated learning via over-the-air computation in IRS-assisted UAV communications"
(Scientific Reports, 2023)
"""

import sys
import numpy as np

from config import (
    SystemConfig,
    generate_user_locations,
    generate_straight_line_trajectory,
)
from channel_model import (
    compute_d_UnI,
    compute_d_IB,
    compute_path_loss,
    generate_rician_fading,
    compute_decomposed_channel,
    compute_cascaded_channel,
    compute_aircomp_mse,
)
from subproblems import (
    optimize_phase_proposed,
    optimize_phase_random,
    optimize_phase_sdr,
    optimize_eta_analytical,
    optimize_eta_cvx,
    optimize_power_analytical,
    optimize_power_cvx,
)


def run_stage2_verification():
    print("=" * 80)
    print("STAGE 2 VERIFICATION: OPTIMIZATION SUB-PROBLEMS (1, 2, 3)")
    print("=" * 80)

    cfg = SystemConfig()
    users = generate_user_locations(cfg)
    q_traj = generate_straight_line_trajectory(cfg)

    # Precompute system channel vectors
    d_IB = compute_d_IB(q_traj, cfg.h_I, cfg.h_B)
    d_UnI = compute_d_UnI(q_traj, users, cfg.h_I)
    path_loss = compute_path_loss(d_UnI, d_IB, cfg.h_0, cfg.alpha)
    h_IB_tilde, h_UnI_tilde = generate_rician_fading(q_traj, users, cfg, seed=123)
    mu_tilde = compute_decomposed_channel(h_IB_tilde, h_UnI_tilde, normalize_elements=True)
    mu_effective = path_loss[:, :, None] * mu_tilde  # shape (N, M, K)

    print(f"\nConfiguration loaded: N={cfg.N}, M={cfg.M}, K={cfg.K}, p_max={cfg.p_max} W, sigma2={cfg.sigma2:.2e} W")

    # --------------------------------------------------------------------------
    # 1. SUB-PROBLEM 1: IRS PHASE SHIFT OPTIMIZATION & BENCHMARKS (LEGACY)
    # --------------------------------------------------------------------------
    # NOTE: The methods below (optimize_phase_proposed, optimize_phase_random,
    # and optimize_phase_sdr) generate slot-dependent phases of shape (M, K)
    # corresponding to the original paper's per-slot formulation used for
    # benchmark comparisons in Figures 3 & 4. The audited production pipeline
    # uses common phase of shape (K,) via optimize_phase_common_with_profile_safeguard.
    print("\n--- 1. SUB-PROBLEM 1: LEGACY PER-SLOT PHASE BENCHMARKS (Figs. 3 & 4) ---")
    p_init = np.full((cfg.N, cfg.M), cfg.p_max)
    eta_init = np.full(cfg.M, 1e-12)

    # 1A. Legacy Proposed Per-Slot Closed-Form Phase (Eq. 15)
    beta_proposed = optimize_phase_proposed(p_init, eta_init, mu_effective)
    assert beta_proposed.shape == (cfg.M, cfg.K), f"Expected shape {(cfg.M, cfg.K)}, got {beta_proposed.shape}"
    assert np.allclose(np.abs(beta_proposed), 1.0, atol=1e-12), "Proposed phase must have unit modulus!"
    print(f"Proposed Phase (Eq. 15): shape={beta_proposed.shape}, unit modulus confirmed.")

    # 1B. Benchmark: Random Phase
    beta_random = optimize_phase_random(cfg.K, cfg.M, seed=42)
    assert beta_random.shape == (cfg.M, cfg.K)
    assert np.allclose(np.abs(beta_random), 1.0, atol=1e-12)
    print(f"Random Phase Benchmark:   shape={beta_random.shape}, unit modulus confirmed.")

    # 1C. Benchmark: SDR with Gaussian Randomization
    # Test on a representative subset of slots to ensure swift execution
    test_slots = [0, 75, 150, 225, 299]
    mu_sub = mu_effective[:, test_slots, :]
    p_sub = p_init[:, test_slots]
    eta_sub = eta_init[test_slots]
    beta_sdr_sub = optimize_phase_sdr(p_sub, eta_sub, mu_sub, num_rand=20, seed=42, mode="auto")
    assert beta_sdr_sub.shape == (len(test_slots), cfg.K)
    assert np.allclose(np.abs(beta_sdr_sub), 1.0, atol=1e-12)
    print(f"SDR Phase Benchmark:      tested on {len(test_slots)} slots, unit modulus confirmed.")

    # Compare full-mission MSE performance across phase methods
    # Run SDR over all 300 slots using fast eigen-randomization mode
    beta_sdr_full = optimize_phase_sdr(p_init, eta_init, mu_effective, num_rand=10, seed=42, mode="eigen")

    # Evaluate each phase method with full power and optimal eta
    _, h_mag_rand = compute_cascaded_channel(q_traj, users, beta_random, cfg, mu_tilde=mu_tilde)
    eta_rand, _ = optimize_eta_analytical(p_init, h_mag_rand, cfg.sigma2)
    _, mse_rand = compute_aircomp_mse(p_init, h_mag_rand, eta_rand, cfg.sigma2, cfg.N)

    _, h_mag_sdr = compute_cascaded_channel(q_traj, users, beta_sdr_full, cfg, mu_tilde=mu_tilde)
    eta_sdr, _ = optimize_eta_analytical(p_init, h_mag_sdr, cfg.sigma2)
    _, mse_sdr = compute_aircomp_mse(p_init, h_mag_sdr, eta_sdr, cfg.sigma2, cfg.N)

    _, h_mag_prop = compute_cascaded_channel(q_traj, users, beta_proposed, cfg, mu_tilde=mu_tilde)
    eta_prop, _ = optimize_eta_analytical(p_init, h_mag_prop, cfg.sigma2)
    _, mse_prop = compute_aircomp_mse(p_init, h_mag_prop, eta_prop, cfg.sigma2, cfg.N)

    print(f"Phase Comparison at p=p_max:")
    print(f"  Random Phase worst-case MSE:   {mse_rand:.6e}")
    print(f"  SDR Phase worst-case MSE:      {mse_sdr:.6e}")
    print(f"  Proposed Phase worst-case MSE: {mse_prop:.6e}")
    assert mse_prop < mse_rand, "Proposed phase must outperform Random Phase!"
    assert mse_sdr < mse_rand, "SDR phase must outperform Random Phase!"

    # --------------------------------------------------------------------------
    # 2. SUB-PROBLEM 2: DENOISING FACTOR OPTIMIZATION (Eqs. 16-18)
    # --------------------------------------------------------------------------
    print("\n--- 2. SUB-PROBLEM 2: DENOISING FACTOR OPTIMIZATION (Eqs. 16-18) ---")
    eta_an, gamma_an = optimize_eta_analytical(p_init, h_mag_prop, cfg.sigma2)
    print(f"Analytical solution: min(eta)={eta_an.min():.4e}, max(eta)={eta_an.max():.4e}")
    assert eta_an.shape == (cfg.M,)
    assert np.all(eta_an > 0), "eta must be strictly positive!"

    # Verify against CVXPY formulation (Eq. 18)
    eval_slots = [0, 50, 100, 150, 200, 250, 299]
    eta_cvx, gamma_cvx, chi_val = optimize_eta_cvx(p_init, h_mag_prop, cfg.sigma2, slots=eval_slots)
    max_rel_diff_eta = np.max(np.abs(eta_an[eval_slots] - eta_cvx) / eta_an[eval_slots])
    print(f"CVXPY Eq. 18 solved on {len(eval_slots)} slots: max relative difference vs Analytical = {max_rel_diff_eta:.2e}")
    assert max_rel_diff_eta < 1e-3, f"CVXPY eta mismatch: {max_rel_diff_eta}"

    # --------------------------------------------------------------------------
    # 3. SUB-PROBLEM 3: USER TRANSMIT POWER OPTIMIZATION (Eqs. 19-20)
    # --------------------------------------------------------------------------
    print("\n--- 3. SUB-PROBLEM 3: TRANSMIT POWER OPTIMIZATION (Eqs. 19-20) ---")
    p_an = optimize_power_analytical(eta_an, h_mag_prop, cfg.p_max)
    print(f"Analytical truncated inversion: min(p)={p_an.min():.4e} W, max(p)={p_an.max():.4e} W")
    assert p_an.shape == (cfg.N, cfg.M)
    assert np.all(p_an >= 0.0), "Power must be non-negative!"
    assert np.all(p_an <= cfg.p_max + 1e-12), "Power constraint p <= p_max violated!"

    # Verify against CVXPY formulation (Eq. 20)
    p_cvx, w_val = optimize_power_cvx(eta_an, h_mag_prop, cfg.p_max, slots=eval_slots)
    max_rel_diff_p = np.max(np.abs(p_an[:, eval_slots] - p_cvx) / (p_an[:, eval_slots] + 1e-30))
    print(f"CVXPY Eq. 20 solved on {len(eval_slots)} slots: max relative difference vs Analytical = {max_rel_diff_p:.2e}")
    assert max_rel_diff_p < 5e-2, f"CVXPY power mismatch: {max_rel_diff_p}"

    # Verify single-slot high precision check
    p_single_an = optimize_power_analytical(eta_an[150:151], h_mag_prop[:, 150:151], cfg.p_max)
    p_single_cvx, _ = optimize_power_cvx(eta_an[150:151], h_mag_prop[:, 150:151], cfg.p_max)
    single_rel_diff = np.max(np.abs(p_single_an - p_single_cvx) / p_single_an)
    print(f"Single-slot per-point CVXPY vs Analytical precision: {single_rel_diff:.2e}")
    assert single_rel_diff < 1e-4, f"Single-slot precision mismatch: {single_rel_diff}"

    # --------------------------------------------------------------------------
    # 4. SEQUENTIAL OPTIMIZATION & STRICT MONOTONIC CONVERGENCE
    # --------------------------------------------------------------------------
    print("\n--- 4. SEQUENTIAL SUB-PROBLEM EXECUTION (1 -> 2 -> 3) ---")
    # Initialize from the baseline state
    p_curr = np.full((cfg.N, cfg.M), cfg.p_max)
    xi_init = np.sum(np.sqrt(p_curr)[:, :, None] * mu_effective, axis=0)
    beta_curr = np.exp(1j * np.angle(xi_init))
    _, h_mag_curr = compute_cascaded_channel(q_traj, users, beta_curr, cfg, mu_tilde=mu_tilde)
    eta_curr, _ = optimize_eta_analytical(p_curr, h_mag_curr, cfg.sigma2)
    p_curr = optimize_power_analytical(eta_curr, h_mag_curr, cfg.p_max)
    eta_curr, _ = optimize_eta_analytical(p_curr, h_mag_curr, cfg.sigma2)

    _, mse_start = compute_aircomp_mse(p_curr, h_mag_curr, eta_curr, cfg.sigma2, cfg.N)
    print(f"Initial State worst-case MSE:  {mse_start:.6e}")

    # Step 1: Sub-problem 1 — Update IRS Phase Shift
    beta_new = optimize_phase_proposed(p_curr, eta_curr, mu_effective)
    _, h_mag_new = compute_cascaded_channel(q_traj, users, beta_new, cfg, mu_tilde=mu_tilde)
    _, mse_step1 = compute_aircomp_mse(p_curr, h_mag_new, eta_curr, cfg.sigma2, cfg.N)
    diff_1 = mse_start - mse_step1
    print(f"Step 1 (IRS Phase beta*):      {mse_step1:.6e} (decreased by {diff_1:.4e}, {diff_1 / mse_start * 100:.2f}%)")
    assert mse_step1 < mse_start, "Sub-problem 1 (Phase) must strictly decrease worst-case MSE!"

    # Step 2: Sub-problem 2 — Update Denoising Factor eta
    eta_new, _ = optimize_eta_analytical(p_curr, h_mag_new, cfg.sigma2)
    _, mse_step2 = compute_aircomp_mse(p_curr, h_mag_new, eta_new, cfg.sigma2, cfg.N)
    diff_2 = mse_step1 - mse_step2
    print(f"Step 2 (Denoising factor eta): {mse_step2:.6e} (decreased by {diff_2:.4e}, {diff_2 / mse_step1 * 100:.2f}%)")
    assert mse_step2 < mse_step1, "Sub-problem 2 (Eta) must strictly decrease worst-case MSE!"

    # Step 3: Sub-problem 3 — Update User Transmit Power p
    p_new = optimize_power_analytical(eta_new, h_mag_new, cfg.p_max)
    _, mse_step3 = compute_aircomp_mse(p_new, h_mag_new, eta_new, cfg.sigma2, cfg.N)
    diff_3 = mse_step2 - mse_step3
    print(f"Step 3 (User Power p):         {mse_step3:.6e} (decreased by {diff_3:.4e}, {diff_3 / mse_step2 * 100:.2f}%)")
    assert mse_step3 < mse_step2, "Sub-problem 3 (Power) must strictly decrease worst-case MSE!"

    total_reduction = (mse_start - mse_step3) / mse_start * 100.0
    print(f"\nTotal MSE reduction in cycle (1 -> 2 -> 3): {total_reduction:.2f}%")
    print(f"Monotonic sequence verified: {mse_start:.6e} > {mse_step1:.6e} > {mse_step2:.6e} > {mse_step3:.6e}")

    print("\n" + "=" * 80)
    print("ALL STAGE 2 VERIFICATIONS PASSED SUCCESSFULLY!")
    print("=" * 80)
    return True


if __name__ == "__main__":
    success = run_stage2_verification()
    sys.exit(0 if success else 1)
