"""
Configuration module for IRS-assisted UAV Federated Learning via Over-the-Air Computation.
Replication of:
"Federated learning via over-the-air computation in IRS-assisted UAV communications"
(Scientific Reports, 2023)
"""

from dataclasses import dataclass, field
import numpy as np


@dataclass
class SystemConfig:
    """System parameters from Table 1 and reverse-engineered hidden parameters."""

    # Base Station (BS) geometry
    bs_pos: np.ndarray = field(default_factory=lambda: np.array([0.0, 0.0]))
    h_B: float = 20.0  # BS antenna height in meters

    # UAV geometry & mobility
    h_I: float = 100.0  # UAV fixed flight altitude in meters
    q_0: np.ndarray = field(default_factory=lambda: np.array([-200.0, 0.0]))  # Initial position (x, y)
    q_F: np.ndarray = field(default_factory=lambda: np.array([500.0, 0.0]))   # Destination position (x, y)
    delta: float = 0.2  # Time slot length in seconds
    T: float = 60.0     # Default total mission time in seconds
    V_max: float = 30.0  # Maximum UAV speed in m/s

    # User equipment (UE) ground distribution
    N: int = 12  # Default number of ground users
    user_center: np.ndarray = field(default_factory=lambda: np.array([150.0, 0.0]))
    user_radius: float = 50.0  # Radius in meters of the user circular deployment area
    user_seed: int = 42  # Seed for deterministic user generation

    # IRS configuration
    K: int = 100  # Number of IRS reflecting elements
    # Configurable scaling factor to match exact MSE baseline scales if desired (default=1.0)
    irs_gain_scale: float = 1.0

    # Wireless channel parameters
    h_0_dB: float = -40.0  # Channel power gain at reference distance d0 = 1 m in dB
    alpha: float = 2.0     # Path loss exponent (LoS dominated)
    sigma2_dBm: float = -110.0  # Noise power in dBm
    kappa: float = 10.0    # Rician fading factor (10 dB -> linear factor 10.0)

    # User transmit power (reverse-engineered hidden parameter from Table 1 / simulation)
    p_max: float = 0.01  # Maximum user transmit power: 0.01 W (10 dBm)

    # Federated learning parameters
    zeta: float = 0.001  # FL local gradient descent learning rate

    @property
    def M(self) -> int:
        """Total number of discrete time slots."""
        return int(round(self.T / self.delta))

    @property
    def max_displacement(self) -> float:
        """Maximum flight displacement per time slot (meters)."""
        return self.V_max * self.delta

    @property
    def h_0(self) -> float:
        """Channel power gain at reference distance d0 = 1 m in linear scale."""
        return 10.0 ** (self.h_0_dB / 10.0)

    @property
    def sigma2(self) -> float:
        """Noise power in Watts (linear scale from dBm)."""
        return 10.0 ** ((self.sigma2_dBm - 30.0) / 10.0)


def generate_user_locations(config: SystemConfig = None) -> np.ndarray:
    """
    Generate deterministic 2D locations for N users uniformly distributed in a circle.

    Parameters
    ----------
    config : SystemConfig, optional
        System configuration dataclass.

    Returns
    -------
    np.ndarray
        Array of shape (N, 2) containing (x_n, y_n) coordinates for each user n.
    """
    if config is None:
        config = SystemConfig()

    rng = np.random.default_rng(config.user_seed)
    angles = rng.uniform(0.0, 2.0 * np.pi, config.N)
    # Uniform sampling over circular disk area: r = R * sqrt(u)
    radii = config.user_radius * np.sqrt(rng.uniform(0.0, 1.0, config.N))

    user_locs = np.zeros((config.N, 2), dtype=float)
    user_locs[:, 0] = config.user_center[0] + radii * np.cos(angles)
    user_locs[:, 1] = config.user_center[1] + radii * np.sin(angles)
    return user_locs


def generate_straight_line_trajectory(config: SystemConfig = None) -> np.ndarray:
    """
    Generate the default straight-line UAV trajectory from q_0 to q_F with constant velocity.

    Parameters
    ----------
    config : SystemConfig, optional
        System configuration dataclass.

    Returns
    -------
    np.ndarray
        Array of shape (M, 2) containing horizontal coordinates q[m] for each time slot m.
    """
    if config is None:
        config = SystemConfig()

    t_steps = np.linspace(0.0, 1.0, config.M)
    q = np.outer(1.0 - t_steps, config.q_0) + np.outer(t_steps, config.q_F)
    return q
