"""
UAV Trajectory Optimization via Successive Convex Approximation (Sub-problem 4).
Mathematically audited Alternative A Majorization-Minimization implementation for:
"Federated learning via over-the-air computation in IRS-assisted UAV communications"
(Scientific Reports, 2023)

Key Mathematical Elements Implemented:
1. Exact Distance Product & Gradient (Part C1):
   Q_k(q) = A_k(q) * B(q) = sqrt((||q - r_k||^2 + h_I^2) * (||q||^2 + (h_I - h_B)^2))
   grad_q Q_k(q) = ((q - r_k) * B^2(q) + q * A_k^2(q)) / Q_k(q)
   (Typo in paper Eq. (25) corrected: gamma_n -> r_n).

2. Exact Channel Coefficient (Part C2):
   c_{k, m} = (sqrt(p_k[m]) * sqrt(h_0) * irs_gain_scale * |mu_tilde_k[m]^H @ beta|) / sqrt(eta[m])
   Uses canonical common phase vector beta of shape (K,).

3. Curvature-Corrected Global Lower Bound for Q (Part C4):
   L_{k, m}^{(r)}(q) = Q_{k, m}^{(r)} + grad_Q_{k, m}^{(r)T} (q[m] - q^{(r)}[m]) - (mu / 2) * ||q[m] - q^{(r)}[m]||^2
   Universal bound parameter: mu >= 2.0 (default mu = 2.0).
   The established global Hessian lower bound grad^2 Q_k(q) >= -2 I guarantees that
   L_{k, m}^{(r)}(q) <= Q_{k, m}(q) globally on the feasible domain for all mu >= 2.0.

4. Weighted AM-GM Global Upper Bound for Q (Part C5):
   U_{k, m}^{(r)}(q) = 0.5 * [ t_{k, m}^{(r)} * (||q - r_k||^2 + h_I^2) + (1 / t_{k, m}^{(r)}) * (||q||^2 + (h_I - h_B)^2) ]
   where t_{k, m}^{(r)} = B(q^{(r)}[m]) / A_k(q^{(r)}[m]).
   Equality condition: The weighted AM-GM inequality holds with equality if and only if
   t_{k, m}^{(r)} * A_k^2(q) = (1 / t_{k, m}^{(r)}) * B^2(q), which is satisfied identically at
   q = q^{(r)}[m] by construction of t_{k, m}^{(r)}.
   Guarantees:
   - Q_{k, m}(q) <= U_{k, m}^{(r)}(q) for all q.
   - U_{k, m}^{(r)}(q^{(r)}[m]) = Q_{k, m}^{(r)} (zero-order tightness).
   - grad U_{k, m}^{(r)}(q^{(r)}[m]) = grad Q_{k, m}^{(r)} (first-order tightness).

5. Complete Alternative A Majorizer (Part C6):
   Normalized quantities:
   r_{k, m} = c_{k, m} / Q_{k, m}^{(r)}
   d_{k, m} = D_{k, m} / Q_{k, m}^{(r)}
   u_{k, m}(q) = U_{k, m}^{(r)}(q) / Q_{k, m}^{(r)}
   e_hat_{k, m}^{(r)} = r_{k, m}^2 * d_{k, m}^(-2) + 2 * r_{k, m} * u_{k, m}(q[m]) - 4 * r_{k, m} + 1.0
   Enforces: 0 < d_{k, m} <= L_{k, m}^{(r)}(q[m]) / Q_{k, m}^{(r)}.

6. Minimax Epigraph Formulation (Part C7):
   min_{q, d, t} t
   s.t. MSE_hat_m^{(r)} <= t for all m in M,
        kinematic endpoints, speed limit, and trust region.

7. Exact-Objective Acceptance Safeguard (Part C9):
   Evaluates old and proposed trajectories using the exact channel and MSE evaluator.
   Rejects candidates if kinematic constraints are violated or if exact worst-slot MSE increases.
"""

from typing import Optional, Tuple, Dict, Any
import numpy as np
import cvxpy as cp

from config import SystemConfig
from channel_model import (
    compute_d_UnI,
    compute_d_IB,
    compute_cascaded_channel,
    compute_aircomp_mse,
)


def compute_Q_and_gradient(
    q: np.ndarray,
    users: np.ndarray,
    h_I: float,
    h_B: float
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute cascaded distance product Q_n[m] = d_UnI[n, m] * d_IB[m]
    and the exact analytical gradient of Q_n[m] with respect to q[m].

    Gradient derivation (Part C1):
    f_1(q[m]) = ||q[m] - r_n||^2 + h_I^2 = d_UnI_sq[n, m],  grad f_1 = 2 * (q[m] - r_n)
    f_2(q[m]) = ||q[m]||^2 + (h_I - h_B)^2 = d_IB_sq[m],   grad f_2 = 2 * q[m]
    Q_n[m] = sqrt(f_1 * f_2)
    grad_q Q_n[m] = (f_2 * grad f_1 + f_1 * grad f_2) / (2 * sqrt(f_1 * f_2))
                  = ((q[m] - r_n) * d_IB_sq[m] + q[m] * d_UnI_sq[n, m]) / Q_n[m]

    Parameters
    ----------
    q : np.ndarray
        UAV horizontal positions of shape (M, 2).
    users : np.ndarray
        User horizontal positions of shape (N, 2).
    h_I : float
        UAV flight altitude in meters.
    h_B : float
        Base station height in meters.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]
        Q : shape (N, M), cascaded distance product d_UnI * d_IB
        grad_Q : shape (N, M, 2), gradient of Q w.r.t q[m]
        d_UnI : shape (N, M), user-to-UAV distance
        d_IB : shape (M,), UAV-to-BS distance
    """
    N = users.shape[0]
    M = q.shape[0]

    d_IB = compute_d_IB(q, h_I, h_B)  # shape (M,)
    d_UnI = compute_d_UnI(q, users, h_I)  # shape (N, M)

    d_IB_sq = d_IB ** 2  # shape (M,)
    d_UnI_sq = d_UnI ** 2  # shape (N, M)
    Q = d_UnI * d_IB[None, :]  # shape (N, M)

    # diff_q_r[n, m, :] = q[m, :] - r_n[:]
    diff_q_r = q[None, :, :] - users[:, None, :]  # shape (N, M, 2)

    # Numerator of grad_Q: ((q[m] - r_n) * d_IB_sq + q[m] * d_UnI_sq)
    term1 = diff_q_r * d_IB_sq[None, :, None]  # shape (N, M, 2)
    term2 = q[None, :, :] * d_UnI_sq[:, :, None]  # shape (N, M, 2)

    grad_Q = (term1 + term2) / Q[:, :, None]  # shape (N, M, 2)

    return Q, grad_Q, d_UnI, d_IB


def compute_channel_coefficients(
    p: np.ndarray,
    eta: np.ndarray,
    beta: np.ndarray,
    mu_tilde: np.ndarray,
    config: SystemConfig,
    phase_mode: str = "common"
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute channel coefficients c_{k, m} and directional IRS gains G_k[m] (Part C2).

    c_{k, m} = (sqrt(p_k[m]) * sqrt(h_0) * irs_gain_scale * G_k[m]) / sqrt(eta[m])
    where G_k[m] = |mu_tilde_k[m]^H @ beta|.

    Parameters
    ----------
    p : np.ndarray
        User transmit power of shape (N, M).
    eta : np.ndarray
        Denoising factor of shape (M,).
    beta : np.ndarray
        Common IRS phase vector of shape (K,).
    mu_tilde : np.ndarray
        Decomposed cascaded channel of shape (N, M, K).
    config : SystemConfig
        System parameters.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        c : shape (N, M), channel coefficients
        G : shape (N, M), directional IRS gains
    """
    K = config.K
    M_slots = mu_tilde.shape[1]
    if phase_mode not in ("common", "per_slot"):
        raise ValueError(f"phase_mode must be 'common' or 'per_slot', got {phase_mode!r}")
    if beta.ndim == 2:
        if beta.shape != (M_slots, K):
            raise ValueError(f"beta must have shape ({M_slots}, {K}), got {beta.shape}")
        if phase_mode == "common" and not np.allclose(beta, beta[0:1]):
            raise ValueError(
                "Part B1 Violation: Common IRS phase architecture requires identical phase vector across all slots. "
                "Found slot-dependent phase vector."
            )
        beta_mat = beta                      # (M, K)
    elif beta.ndim == 1:
        if beta.shape[0] != K:
            raise ValueError(f"Common beta must have shape ({K},), got {beta.shape}")
        beta_mat = np.broadcast_to(beta[None, :], (M_slots, K))
    else:
        raise ValueError(f"beta must have dimension 1 or 2, got {beta.ndim}")

    if not np.allclose(np.abs(beta_mat), 1.0, atol=1e-5):
        raise ValueError("All elements of beta must satisfy unit modulus |beta_k| = 1")

    # Inner product: mu_tilde_k[m]^H @ beta[m]  (beta[m] = beta for the common case)
    inner_prod = np.sum(np.conj(mu_tilde) * beta_mat[None, :, :], axis=2)  # (N, M)
    G = np.abs(inner_prod)  # (N, M)

    eta_arr = np.atleast_1d(eta)
    sqrt_eta = np.sqrt(np.maximum(1e-18, eta_arr))
    c = (np.sqrt(p) * np.sqrt(config.h_0) * config.irs_gain_scale * G) / sqrt_eta[None, :]
    return c, G


def solve_trajectory_sca(
    q_curr: np.ndarray,
    p: np.ndarray,
    eta: np.ndarray,
    beta: np.ndarray,
    mu_tilde: np.ndarray,
    config: SystemConfig,
    users: np.ndarray,
    step_max: float = 6.0,
    mu_bound: float = 2.0,
    solver: str = "CLARABEL",
    phase_mode: str = "common"
) -> Tuple[np.ndarray, Dict[str, Any]]:
    """
    Sub-problem 4: UAV Trajectory Optimization via Alternative A Majorization-Minimization.

    Implements the audited minimax convex conic formulation (Second-Order Cone and Power Cone Program):
    min_{q, d, t} t
    s.t. MSE_hat_m^{(r)} <= t,  for all m in {0, ..., M-1}
         d_{k, m} + (mu / (2 Q_{k, m}^{(r)})) * ||q[m] - q_curr[m]||^2
             <= 1 + (grad_Q_{k, m}^{(r)} / Q_{k, m}^{(r)})^T (q[m] - q_curr[m])
         q[0] == q_0
         q[M-1] == q_F
         ||q[m+1] - q[m]||_2 <= V_max * delta
         ||q[m] - q_curr[m]||_2 <= step_max

    After solving, applies the exact-objective acceptance safeguard (Part C9).

    Parameters
    ----------
    q_curr : np.ndarray
        Current trajectory q^{(r)} of shape (M, 2).
    p : np.ndarray
        User transmit power of shape (N, M).
    eta : np.ndarray
        Denoising factor of shape (M,).
    beta : np.ndarray
        Common IRS phase vector of shape (K,).
    mu_tilde : np.ndarray
        Decomposed cascaded channel of shape (N, M, K).
    config : SystemConfig
        System configuration.
    users : np.ndarray
        User positions of shape (N, 2).
    step_max : float, optional
        Maximum trust region displacement per slot in meters. Default 6.0 m.
    mu_bound : float, optional
        Curvature bound parameter for lower bound L. Must satisfy mu_bound >= 2.0
        for guaranteed global lower bound validity (default 2.0).
    solver : str, optional
        Convex solver to use ('CLARABEL' or 'SCS'). Default 'CLARABEL'.

    Returns
    -------
    Tuple[np.ndarray, Dict[str, Any]]
        q_next : shape (M, 2), updated trajectory (or retained q_curr if rejected)
        diag : Dict[str, Any], comprehensive diagnostics of the solve and acceptance test
    """
    N = users.shape[0]
    M = q_curr.shape[0]
    K = config.K

    # Validate curvature parameter mu_bound (Part C4)
    # The established global Hessian lower bound \nabla^2 Q_k(q) \succeq -2I
    # requires \mu \ge 2.0 for L_k^{(r)}(q) <= Q_k(q) to hold globally.
    if mu_bound < 2.0:
        raise ValueError(
            f"mu_bound must satisfy mu_bound >= 2.0 for guaranteed global lower bound validity, "
            f"got mu_bound = {mu_bound}."
        )

    # Enforce alpha=2 assumption (Part 4)
    if abs(config.alpha - 2.0) > 1e-6:
        raise ValueError(
            f"Alternative A trajectory majorizer currently supports alpha=2.0 only, "
            f"got config.alpha = {config.alpha}."
        )

    if phase_mode not in ("common", "per_slot"):
        raise ValueError(f"phase_mode must be 'common' or 'per_slot', got {phase_mode!r}")
    if beta.ndim == 2:
        if beta.shape != (M, K):
            raise ValueError(f"beta must have shape ({M}, {K}), got {beta.shape}")
        if phase_mode == "common" and not np.allclose(beta, beta[0:1]):
            raise ValueError(
                "Part B1 Violation: Common IRS phase architecture requires identical phase vector across all slots. "
                "Found slot-dependent phase vector."
            )
        beta_vec = beta[0] if phase_mode == "common" else beta
    elif beta.ndim == 1:
        if beta.shape[0] != K:
            raise ValueError(f"Common beta must have shape ({K},), got {beta.shape}")
        beta_vec = beta
    else:
        raise ValueError(f"beta must have dimension 1 or 2, got {beta.ndim}")

    # 1. Evaluate exact initial MSE with q_curr
    _, h_mag_old = compute_cascaded_channel(q_curr, users, beta_vec, config, mu_tilde=mu_tilde)
    mse_old_slots, F_old = compute_aircomp_mse(p, h_mag_old, eta, config.sigma2, N)

    # 2. Compute Q and exact gradients at reference trajectory q_curr
    Q_l, grad_Q, d_UnI, d_IB = compute_Q_and_gradient(q_curr, users, config.h_I, config.h_B)
    d_UnI_sq = d_UnI ** 2  # (N, M)
    d_IB_sq = d_IB ** 2    # (M,)

    # 3. Compute channel coefficients c_{k, m}
    c, G = compute_channel_coefficients(p, eta, beta_vec, mu_tilde, config, phase_mode=phase_mode)

    r_km = c / (Q_l + 1e-30)                       # (N, M)  r = c / Q^(r)
    g_norm = grad_Q / (Q_l[:, :, None] + 1e-30)    # (N, M, 2)
    c_norm = (0.5 * mu_bound) / (Q_l + 1e-30)      # (N, M)

    # 4. Analytical precomputation of the per-slot surrogate  lin(q) = 2 r u(q) - 4 r + 1 (summed over users)
    #    lin_m(q) = coeff_m ||q||^2 - 2 c_w_m^T q + const_m ,  expanded around q_curr below.
    w_km = r_km / (d_UnI_sq + 1e-30)
    W_m = np.sum(w_km, axis=0)
    R_m = np.sum(r_km, axis=0)
    c_w = np.einsum('km,kd->md', w_km, users)
    users_sq = np.sum(users ** 2, axis=-1) + (config.h_I ** 2)
    const_A = np.sum(w_km * users_sq[:, None], axis=0)
    const_B = (R_m / (d_IB_sq + 1e-30)) * ((config.h_I - config.h_B) ** 2)
    const_r = np.sum(-4.0 * r_km + 1.0, axis=0)
    coeff_q_sq = W_m + R_m / (d_IB_sq + 1e-30)

    lin_base = coeff_q_sq * np.sum(q_curr ** 2, axis=1) - 2.0 * np.sum(c_w * q_curr, axis=1) \
        + const_A + const_B + const_r                                   # lin_m(q_curr)
    lin_grad = 2.0 * coeff_q_sq[:, None] * q_curr - 2.0 * c_w           # (M, 2)
    noise_m = config.sigma2 / eta                                       # (M,)

    # 5. Scaled, vectorised convex program.
    #    q = q_curr + s z with s = step_max  (trust region  ->  ||z|| <= 1),
    #    objective divided by F_old.  Both keep all coefficients O(1) so that the conic solver is accurate
    #    (the unscaled program returned `optimal` points whose surrogate value exceeded the exact MSE at q_curr).
    s = float(step_max)
    F_scale = float(max(F_old, 1e-12))
    ones_N = np.ones((N, 1))

    z = cp.Variable((M, 2))
    q_var = q_curr + s * z
    d_var = cp.Variable((N, M), pos=True)
    t_epi = cp.Variable()

    ss_row = cp.reshape(cp.square(z[:, 0]) + cp.square(z[:, 1]), (1, M), order="C")
    z0_row = cp.reshape(z[:, 0], (1, M), order="C")
    z1_row = cp.reshape(z[:, 1], (1, M), order="C")

    constraints = [
        q_var[0] == config.q_0,
        q_var[M - 1] == config.q_F,
        cp.norm(q_var[1:] - q_var[:-1], axis=1) <= config.max_displacement,
        cp.norm(z, axis=1) <= 1.0,
        # curvature-corrected lower bound  d <= L(q)/Q^(r)
        d_var + cp.multiply(c_norm * s ** 2, ones_N @ ss_row)
        <= 1.0 + s * (cp.multiply(g_norm[:, :, 0], ones_N @ z0_row) + cp.multiply(g_norm[:, :, 1], ones_N @ z1_row)),
    ]

    d_term = cp.sum(cp.multiply(r_km ** 2, cp.power(d_var, -2)), axis=0)          # (M,)
    lin_term = lin_base + s * (cp.multiply(lin_grad[:, 0], z[:, 0]) + cp.multiply(lin_grad[:, 1], z[:, 1])) \
        + s ** 2 * cp.multiply(coeff_q_sq, cp.reshape(ss_row, (M,), order="C"))
    mse_hat = (d_term + lin_term + noise_m) / (N ** 2 * F_scale)
    constraints.append(mse_hat <= t_epi)

    prob = cp.Problem(cp.Minimize(t_epi), constraints)

    # 6. Solve with CLARABEL or fallback to SCS (Part 5)
    requested_solver = solver.upper()
    actual_solver = requested_solver
    primary_solver_error = None
    fallback_solver_status = None
    solver_status = "unsolved"
    surrogate_obj = float("inf")

    try:
        if requested_solver == "CLARABEL":
            prob.solve(solver=cp.CLARABEL, tol_gap_abs=1e-4, tol_gap_rel=1e-4, tol_feas=1e-4)
            solver_status = prob.status
            if solver_status not in ["optimal", "optimal_inaccurate"]:
                primary_solver_error = f"Non-optimal status from CLARABEL: {solver_status}"
                actual_solver = "SCS (fallback)"
                try:
                    prob.solve(solver=cp.SCS, eps_abs=1e-4, eps_rel=1e-4)
                    fallback_solver_status = prob.status
                    solver_status = prob.status
                    surrogate_obj = float(prob.value) * F_scale if prob.value is not None else float("inf")
                except Exception as e2:
                    fallback_solver_status = f"error: {str(e2)}"
                    solver_status = f"error: {str(e2)}"
            else:
                surrogate_obj = float(prob.value) * F_scale if prob.value is not None else float("inf")
        elif requested_solver == "SCS":
            prob.solve(solver=cp.SCS, eps_abs=1e-4, eps_rel=1e-4)
            solver_status = prob.status
            surrogate_obj = float(prob.value) * F_scale if prob.value is not None else float("inf")
        else:
            prob.solve(solver=solver)
            solver_status = prob.status
            surrogate_obj = float(prob.value) * F_scale if prob.value is not None else float("inf")
    except Exception as e:
        primary_solver_error = str(e)
        if requested_solver == "CLARABEL":
            actual_solver = "SCS (fallback)"
            try:
                prob.solve(solver=cp.SCS, eps_abs=1e-4, eps_rel=1e-4)
                fallback_solver_status = prob.status
                solver_status = prob.status
                surrogate_obj = float(prob.value) * F_scale if prob.value is not None else float("inf")
            except Exception as e2:
                fallback_solver_status = f"error: {str(e2)}"
                solver_status = f"error: {str(e2)}"
        else:
            solver_status = f"error: {str(e)}"

    # 7. Exact-Objective Acceptance Safeguard (Part C9)
    q_candidate = None
    if solver_status in ["optimal", "optimal_inaccurate"] and q_var.value is not None:
        q_candidate = np.array(q_var.value, dtype=float)

    accepted = False
    rejection_reason = ""
    max_viol = 0.0
    F_new = float("inf")

    if q_candidate is None or not np.all(np.isfinite(q_candidate)):
        accepted = False
        rejection_reason = f"Solver failed or returned non-finite values (status: {solver_status})"
        q_next = np.copy(q_curr)
    else:
        # Check kinematic feasibility and trust region
        kin_viol_start = float(np.linalg.norm(q_candidate[0] - config.q_0))
        kin_viol_end = float(np.linalg.norm(q_candidate[-1] - config.q_F))
        displacements = np.linalg.norm(q_candidate[1:] - q_candidate[:-1], axis=1)
        kin_viol_disp = float(np.max(displacements) - config.max_displacement)
        shift_slots = np.linalg.norm(q_candidate - q_curr, axis=1)
        kin_viol_shift = float(np.max(shift_slots) - step_max)
        max_viol = max(kin_viol_start, kin_viol_end, max(0.0, kin_viol_disp), max(0.0, kin_viol_shift))

        if max_viol > 1e-3:
            accepted = False
            rejection_reason = f"Kinematic or trust-region constraint violation ({max_viol:.4e} > 1e-3)"
            q_next = np.copy(q_curr)
        else:
            # Evaluate proposed trajectory using exact channel and MSE evaluator
            _, h_mag_new = compute_cascaded_channel(q_candidate, users, beta_vec, config, mu_tilde=mu_tilde)
            mse_new_slots, F_new = compute_aircomp_mse(p, h_mag_new, eta, config.sigma2, N)

            # Accept only if exact worst-slot MSE is non-increasing within numerical tolerance
            if F_new <= F_old + 1e-9:
                accepted = True
                q_next = q_candidate
                rejection_reason = f"Accepted: exact worst MSE improved or preserved ({F_new:.6e} <= {F_old:.6e})"
            else:
                accepted = False
                q_next = np.copy(q_curr)
                rejection_reason = f"Rejected: exact worst MSE increased ({F_new:.6e} > {F_old:.6e})"

    diag = {
        "accepted": accepted,
        "requested_solver": requested_solver,
        "actual_solver": actual_solver,
        "primary_solver_error": primary_solver_error,
        "fallback_solver_status": fallback_solver_status,
        "solver_status": solver_status,
        "surrogate_objective": surrogate_obj,
        "old_exact_worst_mse": float(F_old),
        "new_exact_worst_mse": float(F_new) if accepted else float(F_old),
        "candidate_exact_worst_mse": float(F_new),
        "max_kinematic_violation": max_viol,
        "reason": rejection_reason,
    }
    return q_next, diag
