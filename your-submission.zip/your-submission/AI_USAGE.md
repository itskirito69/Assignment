# AI Usage

## How AI Was Used
Gemini/Antigravity was used as an engineering assistant for:
*   repository/file inspection,
*   explaining unfamiliar Python/NLP concepts,
*   executing reproducible commands,
*   writing temporary experiment scripts,
*   preparing the FLORES corpus,
*   tokenizer comparisons,
*   denominator analysis,
*   benchmark calculations,
*   Part C resource analysis,
*   creating submission artifacts,
*   running reproducibility checks.

The human-controlled process required hypotheses formulation, experiment selection, evidence review, and explicit acceptance/rejection of AI claims.

## Where AI Helped
Concrete examples of AI assistance include:
1.  **Baseline execution:** Running the baseline `fertility.py` script and parsing outputs for reproducibility checks.
2.  **Experimental scripts:** Rapid creation of temporary Python scripts to test theories (e.g., lowercasing, string splitting, denominator permutations).
3.  **Tokenizer comparison:** Writing scripts to compare token counts between GPT-2 and XLM-RoBERTa.
4.  **FLORES extraction:** Writing the `fetch_corpus.sh` bash pipeline to securely download, extract, and verify the aligned corpus.
5.  **Part B math:** Executing KV-cache arithmetic and reconciling benchmark log values (goodput vs. wall-clock time).
6.  **Part C planning:** Constructing the decision matrix and reviewer-budget arithmetic.
7.  **Final assembly:** Generating the final structured artifacts based on validated frozen numbers.

## Where AI Was Wrong or Overconfident
The following mistakes and over-claims were observed during the investigation and subsequently corrected:

1.  **IndicBERT accessibility:** AI initially described `ai4bharat/indic-bert` as openly accessible, but an actual load attempt showed the repository required authentication. This caused a pivot to XLM-R.
2.  **Empty-line hypothesis:** AI initially characterized empty-line skipping as an alignment bug inside `fertility.py`. On inspection, the script processes each language independently and does not align lines across languages, so that claim was rejected.
3.  **Aggregation overclaim:** AI initially treated the averaging issue as potentially the main flaw. The controlled experiment showed a small effect relative to the main tokenizer effect.
4.  **Special-token false alarm:** AI treated `add_special_tokens=False` as suspicious before verification. The experiment showed that explicitly excluding injected sequence-boundary tokens was appropriate for the intended measurement.
5.  **Metric/cost overclaim:** AI initially made stronger claims linking tokenizer fertility directly to serving cost than the evidence justified. The analysis was revised to distinguish tokenizer workload from actual production cost.
6.  **Causal overclaim in Part B:** AI initially used stronger language about preemption proving internal scheduler recomputation. The final wording was softened to what the supplied log actually supports.
7.  **Premature rounding:** An earlier calculation used rounded goodput values and produced -19.22% instead of the later precise -19.21%. This was caught and corrected by recalculating from the underlying unrounded values.
8.  **Part C GPT-2 harness:** AI used GPT-2 as a structural stand-in for the Part C experiment. The resulting Hindi/Kannada outputs were unusable for linguistic evaluation, so the outputs were explicitly rejected as quality evidence and retained only as a harness-structure test.
9.  **Unsupported assumptions:** AI occasionally proposed precise training/latency claims for an unavailable FLM-4B model. Those were removed or relabeled as assumptions/ranges rather than presented as measured facts.

## Human Oversight
Human oversight ensured that:
*   Original starter files were preserved unchanged;
*   Experiments were run in controlled temporary scripts;
*   AI-generated hypotheses were treated as hypotheses until experimentally verified;
*   Contradictory or unsupported AI claims were rejected;
*   Validated numbers were frozen before final assembly;
*   Final conclusions were bounded strictly by the supplied evidence.

## Important Reproducibility Note
Exploratory scripts were kept outside the final submission when appropriate, while clean reproducible Part A/Part B scripts were created for the final repository. 

AI was used extensively as a coding, analysis, and reasoning assistant, but experimental evidence and final conclusions were accepted only after independent inspection and reproducibility checks.
