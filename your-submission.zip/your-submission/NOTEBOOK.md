# Laboratory Notebook

This notebook documents the chronological investigation sequence, including hypotheses, experiments, dead ends, and revisions.

---

### Early Part A

## 1. Baseline Reproduction
**Question/Hypothesis:** Can we reproduce the intern’s reported 5.89x token penalty for Hindi?
**Action:** Ran the unmodified `fertility.py` on the provided `eng_sample.txt` and `hin_sample.txt`.
**Evidence/Result:** The script output 5.89x exactly as reported.
**Interpretation:** The baseline behavior is reproducible on the starter kit files.
**Decision/Revision:** Proceed to a forensic audit of the script to identify any underlying causes or bugs.
**AI contribution:** Executed the script and parsed the output.

## 2. Aggregation Hypothesis and Experiment
**Question/Hypothesis:** Is per-line averaging mathematically skewing the overall tokens-per-word ratio?
**Action:** Conducted a temporary pooled-calculation experiment to compare average-of-ratios against pooled totals across the sample.
**Evidence/Result:** The aggregation difference was small, and the large Hindi/English gap remained.
**Interpretation:** Averaging is a statistical flaw, but it is not the primary driver of the anomaly.
**Decision/Revision:** Note the flaw for correction, but continue searching for the main cause.
**AI contribution:** Proposed the hypothesis and built the temporary test.
**AI issue caught:** AI overclaimed that some hypotheses (such as empty-line skipping desynchronizing languages inside fertility.py) were confirmed bugs before they were measured.

---

### Mid Part A

## 3. Tokenizer Candidate Investigation
**Question/Hypothesis:** Is GPT-2’s western-biased vocabulary causing extreme subword fragmentation for Indic languages?
**Action:** Searched HuggingFace for multilingual tokenizer candidates.
**Evidence/Result:** Identified XLM-RoBERTa (XLM-R) and IndicBERT as strong candidates.
**Interpretation:** Testing a multilingual tokenizer might reveal if the penalty is model-dependent rather than language-dependent.
**Decision/Revision:** Compare GPT-2 against a multilingual tokenizer.
**AI contribution:** Suggested XLM-R and IndicBERT candidates.

## 4. IndicBERT Gated-Repo Discovery
**Question/Hypothesis:** Can we test IndicBERT directly to observe tokenizer efficiency?
**Action:** Attempted to load `ai4bharat/indic-bert` in our test harness.
**Evidence/Result:** Failed; the repository required authentication.
**Interpretation:** IndicBERT is not accessible within the current constraints.
**Decision/Revision:** Pivot entirely to using `xlm-roberta-base`.
**AI contribution:** Attempted to load the model programmatically.
**AI issue caught:** Incorrect assumption that IndicBERT was an ungated/open repository before attempting to execute the load.

## 5. GPT-2 vs XLM-R Exploratory Comparison
**Question/Hypothesis:** How does XLM-R compare to GPT-2 on the Hindi sample?
**Action:** Tokenized the initial unaligned samples using both tokenizers.
**Evidence/Result:** XLM-R massively reduced the Hindi token count (by ~80%).
**Interpretation:** The GPT-2 tokenizer is the primary cause of the inflated token penalty.
**Decision/Revision:** Proceed with XLM-R as the comparison standard for the corrected pipeline.
**AI contribution:** Built the comparison script.
**AI issue caught:** Made overstrong claims about tokenizer/cost conclusions before the corrected analysis with proper denominators was completed.

## 6. Special-Token Verification
**Question/Hypothesis:** Does suppressing special tokens (`add_special_tokens=False`) artificially skew the results?
**Action:** Audited `fertility.py`'s `add_special_tokens=False` parameter.
**Evidence/Result:** By excluding tokenizer-added sequence-boundary special tokens, the script measures text tokens rather than injected sentence-boundary tokens.
**Interpretation:** Suppressing special tokens is analytically correct when measuring raw vocabulary fertility.
**Decision/Revision:** Keep `add_special_tokens=False` in our final pipeline.
**AI contribution:** Audited the parameter.
**AI issue caught:** Overcalled the hypothesis as a confirmed "suspicious bug" before measurement and user correction.

---

### Late Part A

## 7. 4-Language FLORES Corpus Construction
**Question/Hypothesis:** How do we get a semantically fair, cross-lingual dataset for English, Hindi, Kannada, and Tamil?
**Action:** Wrote `fetch_corpus.sh` to download and extract the FLORES-200 devtest parallel corpus.
**Evidence/Result:** Extracted 1,012 corresponding FLORES-200 devtest sentences per language; line counts matched and sampled positions were sanity-checked.
**Interpretation:** This provides a controlled, aligned parallel dataset.
**Decision/Revision:** Use the FLORES corpus as the definitive source of truth instead of the unaligned starter samples.
**AI contribution:** Wrote the bash download script.

## 8. Denominator Experiment
**Question/Hypothesis:** Are "words" or "code-points" a valid cross-lingual denominator?
**Action:** Calculated tokens per word, character, grapheme, and sentence across the aligned corpus.
**Evidence/Result:** Words and characters varied wildly by language morphology and encoding (e.g., Kannada agglutination).
**Interpretation:** Morphological differences make words and characters unreliable units of constant semantic meaning.
**Decision/Revision:** Among the evaluated denominators, tokens per aligned parallel sentence was selected as the primary normalization for this controlled cross-language comparison.
**AI contribution:** Executed the denominator sweep.

## 9. Full fertility.py Forensic Audit
**Question/Hypothesis:** What exactly was wrong in `fertility.py`?
**Action:** Reviewed all code lines against our accumulated findings.
**Evidence/Result:** Identified the `split(" ")` behavior, lowercasing, aggregation flaw, wrong denominator, and tokenizer choice.
**Interpretation:** The original script compounded multiple distortions.
**Decision/Revision:** Compile findings into a structured `audit.md` report.
**AI contribution:** Drafted the audit document.

## 10. Repeated-Space Experiment
**Question/Hypothesis:** Why did the word-count denominator in Hindi differ from standard tools?
**Action:** Investigated `line.split(" ")` using a dedicated `test_split.py` script.
**Evidence/Result:** Discovered that repeated spaces in the evaluation corpus cause split(' ') to count empty strings as words; this was especially material for Kannada, with smaller effects in Hindi and Tamil.
**Interpretation:** The empty fields artificially inflated the whitespace-word denominator, with the largest measured effect in Kannada.
**Decision/Revision:** Switch to whitespace-aware `split()` for accurate word counting in the corrected script.
**AI contribution:** Analyzed the string splitting behavior.

## 11. Lowercasing Experiment
**Question/Hypothesis:** Does `line.lower()` distort token counts?
**Action:** Created `test_lower.py` to test tokenizing with and without `.lower()`.
**Evidence/Result:** Caused a minor 1–3% shift in English subword fragmentation; no measurable effect on Brahmic scripts.
**Interpretation:** It is bad practice for named entities, but it was not the primary driver of the anomaly.
**Decision/Revision:** Exclude lowercasing from the corrected pipeline to preserve native orthography.
**AI contribution:** Ran the test and quantified the shift.

## 12. Counterfactual Impact Analysis
**Question/Hypothesis:** What is the true token penalty when using XLM-R and parallel sentences?
**Action:** Ran the full corrected pipeline.
**Evidence/Result:** The Hindi ratio dropped from 7.42x to ~1.25x (an 80% token reduction). Kannada/Tamil dropped to ~1.35x.
**Interpretation:** The analysis established a controlled comparison of tokenizer-induced token workload using aligned sentences.
**Decision/Revision:** The evidence supports considering a multilingual tokenizer/model for Indic traffic, with deployment validation still required.
**AI contribution:** Wrote the analytical pipeline.

## 13. Corrected A3 Analysis Construction
**Question/Hypothesis:** Can we produce a clean final script that outputs all corrected values deterministically?
**Action:** Created `corrected_analysis.py`.
**Evidence/Result:** Successfully produced the exact values used for the headline numbers.
**Interpretation:** The pipeline is stable and deterministic.
**Decision/Revision:** Use this as the final Part A evidence.
**AI contribution:** Generated the python script.
**AI issue caught:** Unnecessary warning suppression (`warnings.filterwarnings`) was included in the final analysis code and had to be removed.

## 14. Reproducibility Validation
**Question/Hypothesis:** Does the script run cleanly without altering the starter files?
**Action:** Ran the script in a clean submission directory.
**Evidence/Result:** Exact match with frozen evidence.
**Interpretation:** The Part A evidence is finalized.
**Decision/Revision:** Lock Part A evidence.
**AI contribution:** Executed the verification.

---

### Early Part B

## 15. Part B KV-Cache Calculation
**Question/Hypothesis:** How many 4096-token sequences can fit in the L4's KV cache?
**Action:** Extracted specs from `model_spec.md` and calculated FP16 tensor sizes.
**Evidence/Result:** The remaining memory budget accommodates approximately 25 concurrent 4096-token sequences.
**Interpretation:** Physical capacity acts as a ceiling on concurrency.
**Decision/Revision:** Use ~25 sequences as the capacity threshold hypothesis.
**AI contribution:** Performed the arithmetic.

---

### Mid Part B

## 16. B2 Long-Context Anomaly Analysis
**Question/Hypothesis:** Why does throughput collapse at batch sizes 32 and 48?
**Action:** Audited `bench_log.csv`.
**Evidence/Result:** KV utilization reached 0.97 and preempted sequences first appeared at batch 32, after the theoretical estimate of approximately 25 concurrent 4096-token sequences.
**Interpretation:** The observed onset of preemption at batch 32, with no preemption at batch 24, is consistent with the estimated capacity.
**Decision/Revision:** Conclude that the observed KV-cache saturation and onset of preemption strongly support KV-cache pressure/preemption as the mechanism behind the throughput degradation.
**AI contribution:** Correlated the metrics.

## 17. B3 Goodput Derivations
**Question/Hypothesis:** What is the true generated-token goodput, and how was `reported_tok_s` calculated?
**Action:** Derived true goodput using two independent methods (wall time vs prefill ratio).
**Evidence/Result:** 
- Method 1: (24 × 512) / 61.16 = 200.92 tok/s
- Method 2: 1607.40 × [512 / (3584 + 512)] = 200.925 tok/s
They agree to rounding.
**Interpretation:** `reported_tok_s` includes both prompt and generated tokens and therefore does not represent generated-token goodput for this workload.
**Decision/Revision:** Invalidate the intern's "longer prompts = higher throughput" conclusion.
**AI contribution:** Derived the formulas.
**AI issue caught:** Premature rounding during scratchpad calculations produced a Batch-48 drop of -19.22%, before it was later corrected to the precise underlying value of -19.21%.

---

### Late Part B

## 18. B4 Mechanism Analysis
**Question/Hypothesis:** What specific metric confirms the mechanism?
**Action:** Identified preempted_seqs as the most direct mechanism-related counter available in the supplied log.
**Evidence/Result:** BS=24 had 0 preemptions, while BS=48 had 23.
**Interpretation:** Its onset and increase coincide with KV-cache saturation and goodput degradation.
**Decision/Revision:** Rely on `preempted_seqs` as the core evidence.
**AI contribution:** Highlighted the mechanism metrics.

## 19. Batch-24 Counterfactual
**Question/Hypothesis:** What is the optimal deployment configuration for this long-context workload?
**Action:** Compared BS 24 to 32 and 48 using the unrounded goodput calculations.
**Evidence/Result:** BS 24 maximizes goodput (~200 tok/s) without triggering preemption.
**Interpretation:** Increasing batch size past 24 destroys goodput.
**Decision/Revision:** Recommend capping concurrency at 24.
**AI contribution:** Calculated the goodput degradation.

---

### Early Part C

## 20. Part C Option Analysis
**Question/Hypothesis:** Which tone adaptation method (Prompt, Rewriter, SFT) is feasible under strict constraints?
**Action:** Built a resource matrix comparing reviewer budget (20 hours), compute (2 weeks), and latency.
**Evidence/Result:** Prompting has the shortest time-to-first-result and the lowest additional infrastructure burden under the stated constraints, making it the preferred initial strategy while preserving SFT as an escalation path.
**Interpretation:** Proceeding with prompt engineering maximizes information gained per unit of time.
**Decision/Revision:** Select Option C as the preferred initial strategy.
**AI contribution:** Constructed the decision matrix.

---

### Mid Part C

## 21. GPT-2 Harness Limitation
**Question/Hypothesis:** Can we evaluate prompt outputs using the available model?
**Action:** Generated dummy outputs using GPT-2 as a structural placeholder.
**Evidence/Result:** GPT-2 outputs were uninterpretable garbage in Indic languages.
**Interpretation:** The outputs lack linguistic value for evaluating casualness.
**Decision/Revision:** Treat the JSONL purely as a structural test harness, not as linguistic evidence.
**AI contribution:** Generated the JSONL structure.
**AI issue caught:** Use of GPT-2 as a Part C stand-in whose outputs were correctly rejected as linguistic evidence.

---

### Final Part C

## 22. Part C Reviewer Protocol
**Question/Hypothesis:** How do we quantitatively gate the prompt engineering experiment?
**Action:** Created an evaluation rubric (Casualness 1-5, Meaning 0/1) and a kill criterion.
**Evidence/Result:** Proposed gate: >=80% success by Day 3 to continue prompt-only development.
**Interpretation:** This provides a constrained evaluation protocol that mitigates deployment risk.
**Decision/Revision:** Draft the final recommendation memo.
**AI contribution:** Drafted the protocol.

---

## Evidence Freeze
Parts A and B were frozen after reproducibility validation. Subsequent work should not alter their validated numbers without an explicitly documented new experiment.
