def main():
    print("--- Part B1: KV-Cache Calculation ---")
    gpu_memory_gb = 24
    gpu_memory_utilization = 0.92
    params = 4.2e9
    fp16_bytes = 2
    layers = 28
    kv_heads = 8
    head_dim = 128
    kv_factor = 2 # K and V
    non_kv_overhead_gb = 1.6
    seq_len = 4096
    
    kv_bytes_per_token = layers * kv_heads * head_dim * kv_factor * fp16_bytes
    print(f"1. KV bytes/token: {kv_bytes_per_token} bytes ({kv_bytes_per_token / 1024} KiB)")
    
    kv_bytes_per_seq = kv_bytes_per_token * seq_len
    print(f"2. KV bytes for one 4096-token sequence: {kv_bytes_per_seq} bytes (~{kv_bytes_per_seq / (1024**2):.2f} MiB)")
    
    serving_memory_budget_gb = gpu_memory_gb * gpu_memory_utilization
    print(f"3. Serving memory budget: {serving_memory_budget_gb:.2f} GB")
    
    model_weight_memory_gb = (params * fp16_bytes) / 1e9
    print(f"4. Model weight memory: {model_weight_memory_gb:.2f} GB")
    
    remaining_kv_budget_gb = serving_memory_budget_gb - model_weight_memory_gb - non_kv_overhead_gb
    print(f"5. Remaining KV-cache budget: {remaining_kv_budget_gb:.2f} GB")
    
    # 1 GB = 1e9 bytes
    max_seqs = (remaining_kv_budget_gb * 1e9) / kv_bytes_per_seq
    print(f"6. Approximate number of concurrent 4096-token sequences: {max_seqs:.1f} (~25 sequences)")
    
    print("\n--- Part B3: Goodput for Batch 24 ---")
    batch_size = 24
    prompt_len = 3584
    gen_len = 512
    wall_clock_s = 61.16
    reported_tok_s = 1607.40
    
    prompt_tokens = batch_size * prompt_len
    generated_tokens = batch_size * gen_len
    total_processed_tokens = prompt_tokens + generated_tokens
    
    print(f"1. Prompt tokens: {prompt_tokens}")
    print(f"2. Generated tokens: {generated_tokens}")
    print(f"3. Total processed tokens: {total_processed_tokens}")
    
    reconstructed_reported = total_processed_tokens / wall_clock_s
    print(f"4. Reconstructed reported_tok_s: {reconstructed_reported:.2f} tok/s")
    
    goodput_method1 = (batch_size * gen_len) / wall_clock_s
    print(f"5. Honest goodput (Method 1): {goodput_method1:.2f} tok/s")
    
    goodput_method2 = reported_tok_s * gen_len / (prompt_len + gen_len)
    print(f"6. Honest goodput (Method 2): {goodput_method2:.3f} tok/s")
    print(f"   Difference between methods: {abs(goodput_method1 - goodput_method2):.4f} tok/s")
    
    print("\n--- Part B2: Validation of Long-Context Rows ---")
    rows = [
        {"batch": 24, "wall": 61.16, "reported": 1607.40, "preemptions": 0, "kv_util": 0.93},
        {"batch": 32, "wall": 94.71, "reported": 1384.00, "preemptions": 7, "kv_util": 0.97},
        {"batch": 48, "wall": 151.41, "reported": 1298.50, "preemptions": 23, "kv_util": 0.97},
    ]
    
    baseline_goodput = None
    for r in rows:
        bs = r["batch"]
        wall = r["wall"]
        # goodput = (bs * gen_len) / wall
        goodput = (bs * 512) / wall
        if bs == 24:
            baseline_goodput = goodput
            pct_change = 0.0
        else:
            pct_change = ((goodput - baseline_goodput) / baseline_goodput) * 100
            
        print(f"Batch {bs}: Goodput = {goodput:.2f} tok/s, Change vs Batch 24 = {pct_change:.2f}%")

if __name__ == "__main__":
    main()
