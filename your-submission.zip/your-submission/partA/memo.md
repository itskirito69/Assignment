# Part A4 Recommendation Memo

**To:** Engineering Team
**From:** Language Modeling Group
**Subject:** Correction of Indic Language Tokenization Penalty & Routing Recommendation

### Corrected Headline Findings
The initial report estimating a 5.89x token penalty for Hindi was conceptually flawed and mathematically distorted. By utilizing an aligned parallel corpus (FLORES-200) and replacing the flawed words/characters denominators with the semantically controlled **tokens per aligned parallel sentence**, we present the true token overhead for processing Indic languages.

**Tokens per Aligned Sentence (GPT-2):**
*   **English:** 26.72 tok/sentence (Baseline 1.00x)
*   **Hindi:** 198.31 tok/sentence (7.42x penalty)
*   **Kannada:** 363.01 tok/sentence (13.58x penalty)
*   **Tamil:** 415.19 tok/sentence (15.54x penalty)

The massive 7x–15x token penalty is **not** an inherent trait of Indic languages; it is an artifact of the GPT-2 tokenizer's byte-fallback architecture, which severely fragments non-Latin scripts. 

When routed through a multilingual tokenizer (**XLM-R**), this penalty nearly vanishes, yielding massive token reductions:
*   **Hindi:** 80.96% token reduction (New relative ratio: 1.25x)
*   **Kannada:** 88.71% token reduction (New relative ratio: 1.35x)
*   **Tamil:** 90.16% token reduction (New relative ratio: 1.35x)

### Routing Recommendation
Do **not** use GPT-2 (or models strictly bound to its vocabulary) for processing Hindi, Kannada, or Tamil traffic. The subword fragmentation will severely degrade throughput and inflate compute costs. We strongly recommend routing all Indic language traffic to models utilizing multilingual tokenizers (e.g., XLM-R) where the token overhead is a highly manageable ~1.3x relative to English.

### Biggest Caveat
**The FLORES-200 devtest is a highly controlled, professionally translated parallel corpus, and is not representative of live production traffic.** Real-world user queries contain heavy code-mixing (e.g., "Hinglish"), transliteration, informal slang, and formatting errors that parallel news/wiki datasets do not capture. The exact 1.3x ratio will likely drift in the wild.

### Production Monitoring Metric
To track true serving costs and identify tokenization inefficiencies in the wild, do not monitor tokens-per-word or tokens-per-character. The primary telemetry metric must be:
**Total Processed Tokens Per Real Request, Segmented by Language.**
