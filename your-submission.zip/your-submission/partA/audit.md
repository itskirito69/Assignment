# Technical Audit of `fertility.py`

This audit details the forensic investigation into the baseline script `fertility.py` which originally reported a 5.89x "fertility ratio" for Hindi relative to English. 

## Confirmed Code-Level Issue

### `split(" ")` Counts Empty Fields
*   **Original Code:** `words = line.split(" ")`
*   **Evidence:** The use of `split(" ")` is technically incorrect because it blindly splits on every space character. When a sentence contains repeated spaces, this creates empty string elements `""` that are falsely counted as "words" in the denominator.
*   **Direction/Magnitude:** English had 0% measured effect. Hindi had approximately 0.02% pooled tok/word effect. Kannada had the largest measured effect at approximately 2.34%, and Tamil had approximately 0.60%. The bug therefore changes the denominator and understates fertility, with the largest measured impact in Kannada. This code-level issue is real but is NOT the main reason for the large Indic tokenization gap.

## Confirmed Conceptual/Metric Issue

### Incorrect Denominators for Routing/Cost Proxies
*   **Original Code:** Used "whitespace-delimited words" and "characters" (code-points) as the denominators for comparing cross-lingual workload.
*   **Evidence:** Whitespace-delimited words are morphologically distinct across languages (e.g., highly agglutinative languages like Kannada encode entire phrases into single "words" without spaces). Furthermore, Unicode code points and UTF-8 bytes are heavily encoding-dependent; complex Brahmic scripts require multiple code-points/bytes just to render a single visual consonant cluster.
*   **Conclusion:** Using words or characters as a cross-lingual denominator fundamentally misrepresents the semantic workload. The only valid, controlled denominator for routing decisions is the **aligned parallel sentence**, which holds semantic meaning constant across translations.

## Tokenizer-Dependence Finding

*   **Evidence:** The massive inflation in token overhead for Indic languages is overwhelmingly a property of the specific tokenizer chosen, not an inherent language trait. 
*   **Magnitude:** When switching from GPT-2 (a byte-fallback tokenizer heavily biased toward Western text) to XLM-R (a multilingual SentencePiece tokenizer), the token penalty nearly vanishes:
    *   **Hindi:** 80.96% reduction in total tokens.
    *   **Kannada:** 88.71% reduction in total tokens.
    *   **Tamil:** 90.16% reduction in total tokens.

## Measured but Non-Decision-Critical Issues

### Per-Line Averaging vs. Pooled Ratios
*   **Original Code:** Calculated tokens/word for each line, then averaged those line-level ratios.
*   **Evidence:** This method mathematically skews results by giving disproportionate weight to very short sentences. We replaced this with a mathematically rigorous pooled calculation (Total Tokens / Total Words).
*   **Impact:** This was a measurable distortion, but its overall numerical impact on the headline ratio was negligible compared to the tokenizer architecture.

### Lowercasing
*   **Original Code:** `line = line.lower()`
*   **Evidence:** Lowercasing non-Latin scripts (which lack capitalization) has no effect, but lowercasing English collapses distinct capitalized tokens into subwords differently.
*   **Impact:** We observed a minor 1-3% shift in token counts. It is poor practice for named entities, but it was not the driver of the 6x-15x discrepancy.

## Suspicious but Correct Behavior

*   **`add_special_tokens=False`:** In typical NLP tasks, `[CLS]` and `[SEP]` tokens are added automatically. Suppressing them here is analytically correct because we want to measure the raw vocabulary fertility (subword fragmentation) of the text, not pad the counts with static meta-tokens.
*   **NFC Normalization:** Using `unicodedata.normalize("NFC", line)` ensures characters like "é" are represented consistently as single precomposed characters rather than combined marks, which is crucial for fair byte-level processing.

## False Lead / Rejected Finding

*   **Skipping Empty Lines (`if not line: continue`)**: It was hypothesized that stripping empty lines in a parallel corpus would "desynchronize" the line alignment. This is **not a bug** in `fertility.py`. The script processes each language independently to generate aggregate ratios; it does not map `line[i]` in English to `line[i]` in Hindi, so alignment desynchronization is irrelevant.

## CLI-Order Baseline Weakness

*   **Original Code:** The baseline 1.0x ratio was arbitrarily assigned to the *first* file passed as an argument in the CLI. 
*   **Evidence:** This is a design weakness, not a numerical bug, but it means the script's output is fundamentally brittle and heavily dependent on user input order rather than a programmatic standard.
