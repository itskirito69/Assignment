#!/bin/bash
set -euo pipefail

CORPUS_DIR="your-submission/partA/corpus"
mkdir -p "$CORPUS_DIR"
LANGS=("eng_Latn" "hin_Deva" "kan_Knda" "tam_Taml")
EXPECTED_LINES=1012

# 1. Check if a valid corpus already exists
all_valid=true
for lang in "${LANGS[@]}"; do
    FILE="$CORPUS_DIR/${lang}.txt"
    if [ ! -f "$FILE" ]; then
        all_valid=false
        break
    fi
    lines=$(wc -l < "$FILE" | tr -d ' ')
    if [ "$lines" -ne "$EXPECTED_LINES" ]; then
        all_valid=false
        break
    fi
done

if [ "$all_valid" = true ]; then
    echo "Validated corpus already exists. Skipping download."
    exit 0
fi

echo "Valid corpus missing or incomplete. Downloading FLORES-200 dataset..."

# 2. Use a temporary directory for safe extraction
TEMP_DIR=$(mktemp -d)
trap 'rm -rf "$TEMP_DIR"' EXIT

curl -L -s -o "$TEMP_DIR/flores200_dataset.tar.gz" https://dl.fbaipublicfiles.com/nllb/flores200_dataset.tar.gz

echo "Extracting evaluation languages..."
tar -xzf "$TEMP_DIR/flores200_dataset.tar.gz" -C "$TEMP_DIR" flores200_dataset/devtest/eng_Latn.devtest
tar -xzf "$TEMP_DIR/flores200_dataset.tar.gz" -C "$TEMP_DIR" flores200_dataset/devtest/hin_Deva.devtest
tar -xzf "$TEMP_DIR/flores200_dataset.tar.gz" -C "$TEMP_DIR" flores200_dataset/devtest/kan_Knda.devtest
tar -xzf "$TEMP_DIR/flores200_dataset.tar.gz" -C "$TEMP_DIR" flores200_dataset/devtest/tam_Taml.devtest

echo "Verifying downloaded line counts before replacing..."
for lang in "${LANGS[@]}"; do
    EXTRACTED_FILE="$TEMP_DIR/flores200_dataset/devtest/${lang}.devtest"
    if [ ! -f "$EXTRACTED_FILE" ]; then
        echo "ERROR: Missing extracted file $EXTRACTED_FILE"
        exit 1
    fi
    lines=$(wc -l < "$EXTRACTED_FILE" | tr -d ' ')
    if [ "$lines" -ne "$EXPECTED_LINES" ]; then
        echo "ERROR: File $EXTRACTED_FILE has $lines lines, expected $EXPECTED_LINES."
        exit 1
    fi
done

echo "Verification successful. Safely moving to final destination..."
for lang in "${LANGS[@]}"; do
    mv "$TEMP_DIR/flores200_dataset/devtest/${lang}.devtest" "$CORPUS_DIR/${lang}.txt"
done

echo "Corpus downloaded and verified successfully."
