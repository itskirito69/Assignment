import os
import unicodedata
import tiktoken
from transformers import AutoTokenizer
import grapheme

def read_lines(path):
    with open(path, "r", encoding="utf-8") as f:
        lines = []
        for raw in f:
            line = raw.strip()
            if not line: continue
            line = unicodedata.normalize("NFC", line)
            # DO NOT lowercase to preserve proper nouns and native orthography
            lines.append(line)
        return lines

def run_experiment():
    langs = ["eng_Latn", "hin_Deva", "kan_Knda", "tam_Taml"]
    # Path relative to the script's execution
    corpus_dir = os.path.join(os.path.dirname(__file__), "corpus")
    
    lang_lines = {l: read_lines(os.path.join(corpus_dir, f"{l}.txt")) for l in langs}
    
    # Calculate denominators
    denoms = {}
    for l in langs:
        lines = lang_lines[l]
        sentences = len(lines)
        # Use split() for whitespace-aware word counting to prevent counting empty fields
        words = sum(len(line.split()) for line in lines)
        codepoints = sum(len(line) for line in lines)
        graphemes = sum(grapheme.length(line) for line in lines)
        utf8_bytes = sum(len(line.encode("utf-8")) for line in lines)
        
        denoms[l] = {
            "sentences": sentences,
            "words": words,
            "codepoints": codepoints,
            "graphemes": graphemes,
            "bytes": utf8_bytes
        }
    
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    xlm_tok = AutoTokenizer.from_pretrained("xlm-roberta-base")
    tokenizers = {
        "gpt2": tiktoken.get_encoding("gpt2").encode,
        "xlm-roberta-base": lambda s: xlm_tok.encode(s, add_special_tokens=False)
    }
    
    results = {}
    for tok_name, encode_fn in tokenizers.items():
        results[tok_name] = {}
        print(f"\n================ Tokenizer: {tok_name} ================")
        
        for l in langs:
            lines = lang_lines[l]
            total_tokens = sum(len(encode_fn(line)) for line in lines)
            d = denoms[l]
            
            results[tok_name][l] = {
                "total_tokens": total_tokens,
                "tok_sent": total_tokens / d["sentences"],
                "tok_word": total_tokens / d["words"],
                "tok_cp": total_tokens / d["codepoints"],
                "tok_graph": total_tokens / d["graphemes"],
                "tok_byte": total_tokens / d["bytes"],
            }
            
            print(f"[{l}]")
            print(f"  Total input tokens: {total_tokens}")
            print(f"  Tokens per aligned sentence: {results[tok_name][l]['tok_sent']:.4f}")
            print(f"  Pooled tokens/word: {results[tok_name][l]['tok_word']:.4f}")
            print(f"  Pooled tokens/code-point: {results[tok_name][l]['tok_cp']:.4f}")
            print(f"  Pooled tokens/grapheme: {results[tok_name][l]['tok_graph']:.4f}")
            print(f"  Pooled tokens/UTF-8-byte: {results[tok_name][l]['tok_byte']:.4f}\n")
            
        eng_tok_sent = results[tok_name]["eng_Latn"]["tok_sent"]
        print(f"  --- English-Relative Tokens-Per-Sentence Ratios ({tok_name}) ---")
        for l in langs:
            ratio = results[tok_name][l]["tok_sent"] / eng_tok_sent
            print(f"  {l} / English ratio: {ratio:.4f}x")

    print("\n================ GPT-2 vs XLM-R Token Reduction ================")
    for l in langs:
        gpt_toks = results["gpt2"][l]["total_tokens"]
        xlm_toks = results["xlm-roberta-base"][l]["total_tokens"]
        pct_reduction = ((gpt_toks - xlm_toks) / gpt_toks) * 100
        print(f"[{l}]")
        print(f"  GPT-2 tokens: {gpt_toks}")
        print(f"  XLM-R tokens: {xlm_toks}")
        print(f"  Reduction: {pct_reduction:.2f}%")

if __name__ == "__main__":
    run_experiment()
