# AI/ML Hiring Assignment — Submission

## What this repository contains

This submission audits three areas:

1. Multilingual tokenizer-fertility claims.
2. LLM serving capacity and throughput claims.
3. A constrained product decision for casual-language adaptation.

The original starter kit is preserved separately and remains unchanged.

## Repository Structure

```text
your-submission/
├── README.md
├── NOTEBOOK.md
├── AI_USAGE.md
├── partA/
│   ├── audit.md
│   ├── corrected_analysis.py
│   ├── fetch_corpus.sh
│   ├── memo.md
│   └── corpus/
├── partB/
│   ├── answers.md
│   └── calculations.py
└── partC/
    ├── memo.md
    └── day1_experiment_protocol.md
```

## Key Findings

### Part A — Tokenizer Audit

GPT-2 produces very large Indic-language token workloads on the FLORES-200 evaluation corpus, while XLM-R dramatically reduces Indic token counts on the same parallel content.

For the controlled multilingual comparison, tokens per aligned parallel sentence was selected as the primary normalization because the sentences are aligned across languages. This is a controlled evaluation metric, not a universal compute or dollar-cost multiplier. For production, the recommended monitoring metric is total processed tokens per real request, segmented by language.

The original fertility implementation contains a confirmed word-counting issue: `split(" ")` counts empty fields created by repeated spaces as words. The largest measured distortion occurred in Kannada (≈2.34%).

Key validated metrics:
*   **GPT-2 Hindi Relative Ratio:** 7.4208x tokens/sentence vs English.
*   **XLM-R Hindi Relative Ratio:** 1.2466x tokens/sentence vs English.
*   **GPT-2 to XLM-R Token Reductions:** English 13.37%, Hindi 80.96%, Kannada 88.71%, Tamil 90.16%.

These results show that the large Indic tokenization overhead observed with GPT-2 is strongly dependent on tokenizer choice (GPT-2 vs XLM-R) and should not be described as a universal or fundamental property of the languages.

### Part B — Serving Capacity and Throughput

Under the supplied FLM-4B-Instruct and NVIDIA L4 assumptions, the approximate KV-cache capacity is about 25 concurrent 4096-token sequences.

The benchmark's `reported_tok_s` includes both prompt and generated tokens. It therefore does not represent generated-token goodput for the long-context workload. 

Honest generated-token goodput:
*   Batch 24: 200.92 tok/s
*   Batch 32: 172.99 tok/s
*   Batch 48: 162.31 tok/s (-19.21% relative to batch 24)

Preemption first appears at batch 32 in the supplied long-context sweep. The observed appearance and increase of preemptions together with KV-cache saturation strongly support KV-cache pressure and preemption as the mechanism behind the throughput degradation. Batch 24 is the best non-preempting operating point observed in the supplied long-context sweep.

### Part C — Casual Tone Adaptation

The preferred initial strategy is Option C: prompt engineering. The decision is risk-managed: run prompt engineering first, apply a quantitative reviewer gate, and escalate to SFT if the gate fails.

The reviewer budget is 20 reviewer-hours total. The proposed engineering success criterion is a >=80% success gate. If the 80% threshold is not reached by Day 3 (the kill criterion), stop prompt-only development and escalate to SFT evaluation.

Hindi and Kannada are the only native-speaker-reviewed languages. Tamil, Telugu, Bengali, and Marathi remain unvalidated deployment risks. Finally, no valid FLM-4B quality result is claimed (the GPT-2 Part C run was explicitly harness-only).

## Reproducing the Results

### Part A

```bash
bash your-submission/partA/fetch_corpus.sh
python3 your-submission/partA/corrected_analysis.py
```

### Part B

```bash
python3 your-submission/partB/calculations.py
```

## Evidence and Reproducibility Notes
*   The original starter files were kept unchanged.
*   Part A and Part B evidence was independently validated.
*   Validated numerical results were frozen before final assembly.
*   Clean scripts are included for reproducibility.
*   Exploratory scratch scripts were not treated as authoritative evidence.
*   Final conclusions are bounded by the supplied data, experiments, assumptions, and stated limitations.

## Important Limitations
*   FLORES-200 devtest is a controlled benchmark; tokenizer behavior depends strongly on tokenizer choice.
*   Tokens per aligned parallel sentence is an evaluation metric, not a production compute multiplier.
*   Native-speaker validation was limited to Hindi and Kannada.
*   The Part C 80% success threshold is an internal engineering assumption.
*   Batch 24 is the best observed point in the supplied long-context sweep, not a universal optimum.

## Assignment Artifacts
*   **Part A:** `audit.md` (forensic audit), `corrected_analysis.py` (clean analysis), `fetch_corpus.sh` (corpus preparation), `memo.md` (recommendation).
*   **Part B:** `calculations.py` (deterministic goodput), `answers.md` (benchmark analysis).
*   **Part C:** `memo.md` (product decision), `day1_experiment_protocol.md` (evaluation protocol).
*   `NOTEBOOK.md`: Chronological investigation record.
*   `AI_USAGE.md`: Statement of AI assistance and corrections.
