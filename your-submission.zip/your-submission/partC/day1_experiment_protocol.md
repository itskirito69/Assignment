# Part C: Day-1 Prompt Experiment Protocol

## Objective
Determine whether prompt engineering can make responses acceptably casual/conversational while preserving meaning.

## Test Languages
Hindi and Kannada only, because these are the languages covered by the available native-speaker reviewer.

## Experimental Design
- 3 prompt variants
- Same underlying inputs for every variant to allow controlled A/B comparison.
- Randomized/blinded presentation order for the reviewer to reduce bias.
- Baseline response plus each prompt variant.
- Do NOT present GPT-2 outputs as quality evidence.

## Reviewer Rubric
Casualness: 1–5
- 1 = formal/textbook
- 2 = somewhat formal
- 3 = acceptable casual/conversational
- 4 = clearly natural casual
- 5 = highly natural

Meaning preservation: 0/1
- 0 = factual/semantic issue
- 1 = meaning preserved

## Success & Kill Criteria

Proposed success criterion:
At least 80% of reviewed Hindi/Kannada outputs achieve:
- casualness >= 3
- meaning preservation = 1

Explicitly state:
The 80% threshold is an internal engineering assumption, not an externally validated product or industry standard.

Proposed kill criterion:
If the 80% threshold is not reached after prompt iteration by Day 3, stop prompt-only development and escalate to SFT evaluation.

## Reviewer Budget & Feasibility

Total:
10 hours/week × 2 weeks = 20 reviewer-hours = 1,200 minutes.

Day-1 design:
- 20 Hindi inputs
- 20 Kannada inputs
- 3 prompt variants
- 120 variant outputs total

At 3 minutes/output:
120 × 3 = 360 minutes = 6 hours.

State that this fits within the first week's 10-hour reviewer budget.

Also show the review capacity at:
- 1 minute/output = 1,200 outputs
- 2 minutes/output = 600 outputs
- 3 minutes/output = 400 outputs
- 5 minutes/output = 240 outputs

## Important Limitations

- Native-speaker validation covers Hindi and Kannada only.
- Tamil, Telugu, Bengali, and Marathi remain unvalidated deployment risks.
- No real FLM-4B-Instruct prompt-quality experiment has been completed because the actual checkpoint was unavailable.
- The earlier GPT-2 run was only a structural harness validation; its Indic outputs are not linguistic quality evidence.

## Prompt Variants

Include the three previously defined prompt variants:

Variant 1:
"Rewrite the following text to sound casual and conversational:"

Variant 2:
"Act as a helpful friend. Rewrite the following text in a natural, everyday tone:"

Variant 3:
"Make the following text sound less like a textbook and more like how real people talk:"

Also state that actual FLM-4B quality evaluation must use the real target model and native-speaker review.

Do NOT claim that prompting has already succeeded.
