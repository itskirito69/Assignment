# Part C — Casual Tone Adaptation Decision

## Recommendation
We recommend **Option C (Prompt Engineering)** as the first and preferred path to casualize the assistant's tone. Given the strict 2-week timeline and 20-hour native-speaker reviewer limit, prompt engineering is the fastest method to prototype and validate. However, this is a risk-managed sequence: we will run prompt engineering first using a quantitative gate. If the gate fails by Day 3, we will stop prompt-only iteration and escalate to Option A (SFT evaluation).

## Assumptions
*   **Engineering Target:** The 80% success threshold (defined below) is an internal engineering assumption, not an externally validated product standard.
*   **Validation Gap:** Native-speaker validation is only available for Hindi and Kannada. Outcomes for Tamil, Telugu, Bengali, and Marathi remain an unvalidated deployment risk.
*   **Unvalidated Baseline:** No real FLM-4B quality experiment has been run yet; our prior pipeline checks using GPT-2 were strictly to validate the test harness infrastructure, not output quality.

## Back-of-Envelope Arithmetic
*   **Reviewer Budget:** 10 hours/week × 2 weeks = 20 reviewer-hours = 1,200 minutes total capacity.
*   **Day-1 Workload:** 20 Hindi + 20 Kannada test inputs evaluated across 3 prompt variants = 120 variant outputs to review.
*   **Time Cost:** Assuming 3 minutes per output review, 120 reviews = 360 minutes = 6 hours.
*   **Conclusion:** The Day-1 review easily fits inside the weekly 10-hour reviewer budget, leaving buffer for iteration. *(Note: Exact A100 training costs and inference latencies for FLM-4B cannot be precisely defined without further empirical testing, but prompt engineering adds no additional model inference stage; it may add a small prompt/prefill-token overhead.)*

## Success Metric
Reviewers will evaluate outputs based on a simple rubric:
1.  **Casualness Score:** 1 (formal/textbook) to 5 (highly natural/casual).
2.  **Meaning Preservation:** 0 (failed) or 1 (preserved).

**Proposed Success Criterion:**
>=80% of reviewed Hindi/Kannada outputs must achieve a casualness score >= 3 AND meaning preservation = 1. *(Note: 80% is an engineering assumption.)*

## Kill Criterion
If the >=80% success threshold is not achieved after prompt iteration by **Day 3**, we will stop prompt-only experimentation and immediately escalate resources to SFT evaluation.

## Day-1 Experiment
*   **Inputs:** 20 Hindi and 20 Kannada inputs, kept identical across all variants to ensure controlled A/B testing.
*   **Variants:** 3 distinct prompt engineering variants.
*   **Methodology:** Reviewers are presented with blinded, randomized presentation orders to prevent bias.
*   **Evaluation:** Reviewers score both casualness and meaning preservation per the rubric above.

## Alternatives
*   **Option A (SFT):** Requires higher upfront data synthesis and A100 training effort, but introduces no additional inference stage after tuning. Synthetic-data quality is the main risk. This is the designated escalation path if prompting fails.
*   **Option B (Rewriter):** Avoids modifying the main model but introduces another inference stage and latency penalty. The rewriter must pass both style and meaning-preservation checks. We deprioritize this unless prompting fails and a suitable off-the-shelf <=1B model validates quickly.

## Final Recommendation
Try prompting first. This maximizes information gained per unit of time and preserves the option to escalate if it fails.
