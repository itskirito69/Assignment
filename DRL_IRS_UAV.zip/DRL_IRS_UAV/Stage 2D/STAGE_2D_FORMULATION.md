# STAGE 2D — FINAL SURGICAL CORRECTION AUDIT
## Freeze Gate: Robust Uncertainty, Solver Outcomes, Byzantine Causality, Action Semantics

---

# 1. FIVE SURGICAL CORRECTIONS

---

## CORRECTION 1 — $\Delta_{E,k,t}$ IS REALIZATION-DEPENDENT, NOT A FIXED PARAMETER

### Previous Issue

The Stage 2D-REV (§4.2) classified the Eve CSI uncertainty radius $\Delta_{E,k}$ as a "fixed system parameter" alongside $\epsilon_{UE,k}$, $\epsilon_{IE}$, $\beta_0$, etc. The information audit table (§4.7) listed $\Delta_{E,k}$ with "Known before $a_t$? ✅ (fixed params)."

This is **mathematically incorrect**.

### Why the Correction Is Necessary

The Stage 1 derivation (STAGE_1_DECISION.md, §C) gives:

$$\Delta_{E,k} = \epsilon_{UE,k} + \epsilon_{IE}\|h_{UI,k}\|_2$$

The term $\|h_{UI,k}\|_2$ is the norm of the user-IRS channel vector. From the base paper (Eq. 5):

$$h_{UI,k} = \sqrt{\frac{\beta_0}{d_{UI,k}^{\alpha_2}}}\;\tilde{h}_k^{UI}$$

The distance $d_{UI,k}$ is fixed (both IRS and users are stationary). However, $\tilde{h}_k^{UI} \in \mathbb{C}^N$ is the small-scale fading vector between user $k$ and the $N$ IRS elements. In our sequential block-fading model, this is a **per-round random variable**: $\tilde{h}_{k,t}^{UI}$.

Therefore:

$$\|h_{UI,k,t}\|_2 = \sqrt{\frac{\beta_0}{d_{UI,k}^{\alpha_2}}}\;\|\tilde{h}_{k,t}^{UI}\|_2$$

varies with the fading realization $\xi_t$, which makes:

$$\Delta_{E,k,t} = \epsilon_{UE,k} + \epsilon_{IE}\sqrt{\frac{\beta_0}{d_{UI,k}^{\alpha_2}}}\;\|\tilde{h}_{k,t}^{UI}\|_2$$

a function of $\xi_t$, i.e., $\Delta_{E,k,t} = \Delta_{E,k}(\xi_t)$.

### Exact Correction

**Fixed quantities** (truly time-invariant):

$$\epsilon_{UE,k}, \quad \epsilon_{IE}, \quad d_{UI,k}, \quad \beta_0, \quad \alpha_2$$

**Realization-dependent quantities** (vary with $\xi_t$):

$$\tilde{h}_{k,t}^{UI}, \quad h_{UI,k,t}, \quad \|h_{UI,k,t}\|_2, \quad \Delta_{E,k,t}$$

The corrected robust secrecy constraint C9 for user $k$ in round $t$ is:

$$|h_k(r_t, v_t; \xi_t)|^2 \ge \Gamma_k(b_{k,t})\bigl(|z_k(v_t; \xi_t)| + \Delta_{E,k,t}\bigr)^2 + \frac{N_0 b_{k,t}}{p_{k,t}}\bigl(\Gamma_k(b_{k,t}) - 1\bigr)$$

where both $z_k(v_t; \xi_t)$ and $\Delta_{E,k,t}$ depend on $\xi_t$, and both are computable at the micro-layer because $\xi_t$ is fully observed there.

**Information-structure consequence:** $\Delta_{E,k,t}$ is NOT available before $a_t$. It is available only after $\xi_t$ is revealed. The DRL controller never sees $\Delta_{E,k,t}$ directly. The micro-layer computes it from $\xi_t$ and uses it in C9. This is consistent with the Model B causal timeline — no correction to the information flow is needed, only to the labeling.

The previous 2D-REV information table row for $\Delta_{E,k}$ must be corrected from:

| $\Delta_{E,k}$ | ✅ (fixed params) | — | ❌ (system params) | ✅ |

to:

| $\Delta_{E,k,t}$ | ❌ | ✅ (computed from $\xi_t$) | ❌ | ✅ |

### Note on Conservative Fixed Bound (Not Adopted)

One could define a deterministic upper bound $\bar{\Delta}_{E,k} = \epsilon_{UE,k} + \epsilon_{IE}\sqrt{\beta_0 / d_{UI,k}^{\alpha_2}} \cdot h_{\max}^{UI}$ by bounding $\|\tilde{h}_{k,t}^{UI}\|_2 \le h_{\max}^{UI}$. This would make C9 more conservative (harder to satisfy). We do NOT adopt this because: (i) it is unnecessarily conservative, (ii) the micro-layer already observes $\xi_t$, so the exact realization-dependent $\Delta_{E,k,t}$ is available, (iii) using the exact value preserves the tightest possible secrecy guarantee without approximation.

✅ **Correction 1 closed.**

---

## CORRECTION 2 — REMOVE ALL BCD/KKT/STATIONARY-POINT CLAIMS

### Previous Issue

The Stage 2D-REV (§7) described the micro-layer output as a "feasible BCD stationary point" and stated that the solver achieves "block-wise stationarity" and "KKT conditions within each BCD block." These are convergence claims about the eventual numerical solver that have no place in a control-problem formulation.

### Why the Correction Is Necessary

Stage 2D defines the **mathematical control problem** $\mathcal{P}_{\text{ctrl}}$. The micro-layer solver is part of the system's transition mechanism. The control-problem definition must specify WHAT the micro-layer produces (a feasible solution or failure), not HOW it produces it or what convergence properties its iterates have. Claims about BCD convergence, KKT stationarity, or BSUM monotonicity belong to a solver-design stage, not to the control-problem formulation.

Moreover, the Stage 1 convergence architecture was established for the *static* problem $\mathcal{P}_1$ (single snapshot). Whether the same convergence properties hold when the solver is called repeatedly within a sequential control loop, potentially warm-started, with varying channel realizations, is a separate question that Stage 2D should not pre-answer.

### Exact Correction

**Remove** all instances of:
- "BCD stationary point"
- "block-wise stationarity"
- "KKT conditions"
- "BSUM monotone descent"
- "converges to a stationary point"

**Replace with:**

> The micro-layer physical-layer recourse procedure numerically searches for a feasible point satisfying all imposed constraints ($\widetilde{C1}$–$C9$). When the procedure successfully finds such a point, it returns a feasible solution $y_t$ and the round proceeds. No claim of global optimality, local optimality, or convergence to a KKT/stationary point is made at the Stage 2D formulation level. The properties of the eventual numerical solver (convergence, quality of returned solutions) are implementation concerns to be addressed separately.

The micro-layer is now described purely by its **input-output contract**:

- **Input:** $(r_t, \xi_t, \mathcal{S}_t^{\text{cand}})$ and fixed system parameters.
- **Output:** Either a feasible solution $y_t$ satisfying $\widetilde{C1}$–$C9$, or a failure signal.
- **No optimality qualifier** on the returned $y_t$.

✅ **Correction 2 closed.**

---

## CORRECTION 3 — THREE DISTINCT PHYSICAL-LAYER OUTCOMES

### Previous Issue

The Stage 2D-REV (§7.3) described only two outcomes: "feasible" (solver finds a solution) and "infeasible" (no feasible point exists or $|\mathcal{S}_t| < S_{\min}$). This conflates structural infeasibility of the underlying mathematical problem with numerical failure of the solver to find a feasible point. These are fundamentally different phenomena.

### Why the Correction Is Necessary

If the formulation calls every solver failure "infeasible," then:
1. A reviewer can challenge: "How do you know the problem was infeasible and not just that your solver failed?"
2. The DRL might learn from incorrect feedback — being penalized for an "outage" that was actually a solver bug.
3. The scientific claim "the system experienced an outage" is incorrect when the issue is numerical, not physical.

### Exact Correction

Define the physical-layer feasible set:

$$\mathcal{Y}_t(r_t, \xi_t, \mathcal{S}_t^{\text{cand}}) = \left\{(v, E_{\mathrm{WPT}}, T, \{p_k, b_k, f_k\}_{k \in \mathcal{S}_t^{\text{cand}}}) : \widetilde{C1}\text{–}C9 \text{ hold}\right\}$$

Three mutually exclusive and exhaustive outcomes:

---

**Outcome A — Service success:**

$$\mathcal{Y}_t \ne \emptyset \quad \text{AND the numerical solver finds a point } y_t \in \mathcal{Y}_t.$$

The round proceeds: WPT, computation, secure uplink, FL aggregation.

Set $\text{outcome}_t = \texttt{SUCCESS}$.

---

**Outcome B — Structural infeasibility:**

$$\mathcal{Y}_t = \emptyset.$$

No physically feasible transmission configuration exists for this $(r_t, \xi_t, \mathcal{S}_t^{\text{cand}})$. This is a genuine physical outage caused by deep fading, unfavorable geometry, or a secrecy constraint that is impossible to satisfy.

Set $\text{outcome}_t = \texttt{STRUCTURAL\_INFEASIBLE}$.

Safe fallback: no RF, no WPT, no FL.

---

**Outcome C — Solver failure:**

$$\mathcal{Y}_t \ne \emptyset \quad \text{BUT the numerical solver fails to find a point in } \mathcal{Y}_t.$$

A feasible solution exists in principle but the solver did not find it. This is a numerical/algorithmic failure, not a physical impossibility.

Set $\text{outcome}_t = \texttt{SOLVER\_FAILURE}$.

Safe fallback: no RF, no WPT, no FL (same operational consequence as Outcome B).

---

### Practical Distinguishability

In practice, the solver **cannot always distinguish** Outcome B from Outcome C. A nonconvex feasibility problem has no polynomial-time certificate of infeasibility. When the solver terminates without finding a feasible point, we cannot know with certainty whether $\mathcal{Y}_t = \emptyset$ or whether $\mathcal{Y}_t \ne \emptyset$ but the solver's search was insufficient.

**Operational treatment:** Both Outcome B and Outcome C produce the same safe fallback (no transmission). For DRL training purposes, both are treated as **service failure events** with the same penalty. We do NOT claim to distinguish them.

**Experimental treatment:** In simulation, one can attempt to verify structural infeasibility by running the solver from multiple random initializations or by relaxing the nonconvex constraints (e.g., dropping $|v_n| = 1$) and checking whether the relaxed problem is infeasible. If the relaxed problem is infeasible, structural infeasibility is confirmed. If the relaxed problem is feasible but the original is not solved, it could be either B or C. This distinction is reported in experimental results, not assumed in the formulation.

**Formally, for the control problem $\mathcal{P}_{\text{ctrl}}$:**

$$\text{feas}_t = \begin{cases} 1 & \text{if outcome}_t = \texttt{SUCCESS} \\ 0 & \text{if outcome}_t \in \{\texttt{STRUCTURAL\_INFEASIBLE}, \texttt{SOLVER\_FAILURE}\} \end{cases}$$

The transition kernel and control objective use only $\text{feas}_t \in \{0,1\}$. The three-way distinction is conceptual and diagnostic, not a formal state variable.

✅ **Correction 3 closed.**

---

## CORRECTION 4 — BYZANTINE MARKOV CLOSURE

### Previous Issue

The Stage 2D-REV (§9, §10) treated Byzantine behavior $\omega_t$ as a source of randomness in the transition but did not explicitly state the stochastic model for $\omega_t$. The formulation left open whether $\omega_t$ could be adversarially adaptive (history-dependent), which would break the Markov property of the transition kernel with respect to $X_t^-$.

### Why the Correction Is Necessary

If $\omega_t$ depends on the full history $(X_1^-, a_1, \ldots, X_t^-, a_t)$, then the transition $X_{t+1}^- \sim P(\cdot | X_t^-, a_t, \xi_t, \omega_t)$ is NOT Markov in $X_t^-$ because $\omega_t$ introduces hidden history dependence. The control problem $\mathcal{P}_{\text{ctrl}}$ requires a well-defined (if approximate) Markov structure for any DRL approach to be applicable.

### Exact Correction

**Modeling Assumption (Byzantine Behavior):**

$$\boxed{\omega_t \sim P_B(\cdot \mid X_t^-, a_t)}$$

This states:

1. The Byzantine attack realization $\omega_t \in \{0,1\}^K$ at round $t$ depends (at most) on the current pre-action state $X_t^-$ and the current macro action $a_t$.
2. Conditional on $(X_t^-, a_t)$, $\omega_t$ is independent of the history $(X_1^-, a_1, \ldots, X_{t-1}^-, a_{t-1})$.
3. $\omega_t$ is independent of $\xi_t$ (Byzantine behavior is determined before or independently of channel fading).

**Interpretation:** This assumption means the adversary's strategy at round $t$ can depend on observable system state (e.g., which users are scheduled, the UAV's committed position, the current trust scores through $X_t^-$) but does NOT have unbounded memory beyond what is captured in $X_t^-$. In particular, $X_t^-$ already contains the trust scores $\{\rho_{k,t-1}\}$, which are themselves a summary of all past aggregation diagnostics — so the adversary can implicitly "see" a summary of past rounds through the state.

**What this covers:**
- Stationary Byzantine behavior (fixed set of corrupted users): $P_B$ assigns probability 1 to a fixed $\omega$.
- State-adaptive attackers: attackers that intensify poisoning when they detect they are about to be excluded (low $\rho_{k,t-1}$), or relax when trusted.
- Action-adaptive attackers: attackers that change strategy based on the scheduling threshold $\eta_t$.

**What this does NOT cover:**
- Adversaries with private memory not captured in $X_t^-$ (e.g., an adversary that counts the exact number of times it has been excluded and uses a strategy keyed to that count, if that count is not in $X_t^-$).

Since $X_t^-$ contains $\{\rho_{k,t-1}\}$ and $n_{\text{out},t-1}$, most practically relevant adaptive adversaries are covered.

**This is a modeling assumption, not a theorem.** It is stated to close the Markov structure. If a specific adversarial model violates this assumption, the formulation would need to be extended with adversary state variables.

**Consequence for the transition kernel:**

$$X_{t+1}^- \sim P(\cdot \mid X_t^-, a_t)$$

is well-defined by marginalizing over $\xi_t \sim P_\xi(\cdot)$ and $\omega_t \sim P_B(\cdot \mid X_t^-, a_t)$ and the SGD noise in FL updates. The transition is Markov in $X_t^-$.

The DRL observation $o_t = \psi(X_t^-)$ is a deterministic compression of $X_t^-$, so the process $(o_t)$ is in general NOT Markov (due to the lossy compression $w_{t-1} \to \phi(w_{t-1})$). This is acceptable: the DRL operates on an approximate information state, as established in previous stages.

✅ **Correction 4 closed.**

---

## CORRECTION 5 — $\eta_t$ IS A TRUST/PARTICIPATION THRESHOLD, NOT A PHYSICAL-FEASIBILITY CONTROLLER

### Previous Issue

The Stage 2D-REV (§6.3) described $\eta_t$ and then stated (§13.8):

> "The DRL controls $\mathcal{S}_t^{\text{cand}}$ through $\eta_t$, not the micro-layer."

While technically accurate, the text in several places implied that $\eta_t$ functions as a mechanism to avoid physical infeasibility — e.g., §6.3: "If user $k$ frequently causes infeasibility... the DRL can learn to increase $\eta_t$ to exclude such users."

This conflates the semantic role of $\eta_t$ (trust-based FL participation) with a physical-layer function (feasibility management).

### Why the Correction Is Necessary

1. $\eta_t$ controls which clients are **eligible for FL participation based on trust/reputation**. Its purpose is Byzantine-aware client selection.
2. Whether the system can physically serve the selected clients is determined **entirely** by the micro-layer through the WPCN + secrecy constraints and the channel realization $\xi_t$.
3. Changing $\eta_t$ changes the candidate user set $\mathcal{S}_t^{\text{cand}}$ and thereby indirectly affects whether the micro-layer problem is feasible (fewer users may be easier to serve). But $\eta_t$ does NOT control feasibility; it controls FL participation trust policy.
4. If a reviewer asks "does changing $\eta_t$ guarantee feasibility?", the answer must be: **No. Feasibility depends on $(r_t, \xi_t, \mathcal{S}_t^{\text{cand}})$ jointly, and no value of $\eta_t$ can guarantee feasibility under arbitrary fading.**

### Exact Correction

**$\eta_t$ is defined as:**

A trust/participation threshold for Byzantine-aware FL scheduling:

$$\mathcal{S}_t^{\text{cand}} = \{k \in \mathcal{K} : \rho_{k,t-1} \ge \eta_t\}$$

**$\eta_t$ controls:** Which clients the server considers trustworthy enough to include in FL aggregation this round.

**$\eta_t$ does NOT control:** Whether the physical-layer transmission is feasible. Physical feasibility is determined by the micro-layer recourse given $(r_t, \xi_t, \mathcal{S}_t^{\text{cand}})$.

**Causal chain:**

$$\eta_t \;\xrightarrow{\text{determines}}\; \mathcal{S}_t^{\text{cand}} \;\xrightarrow{\text{input to}}\; \text{micro-layer} \;\xrightarrow[\text{determines}]{\text{jointly with } (r_t, \xi_t)}\; \text{feas}_t$$

There is an **indirect** effect: a higher $\eta_t$ may reduce $|\mathcal{S}_t^{\text{cand}}|$, which may make the micro-layer problem easier to satisfy (fewer constraints). But this is a learned correlation, not a causal guarantee.

✅ **Correction 5 closed.**

---

# 2. FINAL STAGE 2D FORMULATION — CORRECTED DEFINITIONS

All definitions below supersede any previous version.

---

## Pre-Action State $X_t^-$

$$X_t^- = \bigl(r_{t-1},\; w_{t-1},\; \{\rho_{k,t-1}\}_{k=1}^K,\; \bar{h}_{t-1},\; n_{\text{out},t-1},\; t\bigr)$$

- $r_{t-1}$: UAV position after round $t-1$ (deterministic, known).
- $w_{t-1}$: global FL model after round $t-1$ (known at UAV).
- $\rho_{k,t-1}$: per-user trust score (known, deterministic given history).
- $\bar{h}_{t-1} \in \mathbb{R}_+^K$: per-user channel gain from round $t-1$ ($|h_k(r_{t-1}, v_{t-1}; \xi_{t-1})|^2$ if feasible, carried forward if outage).
- $n_{\text{out},t-1}$: cumulative service-failure count.
- $t$: round index.

Every element is determined at the end of round $t-1$.

---

## DRL Observation $o_t$

$$o_t = \psi(X_t^-) = \bigl(r_{t-1},\; \phi(w_{t-1}),\; \{\rho_{k,t-1}\}_{k=1}^K,\; \bar{h}_{t-1},\; n_{\text{out},t-1},\; t\bigr)$$

where $\phi(w_{t-1}) \in \mathbb{R}^{d_\phi}$ is a lossy compression of the FL model (e.g., training loss, gradient norm, loss change).

$\psi$ is deterministic. $o_t$ depends only on $X_t^-$, which depends only on past rounds.

---

## Macro Action $a_t$

$$a_t = (\Delta x_t, \Delta y_t, \eta_t) \in \mathcal{A} = [-\delta_{\max}, \delta_{\max}]^2 \times [0,1]$$

- $(\Delta x_t, \Delta y_t)$: UAV displacement. Position update: $r_t = \mathrm{Proj}_{\|r\| \le d}(r_{t-1} + (\Delta x_t, \Delta y_t))$.
- $\eta_t$: **trust/participation threshold** for Byzantine-aware FL scheduling. $\mathcal{S}_t^{\text{cand}} = \{k \in \mathcal{K} : \rho_{k,t-1} \ge \eta_t\}$.

$\mathcal{A}$ is a fixed compact set, state-independent. $\eta_t$ does NOT control or guarantee physical feasibility.

---

## Post-Action Channel Realization $\xi_t$

$$\xi_t = \bigl(\{\tilde{h}_{k,t}^{UA}\}_{k=1}^K,\; \tilde{h}_t^{IA},\; \{\tilde{h}_{k,t}^{UI}\}_{k=1}^K\bigr) \sim P_\xi(\cdot)$$

Drawn i.i.d. per round (block fading). Independent of $(X_t^-, a_t)$. The large-scale path loss $\beta_0 / d_{UA,k}(r_t)^{\alpha_1}$ etc. depends on $r_t$ (from $a_t$) deterministically, but the small-scale fading in $\xi_t$ does not.

$\xi_t$ is revealed AFTER $a_t$ is committed. The DRL never observes $\xi_t$ for the current round.

From $\xi_t$, the micro-layer computes:
- All legitimate channels $h_k(r_t, v; \xi_t)$ as functions of $v$.
- The realization-dependent eavesdropper terms $z_k(v; \xi_t)$ and $\Delta_{E,k,t} = \Delta_{E,k}(\xi_t)$.

---

## Physical-Layer Feasible Set $\mathcal{Y}_t$

$$\mathcal{Y}_t \triangleq \mathcal{Y}(r_t, \xi_t, \mathcal{S}_t^{\text{cand}}) = \Bigl\{(v, E_{\mathrm{WPT}}, T, \{p_k, b_k, f_k\}_{k \in \mathcal{S}_t^{\text{cand}}}) : \widetilde{C1}\text{–}C9 \text{ are satisfied}\Bigr\}$$

where constraints $\widetilde{C1}$–$C9$ are:

$$\begin{aligned}
\widetilde{C1}: \quad & \frac{R C_k D_k}{f_k} + \frac{D}{R_k} \le T, && \forall k \in \mathcal{S}_t^{\text{cand}} \\[3pt]
\widetilde{C2}: \quad & \frac{R \tau_k}{2} C_k D_k f_k^2 + \frac{p_k D}{R_k} \le \lambda E_{\mathrm{WPT}} |h_k(r_t, v; \xi_t)|^2, && \forall k \in \mathcal{S}_t^{\text{cand}} \\[3pt]
\widetilde{C3}: \quad & E_{\mathrm{WPT}} \le P_c^{\max} T \\[3pt]
C4: \quad & 0 \le p_k \le p_{\max}, && \forall k \in \mathcal{S}_t^{\text{cand}} \\[3pt]
C5: \quad & \sum_{k \in \mathcal{S}_t^{\text{cand}}} b_k \le B, \quad b_k \ge 0 \\[3pt]
C6: \quad & f_k^{\min} \le f_k \le f_k^{\max}, && \forall k \in \mathcal{S}_t^{\text{cand}} \\[3pt]
C7: \quad & |v_n| = 1, && \forall n \in \mathcal{N} \\[3pt]
C9: \quad & |h_k(r_t, v; \xi_t)|^2 \ge \Gamma_k(b_k)(|z_k(v; \xi_t)| + \Delta_{E,k,t})^2 + \frac{N_0 b_k}{p_k}(\Gamma_k(b_k) - 1), && \forall k \in \mathcal{S}_t^{\text{cand}}
\end{aligned}$$

with $\Delta_{E,k,t} = \epsilon_{UE,k} + \epsilon_{IE}\|h_{UI,k,t}\|_2$ computed from $\xi_t$.

The physical-layer recourse procedure numerically searches for a feasible point $y_t \in \mathcal{Y}_t$. No optimality, stationarity, or KKT claim is made about the returned point.

---

## Transition $P$

$$X_{t+1}^- \sim P(\cdot \mid X_t^-, a_t)$$

obtained by marginalizing over:

1. **Fading:** $\xi_t \sim P_\xi(\cdot)$ — i.i.d., independent of $(X_t^-, a_t)$.
2. **Byzantine behavior:** $\omega_t \sim P_B(\cdot \mid X_t^-, a_t)$ — **modeling assumption** (see §5).
3. **SGD noise:** mini-batch randomness in local FL updates.

Step-by-step deterministic components:

- **Position:** $r_t = \mathrm{Proj}_{\|r\| \le d}(r_{t-1} + (\Delta x_t, \Delta y_t))$.
- **Candidate set:** $\mathcal{S}_t^{\text{cand}} = \{k : \rho_{k,t-1} \ge \eta_t\}$.
- **Micro-layer:** Numerical search for $y_t \in \mathcal{Y}_t(r_t, \xi_t, \mathcal{S}_t^{\text{cand}})$. Returns $(\text{feas}_t, y_t)$.
- **FL update:**
  $w_t = w_{t-1} + \alpha_g \cdot \mathcal{G}(\{\Delta w_{k,t}\}_{k \in \mathcal{S}_t^{\text{cand}}})$ if $\text{feas}_t = 1$; $w_t = w_{t-1}$ otherwise.
- **Trust:** $\rho_{k,t} = \beta_\rho \rho_{k,t-1} + (1-\beta_\rho)\sigma_{k,t}$ if $\text{feas}_t = 1$; unchanged otherwise.
- **Channel stats:** $\bar{h}_{k,t} = |h_k(r_t, v_t; \xi_t)|^2$ if $\text{feas}_t = 1$; $\bar{h}_{k,t} = \bar{h}_{k,t-1}$ otherwise.
- **Outage counter:** $n_{\text{out},t} = n_{\text{out},t-1} + (1 - \text{feas}_t)$.

---

## Reward / Control Objective $R$

**Per-step signal:**

$$R_t = \begin{cases} \mathcal{L}(w_{t-1}) - \mathcal{L}(w_t) & \text{if } \text{feas}_t = 1 \\ 0 & \text{if } \text{feas}_t = 0 \end{cases}$$

Note: $R_t$ may be negative (Byzantine corruption worsens model).

**Primary objective:**

$$\max_\pi \; J(\pi) = \mathbb{E}_\pi\!\left[\sum_{t=1}^{T_{\max}} \gamma^{t-1} R_t\right]$$

**Long-term constraints:**

$$G_1(\pi) = \mathbb{E}_\pi\!\left[\sum_{t=1}^{T_{\max}} E_{\mathrm{WPT},t} \cdot \mathbb{1}[\text{feas}_t = 1]\right] \le E_{\mathrm{budget}}$$

$$G_2(\pi) = \mathbb{E}_\pi\!\left[\frac{1}{T_{\max}} \sum_{t=1}^{T_{\max}} (1 - \text{feas}_t)\right] \le \epsilon_{\mathrm{out}}$$

**Hard per-round constraints:** $\widetilde{C1}$–$C9$ enforced by micro-layer whenever $\text{feas}_t = 1$. Safe fallback otherwise.

**Full control problem:**

$$\mathcal{P}_{\text{ctrl}}: \quad \max_\pi \; J(\pi) \quad \text{s.t.} \quad G_1(\pi) \le E_{\mathrm{budget}}, \quad G_2(\pi) \le \epsilon_{\mathrm{out}}$$

No algorithmic commitment (no CMDP, no Lagrangian, no specific DRL algorithm).

---

# 3. ROBUST SECRECY CONSISTENCY CHECK

**Stage 1 derivation (STAGE_1_DECISION.md §C):**

$$\Delta_{E,k} = \epsilon_{UE,k} + \epsilon_{IE}\|h_{UI,k}\|_2$$

**Base paper channel (Eq. 5):**

$$h_{UI,k} = \sqrt{\frac{\beta_0}{d_{UI,k}^{\alpha_2}}}\;\tilde{h}_k^{UI}$$

**In sequential model:**

$$h_{UI,k,t} = \sqrt{\frac{\beta_0}{d_{UI,k}^{\alpha_2}}}\;\tilde{h}_{k,t}^{UI}$$

where $\tilde{h}_{k,t}^{UI} \in \mathbb{C}^N$ is part of $\xi_t$.

**Therefore:**

$$\Delta_{E,k,t} = \epsilon_{UE,k} + \epsilon_{IE}\sqrt{\frac{\beta_0}{d_{UI,k}^{\alpha_2}}}\;\|\tilde{h}_{k,t}^{UI}\|_2 = \Delta_{E,k}(\xi_t)$$

**Dependency chain:**

$$\xi_t \;\ni\; \tilde{h}_{k,t}^{UI} \;\longrightarrow\; h_{UI,k,t} \;\longrightarrow\; \|h_{UI,k,t}\|_2 \;\longrightarrow\; \Delta_{E,k,t}$$

**Consistency verification:**
- $\Delta_{E,k,t}$ is NOT known before $a_t$. ✅
- $\Delta_{E,k,t}$ IS known to the micro-layer (which observes $\xi_t$). ✅
- $\Delta_{E,k,t}$ is NOT in $o_t$. ✅
- C9 uses the exact Stage 1 expression, with correct time indexing. ✅
- No conservative fixed bound is used. The exact realization-dependent value is applied. ✅
- This is the **exact** Stage 1 derivation, not an approximation. The only change is adding the round subscript $t$ to reflect block fading. ✅

---

# 4. SOLVER OUTCOME SEMANTICS

Three conceptually distinct outcomes:

| Outcome | Condition | Physical Meaning | Operational Response | Distinguishable? |
|---|---|---|---|---|
| **A: Success** | $\mathcal{Y}_t \ne \emptyset$ AND solver finds $y_t \in \mathcal{Y}_t$ | System can and does serve users securely | Execute WPT, computation, secure uplink, FL aggregation | ✅ Yes |
| **B: Structural infeasibility** | $\mathcal{Y}_t = \emptyset$ | No physically feasible configuration exists | Safe fallback: no RF, no WPT, no FL | ❌ Not always (see below) |
| **C: Solver failure** | $\mathcal{Y}_t \ne \emptyset$ but solver fails to find $y_t$ | Feasible configuration exists but not found | Safe fallback: no RF, no WPT, no FL | ❌ Not always (see below) |

**Distinguishability:** The solver cannot in general certify $\mathcal{Y}_t = \emptyset$ for a nonconvex problem. When the solver returns without a feasible point, we cannot determine with certainty whether Outcome B or C occurred.

**Operational treatment:** Outcomes B and C produce the identical safe fallback. For DRL training, both are treated as service failure ($\text{feas}_t = 0$) with the same consequence. The control problem $\mathcal{P}_{\text{ctrl}}$ uses only the binary $\text{feas}_t$.

**Experimental treatment:** In simulation, partial distinguishability is possible:
- Run the solver from multiple random initializations. If all fail, structural infeasibility becomes more likely (but not certain).
- Solve a convex relaxation (e.g., drop $|v_n|=1$). If the relaxation is infeasible, $\mathcal{Y}_t = \emptyset$ is confirmed.
- Report solver failure rates alongside structural infeasibility estimates.

**Key formulation discipline:**

$$\boxed{\text{structural infeasibility} \;\ne\; \text{numerical solver failure}}$$

The formulation acknowledges this distinction even though the operational response is the same.

---

# 5. BYZANTINE MARKOV CLOSURE

**Modeling assumption:**

$$\boxed{\omega_t \sim P_B(\cdot \mid X_t^-, a_t)}$$

**Why this closes the transition:**

The full transition is:

$$X_{t+1}^- = \mathcal{T}(X_t^-, a_t, \xi_t, \omega_t, \zeta_t^{\text{SGD}})$$

where $\zeta_t^{\text{SGD}}$ represents SGD mini-batch noise. With the assumptions:

- $\xi_t \sim P_\xi(\cdot)$ — independent of everything.
- $\omega_t \sim P_B(\cdot \mid X_t^-, a_t)$ — Markov assumption.
- $\zeta_t^{\text{SGD}}$ — conditionally independent given $(w_{t-1}, \mathcal{S}_t^{\text{cand}})$, both of which are in or determined by $(X_t^-, a_t)$.

We obtain:

$$X_{t+1}^- \sim P(\cdot \mid X_t^-, a_t) = \int \mathcal{T}(X_t^-, a_t, \xi, \omega, \zeta) \; dP_\xi(\xi) \; dP_B(\omega \mid X_t^-, a_t) \; dP_{\text{SGD}}(\zeta \mid X_t^-, a_t)$$

This is a well-defined Markov transition kernel on $X_t^-$.

**What the assumption covers:** Stationary Byzantine sets (fixed corrupted users), state-adaptive adversaries (strategy depends on trust scores in $X_t^-$), and action-adaptive adversaries (strategy depends on $\eta_t$ in $a_t$).

**What the assumption excludes:** Adversaries with private memory not captured in $X_t^-$ (e.g., an adversary tracking information about past rounds beyond what the trust scores summarize). Since $X_t^-$ contains $\{\rho_{k,t-1}\}$ which are exponential-moving-average summaries of all past aggregation diagnostics, this exclusion is narrow.

**This is a modeling assumption, explicitly stated as such.** It is not proven from first principles. It is adopted to keep the transition Markov.

---

# 6. ACTION SEMANTICS

The macro action is:

$$a_t = (\Delta x_t, \Delta y_t, \eta_t)$$

| Component | Semantic Role | Controls | Does NOT Control |
|---|---|---|---|
| $\Delta x_t, \Delta y_t$ | UAV spatial control | UAV position $r_t$ (after projection) | Channel fading; does not guarantee favorable channels |
| $\eta_t$ | **Trust/participation threshold** for Byzantine-aware FL scheduling | Which clients are FL-eligible: $\mathcal{S}_t^{\text{cand}} = \{k : \rho_{k,t-1} \ge \eta_t\}$ | Physical feasibility; does not guarantee $\mathcal{Y}_t \ne \emptyset$ |

**Explicit statement:**

$\eta_t$ is a **trust/participation threshold**. It determines which clients the server considers sufficiently trustworthy to include in federated learning aggregation this round. Its purpose is **Byzantine-aware client selection**, not physical-layer feasibility management.

Physical feasibility is determined exclusively by the micro-layer recourse, which depends on $(r_t, \xi_t, \mathcal{S}_t^{\text{cand}})$ jointly. No value of $\eta_t$ guarantees physical feasibility under arbitrary fading realizations. Conversely, $\eta_t = 0$ (include all users) does not guarantee infeasibility.

**Indirect effect:** Changing $\eta_t$ changes $|\mathcal{S}_t^{\text{cand}}|$, which changes the number of constraints in the micro-layer problem. Fewer users may make the problem easier to satisfy. But this is an indirect statistical effect that the DRL may learn, not a causal guarantee that the formulation claims.

---

# 7. REVIEWER-2 / REVIEWER-3 ATTACK SURFACE

After the five corrections, the remaining formulation-level attack surface is:

| Potential Reviewer Objection | Status |
|---|---|
| "Your state contains future information" | ✅ Closed. $X_t^-$ is strictly past. $\xi_t$ is strictly post-action. Information table verifies this. |
| "Your uncertainty radius $\Delta_{E,k}$ is incorrectly called fixed" | ✅ Closed (Correction 1). $\Delta_{E,k,t} = \Delta_{E,k}(\xi_t)$ is explicitly realization-dependent. |
| "You claim optimality for a nonconvex solver" | ✅ Closed (Correction 2). No optimality, KKT, or stationarity claim. |
| "You conflate solver failure with infeasibility" | ✅ Closed (Correction 3). Three outcomes distinguished. |
| "Your transition is not Markov because Byzantine behavior is adversarial" | ✅ Closed (Correction 4). $\omega_t \sim P_B(\cdot \mid X_t^-, a_t)$ stated as an explicit modeling assumption. |
| "Your action $\eta_t$ magically controls feasibility" | ✅ Closed (Correction 5). $\eta_t$ is a trust threshold; feasibility is micro-layer-determined. |
| "You prematurely committed to CMDP / Lagrangian" | ✅ Closed (from 2D-REV, preserved). $\mathcal{P}_{\text{ctrl}}$ is algorithm-agnostic. |
| "You silently dropped users in the micro-layer" | ✅ Closed (from 2D-REV, preserved). All-or-nothing feasibility. |
| "Your energy model is undefined" | ✅ Closed (from 2D-REV, preserved). Per-round energy neutrality. |
| "You modified the base paper equations" | ✅ Closed. Eqs. (1)–(17) preserved with round indexing. Only extensions: scheduling subset, secrecy C9, sequential indexing. |

**Remaining vulnerabilities that are NOT formulation-level issues:**
1. "Your DRL does not converge." — Deferred to Stage 3. No convergence claim is made.
2. "Your FL does not converge under this policy." — Explicitly flagged as a non-guarantee.
3. "Your approach is not novel." — Requires literature audit (Stage 3).
4. "Your $o_t$ is not sufficiently Markov." — Acknowledged; empirical validation needed.

None of these require changes to the Stage 2D mathematical formulation.

---

# 8. FINAL GATE

## Corrected Information Audit Table (Complete)

| Quantity | Before $a_t$? | After $a_t$? | In $o_t$? | Micro-layer? | Role |
|---|:---:|:---:|:---:|:---:|---|
| $r_{t-1}$ | ✅ | — | ✅ | via $r_t$ | Past UAV position |
| $w_{t-1}$ | ✅ | — | via $\phi$ | ❌ | Past FL model |
| $\rho_{k,t-1}$ | ✅ | — | ✅ | ❌ | Past trust scores |
| $\bar{h}_{t-1}$ | ✅ | — | ✅ | ❌ | Past channel stats |
| $n_{\text{out},t-1}$ | ✅ | — | ✅ | ❌ | Past outage count |
| $t$ | ✅ | — | ✅ | ❌ | Clock |
| $\epsilon_{UE,k}, \epsilon_{IE}$ | ✅ (fixed) | — | ❌ (params) | ✅ | Fixed error bounds |
| $\widehat{g}_{UE,k}, \widehat{\mathbf{g}}_{IE}$ | ✅ (fixed) | — | ❌ (params) | ✅ | Fixed Eve estimates |
| $\tilde{h}_{k,t}^{UA}$ | ❌ | ✅ | ❌ | ✅ | Part of $\xi_t$ |
| $\tilde{h}_t^{IA}$ | ❌ | ✅ | ❌ | ✅ | Part of $\xi_t$ |
| $\tilde{h}_{k,t}^{UI}$ | ❌ | ✅ | ❌ | ✅ | Part of $\xi_t$ |
| $h_k(r_t, v; \xi_t)$ | ❌ | ✅ (computed) | ❌ | ✅ | Composite channel |
| $z_k(v; \xi_t)$ | ❌ | ✅ (computed) | ❌ | ✅ | Composite Eve channel |
| $\Delta_{E,k,t}$ | ❌ | ✅ (computed from $\xi_t$) | ❌ | ✅ | **Realization-dependent** uncertainty radius |
| $\omega_{k,t}$ | ❌ | ❌ (hidden) | ❌ | ❌ | Byzantine; drawn from $P_B$ |

**No variable is simultaneously unavailable before $a_t$ and included in $o_t$.** ✅

## Audit Checklist

| Check | Verdict |
|---|---|
| A. $X_t^-$ internally consistent and sufficient for Markov transition? | ✅ (with $\omega_t \sim P_B(\cdot \mid X_t^-, a_t)$) |
| B. $o_t$ consistent with pre-action knowledge? | ✅ (table above) |
| C. $a_t = (\Delta x_t, \Delta y_t, \eta_t)$ correctly interpreted? | ✅ ($\eta_t$ is trust threshold, not feasibility control) |
| D. Realization-dependent uncertainties correctly indexed? | ✅ ($\Delta_{E,k,t} = \Delta_{E,k}(\xi_t)$) |
| E. Robust secrecy uses exact Stage 1 formulation? | ✅ (same derivation, added round index) |
| F. Micro-layer described without optimality/KKT claims? | ✅ (numerical feasibility search only) |
| G. Three outcomes separated? | ✅ (success, structural infeasibility, solver failure) |
| H. Byzantine Markov assumption closed? | ✅ ($\omega_t \sim P_B(\cdot \mid X_t^-, a_t)$, stated as assumption) |
| I. $\eta_t$ correctly described? | ✅ (trust/participation threshold) |
| J. Algorithm-independent? | ✅ (no CMDP, no Lagrangian, no DRL algorithm named) |

---

$$\boxed{\textbf{GREEN — STAGE 2D FROZEN}}$$

All five surgical corrections are closed and internally consistent. The corrected formulation:

1. Uses the exact Stage 1 robust secrecy derivation with correct time-dependent $\Delta_{E,k,t} = \Delta_{E,k}(\xi_t)$.
2. Makes no optimality, stationarity, or convergence claims about the micro-layer solver.
3. Distinguishes structural infeasibility from solver failure (with honest acknowledgment that runtime distinction is not always possible).
4. Closes the Byzantine Markov structure with an explicit modeling assumption $\omega_t \sim P_B(\cdot | X_t^-, a_t)$.
5. Correctly classifies $\eta_t$ as a trust/participation threshold, not a physical-feasibility controller.
6. Preserves all previously closed decisions (two-timescale architecture, per-round energy neutrality, all-or-nothing feasibility, algorithm independence, base paper equations).
7. Contains no convergence theorem, no algorithm selection, and no base-paper modification.

> **Stage 2D is frozen. The next stage is Stage 3: Literature Audit + DRL Algorithm Selection.**
