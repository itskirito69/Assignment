# Stage 3B.1 — Surgical Operational Closure Report

## Formal Auditing and Closure of Operational DRL Issues Prior to Stage 3C

---

# 1. EXECUTIVE OVERVIEW

Following the hostile Stage 3B DRL Formulation Audit, this document executes the **four surgical operational corrections** required to bridge the frozen Stage 2D formulation into the upcoming DRL algorithm comparison (Stage 3C).

In strict accordance with the audit guidelines:
- **Architecture is NOT redesigned.**
- **No DRL algorithm (SAC, PPO, TD3, etc.) is selected.**
- **No code is implemented.**
- **No theoretical bounds or convergence theorems are invented.**
- **The Stage 2D physical and mathematical formulation remains FROZEN.**

---

# 2. SURGICAL CORRECTION AUDITS

---

## CORRECTION 1: Add Remaining/Cumulative Energy to the Operational State

### 1. Original Issue
In Stage 2D (§2), the pre-action state was defined as:
$$X_t^- = \bigl(r_{t-1},\; w_{t-1},\; \{\rho_{k,t-1}\}_{k=1}^K,\; \bar{h}_{t-1},\; n_{\text{out},t-1},\; t\bigr)$$
While $n_{\text{out},t-1} = \sum_{\tau=1}^{t-1} (1 - \text{feas}_\tau)$ was included to track historical progress against the long-term outage constraint $G_2(\pi) \le \epsilon_{\text{out}}$, the cumulative WPT energy consumption was omitted.

Under the finite-horizon long-term constraint:
$$G_1(\pi) = \mathbb{E}_\pi\left[\sum_{t=1}^{T_{\max}} E_{\text{WPT},t} \cdot \mathbb{1}[\text{feas}_t = 1]\right] \le E_{\text{budget}}$$
an agent operating without remaining energy budget awareness is **budget-blind**. In stochastic optimal control over a finite horizon $T_{\max}$, an optimal Markov policy must modulate its risk posture (e.g., trajectory distance, client cluster coverage, and admission threshold) based on the remaining resource endowment. Without this state variable, stationary Markov policies cannot make budget-optimal decisions.

### 2. Exact Correction
We define the cumulative WPT energy expenditure up to round $t-1$ as:
$$E_{\text{cum},t-1} = \sum_{\tau=1}^{t-1} E_{\text{WPT},\tau} \cdot \mathbb{1}[\text{feas}_\tau = 1], \quad \text{with } E_{\text{cum},0} = 0$$
or equivalently, the remaining energy budget:
$$E_{\text{rem},t-1} = E_{\text{budget}} - E_{\text{cum},t-1}, \quad \text{with } E_{\text{rem},0} = E_{\text{budget}}$$

The operational state is explicitly updated to:
$$\boxed{X_t^- = \bigl(r_{t-1},\; w_{t-1},\; \{\rho_{k,t-1}\}_{k=1}^K,\; \bar{h}_{t-1},\; n_{\text{out},t-1},\; E_{\text{rem},t-1},\; t\bigr)}$$

The corresponding operational observation supplied to the policy network is:
$$\boxed{o_t = \psi(X_t^-) = \bigl(r_{t-1},\; \phi(w_{t-1}),\; \{\rho_{k,t-1}\}_{k=1}^K,\; \bar{h}_{t-1},\; n_{\text{out},t-1},\; E_{\text{rem},t-1},\; t\bigr)}$$

### 3. Mathematical / State-Level Change
- The state space dimension increases by exactly $1$ scalar ($E_{\text{rem},t-1} \in \mathbb{R}$).
- The transition recursion is exact and causal:
  $$E_{\text{rem},t} = E_{\text{rem},t-1} - E_{\text{WPT},t} \cdot \mathbb{1}[\text{feas}_t = 1]$$
- No future information is introduced. $E_{\text{rem},t-1}$ is fully determined by the history up to round $t-1$.

### 4. What Remains Intentionally Unresolved
- The exact feature scaling (e.g., raw Joules vs. normalized fraction $E_{\text{rem},t-1}/E_{\text{budget}}$, or average budget per remaining round $E_{\text{rem},t-1}/(T_{\max} - t + 1)$) is an implementation-level neural network input normalization choice deferred to Stage 3C.

### 5. Whether Stage 2D Needs Reopening
- **NO.** In Constrained Markov Decision Processes (CMDPs), augmenting the state with the accumulated constraint cost is the classical, standard technique to enable stationary policy execution for finite-horizon constraints. The underlying physical optimization and constraint bounds in Stage 2D remain identical.

---

## CORRECTION 2: Separate the Formal Objective from the Operational DRL Training Reward

### 1. Original Issue
Stage 3B identified potential training pathologies with the raw step reward $R_t = \Delta \mathcal{L}_t \cdot \mathbb{1}[\text{feas}_t=1]$ and discussed reward shaping remedies. This created conceptual ambiguity between the paper's formal optimization objective and the numerical training signals used in DRL optimization.

### 2. Exact Correction
We establish a strict, explicit separation between:

#### A. The Formal Research Objective (Stage 2D Mathematical Control Problem)
The definitive, uncompromised control problem $\mathcal{P}_{\text{ctrl}}$ of the paper remains:
$$\mathcal{P}_{\text{ctrl}}: \quad \max_\pi \; J(\pi) = \mathbb{E}_\pi\left[\sum_{t=1}^{T_{\max}} \gamma^{t-1} \bigl(\mathcal{L}(w_{t-1}) - \mathcal{L}(w_t)\bigr) \cdot \mathbb{1}[\text{feas}_t = 1]\right]$$
$$\text{subject to} \quad G_1(\pi) \le E_{\text{budget}}, \quad G_2(\pi) \le \epsilon_{\text{out}}$$
This formal objective represents the scientific performance metric evaluated in the paper's final benchmark comparisons.

#### B. The Operational DRL Training Reward
The numerical reward signal $R_t^{\text{train}}$ passed to the DRL policy gradient / Bellman loss during training. 

We document the governing principle:
$$\boxed{\text{Formal Objective } J(\pi) \;\ne\; \text{necessarily identical to raw operational training reward } R_t^{\text{train}}}$$

Any training surrogates (e.g., reward scaling, loss-difference normalization, service failure penalties, or potential-based reward shaping) introduced during algorithm implementation are **numerical optimization vehicles** designed to stabilize policy gradient ascent, and do not alter the formal mathematical research problem $\mathcal{P}_{\text{ctrl}}$.

### 3. Mathematical / State-Level Change
- None. The mathematical definition of $\mathcal{P}_{\text{ctrl}}$ is preserved verbatim.

### 4. What Remains Intentionally Unresolved
- The specific mathematical structure and hyperparameter tuning of $R_t^{\text{train}}$ are deferred to Stage 3C algorithm comparison.

### 5. Whether Stage 2D Needs Reopening
- **NO.** Explicitly distinguishing between the formal problem and training surrogates protects Stage 2D from being diluted by heuristic modifications.

---

## CORRECTION 3: Correct the Outage-Penalty Requirement

### 1. Original Issue
Stage 3B proposed an operational outage penalty condition:
$$\lambda_{\text{out}} > \max_{\omega, \zeta} |\Delta \mathcal{L}_t^{\text{poisoned}}|$$
to mathematically guarantee that service failures are strictly worse than poisoned rounds.

**Hostile Mathematical Critique:** This condition is unsupportable. In deep federated learning with non-convex loss surfaces, mini-batch gradient noise, and arbitrary Byzantine attack vectors (e.g., untargeted random updates or coordinated gradient ascent attacks), there is **no finite global theoretical upper bound on $|\Delta \mathcal{L}_t|$**. Inventing an artificial bound or asserting a universal dominance theorem is scientifically indefensible and creates a fatal vulnerability for hostile reviewers.

### 2. Exact Correction
1. We formally **retract and remove** the claim that $\lambda_{\text{out}}$ must exceed a theoretical global maximum $|\Delta \mathcal{L}_t|$.
2. No theoretical bound is invented.
3. We document the correct operational engineering principle:
   > **Operational Principle:** The operational outage penalty $\lambda_{\text{out}}$ must be calibrated empirically relative to the chosen bounded or normalized training-reward scale to discourage chronic service failure, without asserting any universal theoretical dominance condition.

### 3. Mathematical / State-Level Change
- None. No invalid theoretical constant or bound is injected into the mathematics.

### 4. What Remains Intentionally Unresolved
- The exact numerical calibration of $\lambda_{\text{out}}$, the reward normalization/clipping scheme, and the mechanism for constraint enforcement (e.g., additive penalty vs. adaptive Lagrangian dual variables $\mu_1, \mu_2$) are designated as Stage 3C design decisions.

### 5. Whether Stage 2D Needs Reopening
- **NO.** Striking an unsupported theoretical claim strengthens the paper's mathematical integrity without touching the underlying formulation.

---

## CORRECTION 4: Record Client-Selection Diversity / Cherry-Picking as an Open Stage 3C Issue

### 1. Original Issue
Stage 3B observed that the policy could potentially "cherry-pick" a tiny cohort of easy, geographically proximate, high-reputation clients to minimize physical infeasibility while ignoring the broader data distribution. 

While Stage 2D includes a minimum cohort size constraint ($|\mathcal{S}_t^{\text{cand}}| \ge S_{\min}$), claiming that $S_{\min}$ completely solves client-selection bias or non-IID data representation is technically false. $S_{\min}$ prevents numerical collapse to an empty or singleton set, but does not guarantee diversity across heterogeneous data distributions.

### 2. Exact Correction
1. We explicitly **record client-selection diversity and cherry-picking as an open, unresolved Stage 3C design issue**.
2. We retain the Stage 2D admission definition without modification:
   $$\mathcal{S}_t^{\text{cand}} = \{k \in \mathcal{K} : \rho_{k,t-1} \ge \eta_t\}$$
3. We do **NOT** add ad-hoc fairness constraints, diversity regularization, or additional action dimensions in Stage 3B.1.
4. We record that Stage 3C will evaluate whether client diversity should be addressed through:
   - observation features (e.g., tracking historical client selection frequencies),
   - multi-objective reward regularization,
   - constrained scheduling bounds, or
   - empirical baseline comparisons demonstrating the natural trade-off between Byzantine trust filtering and client diversity.

### 3. Mathematical / State-Level Change
- None. Action space $\mathcal{A} = [-\delta_{\max}, \delta_{\max}]^2 \times [0, 1]$ and candidate definition are preserved exactly as frozen in Stage 2D.

### 4. What Remains Intentionally Unresolved
- The algorithmic resolution of client-selection diversity vs. Byzantine resilience is explicitly deferred to Stage 3C.

### 5. Whether Stage 2D Needs Reopening
- **NO.** The architectural separation of concerns is maintained. Stage 2D defines the system mechanics; Stage 3C investigates algorithmic policies to balance diversity and trust.

---

# 3. CONSOLIDATED AUDIT SUMMARY

| Correction | Nature of Change | Mathematical Impact | Stage 2D Reopened? | Status |
|---|---|---|:---:|:---:|
| **1. Energy in Operational State** | State Augmentation | $X_t^-$ augmented with $E_{\text{rem},t-1} \in \mathbb{R}$ | **NO** | 🟢 CLOSED |
| **2. Objective vs Training Reward** | Conceptual Clarification | Preserves $\mathcal{P}_{\text{ctrl}}$; designates $R_t^{\text{train}}$ as training surrogate | **NO** | 🟢 CLOSED |
| **3. Outage Penalty Bound** | Theoretical Retraction | Removed invalid dominance bound; adopted calibrated scaling principle | **NO** | 🟢 CLOSED |
| **4. Client Diversity / Cherry-Picking** | Open Issue Designation | Retains $\mathcal{S}_t^{\text{cand}}$; defers diversity mechanisms to Stage 3C | **NO** | 🟢 CLOSED |

---

# 4. FINAL GATE DECISION

$$\boxed{\Huge\textbf{GREEN — STAGE 3B.1 PASSED}}$$

### Formal Gate Statement:

> **Stage 3B.1 is closed. Stage 2D remains frozen. The project may proceed to Stage 3C — DRL Algorithm Comparison.**

