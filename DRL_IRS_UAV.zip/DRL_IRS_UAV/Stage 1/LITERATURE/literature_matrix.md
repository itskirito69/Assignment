# STAGE 1: LITERATURE AUDIT & COMPARATIVE MATRIX
## Focused Survey of Robust Secrecy, RIS-Assisted UAV Networks, and BCD/SCA/MM Convergence

---

### Literature Matrix

| # | Reference Citation | System & Setup | Variables Optimized | Deliberately Excluded Variables | Secrecy Formulation | CSI Uncertainty Model | Decomposition Architecture | Convergence Argument | Relevance to Our Stage 1 Architecture |
|---|:---|:---|:---|:---|:---|:---|:---|:---|:---|
| **[R1]** | **Li et al. (2024)**<br>*Phys. Commun.*, vol. 67, 102504.<br>(Our Base Paper) | Single UAV, 1 IRS, $K$ wireless-powered FL users. | $P_c, T, r, \Theta, p_k, b_k, f_k$. | Eavesdropper secrecy, multi-antenna beamforming, user scheduling, trajectory. | **NONE** (No security model). | Perfect legitimate CSI. | 4 subproblems: $\Theta \to (P_c, T) \to (p,b,f) \to r$. | Monotonic objective decrease (heuristic; $\Theta$ phase alignment flawed for $K>1$). | **Primary Physical Reference.** Baseline FL, WPT, and computing models. |
| **[R2]** | **Wang et al. (2021)**<br>*IEEE TWC*, vol. 20, no. 11, pp. 7148–7162. | UAV-enabled wireless powered communication network. | UAV trajectory, energy beamforming, user transmit time/power. | IRS, federated learning, robust secrecy. | No secrecy. | Perfect CSI. | BCD + SCA on non-convex flight trajectory. | Monotone bounded sequence converges to local optimum. | Validates elimination of intermediate time variables and $(P_c, T)$ condensation in WPCN. |
| **[R3]** | **Miao et al. (2022)**<br>*IEEE TCOM*, vol. 70, no. 5, pp. 3432–3446. | Robust IRS-assisted secure multi-user communication with imperfect Eve CSI. | Base station beamforming, IRS phase shifts $v$. | UAV mobility, wireless power transfer, federated learning. | Secrecy rate maximization under bounded error: $\| \Delta g \|_2 \le \epsilon$. | Deterministic ellipsoidal/spherical uncertainty on Eve link. | BCD + S-Procedure + SCA on phase shifts. | Majorization-minimization guaranteeing stationary point convergence. | **Direct Secrecy Formulation Precedent.** Supports our deterministic bounded Eve CSI uncertainty ball. |
| **[R4]** | **Pan et al. (2020)**<br>*IEEE JSAC*, vol. 38, no. 11, pp. 2537–2552. | Multicell RIS-assisted transmission with physical-layer secrecy. | Beamforming vectors, RIS reflection phases $v$. | UAV, WPT, FL computing allocation. | Robust secrecy rate with eavesdroppers. | Worst-case deterministic CSI error. | BCD + Fractional Programming (Dinkelbach) + MM. | Dinkelbach quadratic transform converges monotonically to KKT point. | Justifies using Minorization-Maximization (MM) on the unit-modulus manifold $\mathbb{T}^N$. |
| **[R5]** | **Sun et al. (2022)**<br>*IEEE TWC*, vol. 21, no. 8, pp. 6081–6095. | Energy-efficient UAV-assisted federated learning with wireless power. | UAV 3D location, user power, bandwidth, CPU frequency. | IRS reflection, eavesdropping secrecy. | No secrecy. | Perfect CSI. | BCD + Successive Convex Approximation (SCA). | Objective sequence monotonic non-increasing, bounded below by zero. | Supports our exact CPU frequency closed-form boundary $f_k^*$ and bandwidth allocation. |
| **[R6]** | **Razaviyayn, Sanjabi, Luo (2013)**<br>*SIAM J. Optim.*, vol. 23, no. 2, pp. 1126–1153. | Foundational optimization theory: Block Successive Upper-bound Minimization (BSUM). | General partitioned variable blocks $x = (x_1, \dots, x_B)$. | N/A (Pure optimization theory). | General non-convex constraints. | N/A. | Block Coordinate Descent with local surrogate minorizers/majorizers. | **Theorem 2.3:** Proves accumulation points of BSUM/SCA are stationary points of original problem. | **Theoretical Anchor for Reviewer 2.** Guarantees that our SCA/MM BCD framework achieves true stationary points. |

---

### Key Takeaways for Stage 1 Architectural Decisions

1. **Physical Architecture Justification:**
   Our system variable set $(r, v, p, b, f, E_{\mathrm{WPT}}, T)$ matches the core degrees of freedom across [R1], [R2], and [R5], while stripping out secondary machinery (beamforming, multi-UAV scheduling, NOMA) that obscure the fundamental interaction between WPT, FL convergence, and physical-layer secrecy.
2. **Robust Secrecy Formulation:**
   References [R3] and [R4] confirm that deterministic spherical uncertainty ($\|\Delta g_{IE}\|_2 \le \epsilon_{IE}, |\Delta g_{UE,k}| \le \epsilon_{UE,k}$) is the standard, mathematically rigorous benchmark for non-cooperative eavesdroppers. Our exact closed-form signed-square/magnitude formulation avoids the conservative over-approximations of the S-procedure.
3. **Algorithm & Convergence Justification:**
   By designing our subproblems around Razaviyayn et al. [R6] (BSUM framework) rather than heuristic uncertified updates:
   - Every surrogate touches the original function tangentially.
   - The global objective decreases monotonically in every block.
   - The accumulation points are certified KKT points of the original reduced problem $\mathcal{P}_1$.
   This directly and permanently dismantles the prior reviewer criticisms.
