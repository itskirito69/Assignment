# STAGE 1: FORMAL DECISION LOG (DECISIONS.md)
## Secure IRS-Assisted UAV Wireless-Powered Federated Learning

---

### Decision D1 — Research Objective
- **Date:** October 22, 2026
- **Status:** **FROZEN**
- **Decision:** The research objective is formally defined as:
  > **Minimize the UAV wireless-power-transfer (WPT) energy required for sustainable federated learning while guaranteeing robust physical-layer secrecy under imperfect eavesdropper CSI in an IRS-assisted UAV wireless-powered FL system.**
- **Rationale:** Keeps the core contribution sharply focused on energy sustainability and robust physical-layer secrecy without inflating the problem scope.

---

### Decision D2 — Physical System Philosophy
- **Date:** October 22, 2026
- **Status:** **FROZEN**
- **Decision:** The physical architecture adheres strictly to the following three rules:
  1. **KEEP Base-Paper Physics**:
     - Single-antenna UAV operating at fixed altitude $H_A$.
     - IRS with $N$ passive phase-shift elements at fixed height $H_I$.
     - $K$ single-antenna wireless-powered ground FL users.
     - UAV wireless power transfer (RF energy harvesting with conversion efficiency $\lambda$).
     - User local model training (CPU computation).
     - Parallel uplink model transmission (FDMA/OFDMA with bandwidth $b_k$).
     - UAV horizontal position optimization $r = (x, y) \in \mathbb{R}^2$.
     - IRS phase optimization $\theta \in [0, 2\pi]^N$ (or $v \in \mathbb{T}^N$).
     - User transmit power allocation $p_k$, bandwidth allocation $b_k$, CPU allocation $f_k$.
     - UAV WPT energy minimization ($E_{\mathrm{WPT}} = P_c T$).
  2. **ADD Robust Physical-Layer Secrecy**:
     - One single-antenna ground eavesdropper (Eve).
     - Imperfect eavesdropper CSI with deterministic bounded channel uncertainty balls:
       $$\| \Delta g_{IE} \|_2 \le \epsilon_{IE}, \qquad |\Delta g_{UE,k}| \le \epsilon_{UE,k}.$$
     - Exact worst-case eavesdropper channel magnitude $|g_{e,k}(v)|^{\mathrm{wc}} = |z_k(v)| + \Delta_{E,k}$.
     - Exact deterministic robust secrecy rate constraint:
       $$R_{\mathrm{sec},k} = [R_k - R_{e,k}^{\mathrm{wc}}]^+ \ge R_{s,k}, \qquad \forall k \in \{1,\dots,K\}.$$
  3. **REMOVE Unnecessary Complexities**:
     - No user scheduling / time-division user association.
     - No complex UAV trajectory optimization (UAV hover position $r = (x,y)$ is optimized).
     - No multi-antenna beamforming (single-antenna UAV avoids complicating the base model).
     - No artificial noise (AN) injection.
     - No NOMA.
     - No multiple UAVs.
     - No IRS element on/off selection or amplitude attenuation ($|\beta_n| = 1$).
     - No Byzantine attack defenses or FL aggregation rule modifications.

---

### Decision D3 — Optimization Architecture Philosophy
- **Date:** October 22, 2026
- **Status:** **FROZEN**
- **Decision:** Abandon the monolithic Riemannian Augmented Lagrangian Method (ALM) with high penalty parameter continuation.
- **Rationale:** 
  The extensive numerical forensics of Stage 10 (Stages 10E.2 through 10E.8C) proved conclusively that penalty parameter escalation ($\rho \to 781,250$) creates an infinitely steep, ill-conditioned non-convex canyon ($\kappa \sim 10^7$) on the curved product manifold $\mathcal{M}$, causing catastrophic step-size collapse ($\alpha \to 10^{-16}$) across all candidate inner solvers (Steepest Descent, Spectral SD, L-BFGS, RTR, and preconditioned directions). 
  The new branch will adopt a decoupled Block Coordinate Descent (BCD) framework utilizing Successive Convex Approximation (SCA) and Minorization-Maximization (MM) only where non-convexity strictly requires it.

---

### Decision D4 — Exact Robust Secrecy Integrity
- **Date:** October 22, 2026
- **Status:** **FROZEN**
- **Decision:** The robust secrecy constraint must remain **exact** at the formulation level:
  $$|h_k(q,v)|^2 \ge \Gamma_k(b_k) (|z_k(v)| + \Delta_{E,k})^2 + \frac{b_k N_0}{p_k} (\Gamma_k(b_k) - 1), \quad \text{where } \Gamma_k(b_k) = 2^{R_{s,k}/b_k}.$$
- **Rationale:** Do not replace this exact constraint with an S-procedure, continuous smoothing, slack penalty heuristics, or artificial noise approximations. Any convex surrogate used in an SCA block must be rigorously proved to be a conservative (inner) minorization that preserves exact feasibility.

---

### Decision D5 — Codebase Protection & Zero Premature Implementation
- **Date:** October 22, 2026
- **Status:** **FROZEN**
- **Decision:** The existing codebase in `final codebase/stage3_implementation` remains 100% frozen (0 files modified). No MATLAB coding is permitted until Stage 1 mathematical reduction, variable inventory, elimination proofs, block classification, and convergence blueprint are fully audited and approved.

---

### Decision D6 — Elimination of Duration $T$, Power $P_c$, CPU $f_k$, and Power $p_k$
- **Date:** October 27, 2026
- **Status:** **FROZEN**
- **Decision:**
  1. Duration $T$ has no upper bound in the base paper; it is eliminated by feasible-set projection onto $(E, q, v, b)$, with canonical minimum-latency recovery $T_{\mathrm{rec}} = \max(T_{\mathrm{lat}}, E/P_c^{\max})$.
  2. UAV transmit power $P_c$ is eliminated via $E = P_c T$.
  3. CPU frequency is uniquely optimal at physical minimum: $f_k^* = f_k^{\min}$.
  4. User upload power is uniquely optimal on the secrecy boundary: $p_k^* = p_k^{\mathrm{sec}}(b_k, q, v)$.

---

### Decision D7 — Global Strict Convexity & Monotonicity of Bandwidth Allocation
- **Date:** October 27, 2026
- **Status:** **FROZEN**
- **Decision:**
  1. The composite user energy demand $E_k(b_k; q, v)$ is analytically proven strictly decreasing ($E_k'(b) < 0$) and strictly convex ($E_k''(b) > 0$) on $(b_{\min,k}^{\mathrm{sec}}, \infty)$.
  2. The sum-bandwidth constraint $\sum_k b_k = B$ is strictly active at any optimal solution.
  3. The global resource allocation block $(E, b)$ for fixed $(q, v)$ is a disciplined, strictly convex program requiring zero SCA, MM, or penalty heuristics.
  4. Stage 2C is formally authorized.

---

### Decision D8-R — Forensic Re-Audit of Stage 2C (Retraction of GREEN, Classified YELLOW)
- **Date:** October 27, 2026
- **Status:** **FROZEN / ACTIVE AUDIT STATUS**
- **Decision:**
  1. **Retraction of Closed-Form IRS Update**: The claim that the IRS subproblem has a closed-form phase projection update $v_n = e^{j \arg(w_{\mathrm{agg},n})}$ is mathematically false. The constrained multi-user epigraph problem on $\mathbb{T}^N$ with $K$ secrecy constraints is a non-convex, NP-hard QCQP with no closed form.
  2. **Singularity at $z_k(v^{(r)}) = 0$**: The candidate majorizer $\widetilde{G}_k(v; v^{(r)})$ diverges to $+\infty$ at $z_k = 0$. $\epsilon$-smoothing breaks exact tightness and invalidates the descent lemma.
  3. **Trust-Region Restriction for $q$-SCA**: The concave channel minorizer $\widetilde{H}_k(q)$ drops below the secrecy threshold within 1–2 meters. The surrogate $\widetilde{E}_k(q)$ is convex only within an explicit trust-region domain $\mathcal{D}_q(q^{(r)}) = \{q : \widetilde{H}_k(q) \ge H_{\mathrm{thresh},k} + \delta_{\mathrm{sec}}\}$.
  4. **Status & Authorization**: Stage 2C is classified as **YELLOW** (partial reduction certified, IRS block intrinsically non-convex). Stage 2D authorization is **SUSPENDED** until a legitimate constrained IRS solver architecture (e.g., disciplined SDR or element-wise BCD) is mathematically formulated.



