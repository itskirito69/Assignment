# STAGE 2C — FORENSIC RE-AUDIT: NON-CONVEXITY, TRACTABILITY, AND MONOTONICITY DEFICITS

**Author / Auditor**: Antigravity Mathematical Optimization Forensic Auditor  
**Date**: October 27, 2026  
**Status**: RETRACTED GREEN → **CLASSIFIED YELLOW / DEFICIT EXPOSED**  
**Mandate**: Re-audit the four central claims of the Stage 2C derivation without defending the previous verdict, with special focus on the claimed closed-form IRS update $v_n = e^{j \arg(w_n)}$.

---

## 1. EXECUTIVE VERDICT

$$\boxed{\text{PREVIOUS GREEN VERDICT IS FORMALLY RETRACTED}}$$
$$\boxed{\text{CURRENT STATUS: YELLOW — PARTIAL REDUCTION CERTIFIED, IRS BLOCK IS INTRINSICALLY NON-CONVEX}}$$

The previous Stage 2C report suffered from **four critical mathematical defects** that must be formally acknowledged and corrected:

1. **The Closed-Form IRS Update Claim is FALSE**:  
   The update $v_n = e^{j \arg(w_{\mathrm{agg},n})}$ is **NOT** the solution of the IRS subproblem. It is merely the unconstrained maximizer of an isolated linear function $\operatorname{Re}\{w_{\mathrm{agg}}^H v\}$ on $\mathbb{T}^N$. It completely ignores:
   - The multi-user minimax coupling ($\max_{k=1,\ldots,K} E_k(v)$);
   - The $K$ non-convex robust secrecy constraints ($H_k(v) - 2^{R_s/b_k} G_k(v) \ge \text{threshold}_k$);
   - The individual user peak-power constraints ($p_k^{\mathrm{sec}}(v) \le p_{\max}$).  
   Executing $v_n = e^{j \arg(w_{\mathrm{agg},n})}$ will, in general, violate secrecy for multiple users, render $E_k(v)$ undefined/negative, and destroy the outer BCD monotonicity chain.
2. **Singularity at $z_k(v^{(r)}) = 0$**:  
   The proposed majorizer $\widetilde{G}_k(v; v^{(r)})$ contains the coefficient $\frac{\Delta_{E,k}}{|z_k(v^{(r)})|}$, which **diverges to $+\infty$** if the nominal eavesdropper channel vanishes ($z_k(v^{(r)}) = 0$). Smoothing via $\sqrt{|z_k|^2 + \delta_0^2}$ introduces a strictly positive gap $\delta_0 > 0$ at the incumbent, which breaks the exact tightness condition of BSUM and invalidates the descent lemma.
3. **Domain Invalidation of the $q$-Surrogate**:  
   The concave minorizer $\widetilde{H}_k(q; q^{(r)}) = H_k(q^{(r)}) + \nabla H_k^T (q - q^{(r)}) - \frac{M_q}{2} \|q - q^{(r)}\|_2^2$ is a downward parabola that drops below the physical secrecy threshold $2^{R_s/b_k} G_k(v)$ outside a small neighborhood of $q^{(r)}$ (often within 1–2 meters). Outside this neighborhood, $E_k(\widetilde{H}_k(q))$ becomes undefined or complex. The subproblem is **NOT** globally convex on $\mathcal{Q}$; it requires an explicit trust-region / domain constraint $\widetilde{H}_k(q; q^{(r)}) \ge 2^{R_s/b_k} G_k(v) + \epsilon$.
4. **Broken BCD Monotonicity Chain**:  
   Because the intermediate IRS iterate $v^{(r+1)}$ cannot be obtained in closed form and cannot be guaranteed feasible via unconstrained projection, the claim that $E(q^{(r+1)}, v^{(r+1)}, b^{(r+1)}) \le E(q^{(r)}, v^{(r)}, b^{(r)})$ was an unproven conjecture.

---

## 2. RE-AUDIT OF CLAIM 1: $z_k(v^{(r)}) = 0$ EXACT IRS MAJORIZATION

### 1. The Purported Majorizer
The candidate majorizer derived in the previous report was:
$$\widetilde{G}_k(v; v^{(r)}) = \left( 1 + \frac{\Delta_{E,k}}{|z_k(v^{(r)})|} \right) |z_k(v)|^2 + \Delta_{E,k} |z_k(v^{(r)})| + \Delta_{E,k}^2.$$

### 2. Forensic Breakdown at $z_k(v^{(r)}) = 0$
Consider an iterate $v^{(r)}$ where the nominal reflected Eve link cancels the direct Eve link:
$$z_k(v^{(r)}) = \hat{g}_{UE,k} + \hat{g}_{IE}^H \operatorname{diag}(v^{(r)}) h_{UI,k} = 0.$$
- **Divergence of the Majorizer**: The leading coefficient:
  $$\alpha_k^{(r)} = 1 + \frac{\Delta_{E,k}}{|z_k(v^{(r)})|} \longrightarrow 1 + \frac{\Delta_{E,k}}{0^+} = +\infty.$$
  The majorizer becomes identically undefined ($\infty$).
- **Mathematical Root Cause**: The majorizer was derived using the concavity of $t \mapsto \sqrt{t}$ at $t_0 = |z_k(v^{(r)})|^2$. But the derivative of $\sqrt{t}$ at $t=0$ is:
  $$\left. \frac{d\sqrt{t}}{dt} \right|_{t=0} = \lim_{t \downarrow 0} \frac{1}{2\sqrt{t}} = +\infty.$$
  The function $\sqrt{t}$ has a vertical tangent at the origin. Therefore, **no finite linear upper bound tangent to $\sqrt{t}$ at $t=0$ exists**.

### 3. Failure of the $\epsilon$-Smoothing Fix
The previous report suggested smoothing via $\sqrt{|z_k(v)|^2 + \delta_0^2}$. Let us audit this claim:
- At $v = v^{(r)}$ with $z_k(v^{(r)}) = 0$:
  $$\text{True value: } |z_k(v^{(r)})| = 0.$$
  $$\text{Smoothed value: } \sqrt{0^2 + \delta_0^2} = \delta_0 > 0.$$
- This creates an **incumbent gap**:
  $$\widetilde{G}_k(v^{(r)}; v^{(r)}) = (\delta_0 + \Delta_{E,k})^2 > \Delta_{E,k}^2 = G_k(v^{(r)}).$$
- **Destruction of the BSUM Descent Guarantee**:  
  Under standard BSUM theory (Razaviyayn et al., 2013, Theorem 1), monotonic descent requires exact tightness at the incumbent:
  $$\widetilde{f}(x^{(r)}; x^{(r)}) = f(x^{(r)}).$$
  If $\widetilde{f}(x^{(r)}; x^{(r)}) = f(x^{(r)}) + \delta_0$, then an update $x^{(r+1)}$ that minimizes $\widetilde{f}$ satisfies:
  $$\widetilde{f}(x^{(r+1)}) \le \widetilde{f}(x^{(r)}) = f(x^{(r)}) + \delta_0.$$
  However, because $f(x^{(r+1)}) \le \widetilde{f}(x^{(r+1)})$, it is entirely possible that:
  $$f(x^{(r+1)}) = f(x^{(r)}) + \frac{1}{2}\delta_0 > f(x^{(r)}).$$
  **The true objective can increase! Monotonic descent is completely lost.**

---

## 3. RE-AUDIT OF CLAIM 2: TRACTABILITY OF THE IRS SUBPROBLEM

### 1. The True Constrained IRS Subproblem
For fixed UAV position $q$ and bandwidth allocation $b$, the exact IRS subproblem is:
$$\begin{aligned}
\min_{E \in \mathbb{R},\, v \in \mathbb{C}^N} \quad & E \\
\text{subject to} \quad & E \ge E_k(b_k; q, v), \quad \forall k \in \{1,\ldots,K\}, \\
& H_k(q, v) - 2^{R_s/b_k} G_k(v) \ge \frac{N_0 b_k}{p_{\max}} \left( 2^{R_s/b_k} - 1 \right), \quad \forall k \in \{1,\ldots,K\}, \\
& |v_n| = 1, \quad \forall n \in \{1,\ldots,N\}.
\end{aligned}$$

### 2. Dissection of the "Closed-Form Projection" Fallacy
The previous report claimed:
> *"The IRS surrogate objective on $\mathbb{T}^N$ reduces to an unconstrained linear maximization... This yields the exact, closed-form unimodular phase projection update: $v_n^{(r+1)} = e^{j \arg(w_{\mathrm{agg},n})}$."*

This claim is **completely indefensible**:

1. **It Ignores the $K$ Secrecy Constraints**:  
   The update $v_n = e^{j \arg(w_{\mathrm{agg},n})}$ is chosen to maximize a single aggregate phase alignment. It contains **no mechanism** to enforce the $K$ distinct quadratic inequality constraints:
   $$H_k(v) - 2^{R_s/b_k} G_k(v) \ge \text{threshold}_k.$$
   In any non-trivial multi-user topology, aligning with an aggregate vector will reduce the legitimate gain or increase the Eve leakage for some user $k$, driving $H_k - 2^{R_s/b_k} G_k < 0$. This causes $p_k^{\mathrm{sec}}(v) < 0$ or undefined, which is a catastrophic constraint violation.
2. **It Confuses a Minimax Epigraph with a Single Linear Objective**:  
   The true objective is $E = \max_{k=1,\ldots,K} E_k(v)$. Even if each $E_k(v)$ were majorized by a linear function $\operatorname{Re}\{r_k^H v\} + c_k$, the resulting subproblem is:
   $$\min_{v \in \mathbb{T}^N} \max_{k=1,\ldots,K} \left( \operatorname{Re}\{r_k^H v\} + c_k \right).$$
   This is a **minimax problem over the non-convex torus $\mathbb{T}^N$**. It CANNOT be solved by taking a linear combination $w_{\mathrm{agg}} = \sum r_k$ and projecting it. Minimax optimization requires finding the active subgradient / saddle point among the $K$ users.
3. **NP-Hardness of the Subproblem**:  
   Minimizing a convex function (or even a linear epigraph) subject to $K$ quadratic constraints over the unit-modulus set $|v_n| = 1$ is a **non-convex Quadratically Constrained Quadratic Program (QCQP)**, which is proven NP-hard (Luo et al., IEEE SPM 2010).  
   Claiming a "closed-form solution" for an NP-hard problem without an exact rank-1 recovery proof is a textbook mathematical error.

---

## 4. RE-AUDIT OF CLAIM 3: STRICT CONVEXITY AND DOMAIN VALIDITY OF THE $q$-SURROGATE

### 1. The Candidate Minorizer
The surrogate legitimate channel gain was defined as:
$$\widetilde{H}_k(q; q^{(r)}) = H_k(q^{(r)}) + \nabla_q H_k(q^{(r)})^T (q - q^{(r)}) - \frac{M_{q,k}}{2} \|q - q^{(r)}\|_2^2.$$

### 2. The Domain Collapse Deficit
Recall that the energy function $E_k(H)$ is given by:
$$E_k(H) = \frac{e_k^{\ell,\min}}{\lambda H} + \frac{N_0 D \ln 2}{\lambda H^2} \cdot \frac{\gamma_k(H)}{\ln(1 + \gamma_k(H))}, \qquad \gamma_k(H) = \frac{2^{R_s/b_k} - 1}{1 - 2^{R_s/b_k} \frac{G_k}{H}}.$$
- **Physical Feasibility Domain**:  
  $E_k(H)$ is defined **ONLY** when the denominator of $\gamma_k$ is strictly positive:
  $$H > 2^{R_s/b_k} G_k(v) \triangleq H_{\mathrm{thresh},k}.$$
  If $H \le H_{\mathrm{thresh},k}$, the secrecy rate is physically unachievable, $p_k^{\mathrm{sec}} \le 0$, and $E_k(H)$ becomes negative, complex, or undefined.
- **Parabolic Decay of $\widetilde{H}_k(q)$**:  
  Because $\widetilde{H}_k(q; q^{(r)})$ has a quadratic penalty $-\frac{M_{q,k}}{2} \|q - q^{(r)}\|_2^2$, as $q$ moves away from $q^{(r)}$:
  $$\lim_{\|q - q^{(r)}\|_2 \to \infty} \widetilde{H}_k(q; q^{(r)}) = -\infty.$$
  In typical UAV-IRS channels with path loss $\beta_0 \sim 10^{-4}$ and distance $d \sim 50$ m, $H_k \sim 10^{-5}$ to $10^{-6}$.  
  If $M_{q,k} \sim 10^{-5}$, then for $\|q - q^{(r)}\|_2 \ge 1.5$ meters:
  $$\frac{M_{q,k}}{2} \|q - q^{(r)}\|_2^2 \approx 1.1 \times 10^{-5} > H_k(q^{(r)}) - H_{\mathrm{thresh},k}.$$
  Therefore, **within a 1.5-meter displacement, $\widetilde{H}_k(q)$ drops below the secrecy threshold and becomes negative!**

### 3. Mathematical Consequence
$\widetilde{E}_k(q) \triangleq E_k(\widetilde{H}_k(q))$ is **NOT** a convex function on $\mathcal{Q} = \{q : \|q\|_2 \le d_{\max}\}$.  
It is only convex on the restricted interior trust-region domain:
$$\mathcal{D}_q(q^{(r)}) \triangleq \left\{ q \in \mathcal{Q} : \widetilde{H}_k(q; q^{(r)}) \ge 2^{R_s/b_k} G_k(v) + \delta_{\mathrm{sec}}, \quad \forall k=1,\ldots,K \right\}.$$
Treating the subproblem as an unconstrained convex optimization on $\mathcal{Q}$ will cause CVX / fmincon to evaluate points outside $\mathcal{D}_q$, producing `NaN` or unphysical negative energy values.

---

## 5. RE-AUDIT OF CLAIM 4: BCD/BSUM MONOTONICITY PROOF

The previous report claimed that the outer algorithm satisfies:
$$E(q^{(r+1)}, v^{(r+1)}, b^{(r+1)}) \le \widetilde{E}_b(b^{(r+1)}) \le \widetilde{E}_v(v^{(r+1)}) \le \widetilde{E}_q(q^{(r+1)}) \le E(q^{(r)}, v^{(r)}, b^{(r)}).$$

Let us forensically trace this inequality across intermediate steps:

1. **Step 1 ($q$-update)**:  
   $q^{(r+1)} = \arg\min_{q \in \mathcal{D}_q} \max_k \widetilde{E}_k(q; q^{(r)})$.  
   Because $\widetilde{E}_k(q)$ is a rigorous majorizer on $\mathcal{D}_q$:
   $$E(q^{(r+1)}, v^{(r)}, b^{(r)}) \le \max_k \widetilde{E}_k(q^{(r+1)}; q^{(r)}) \le \max_k \widetilde{E}_k(q^{(r)}; q^{(r)}) = E(q^{(r)}, v^{(r)}, b^{(r)}).$$
   **Step 1 holds** (provided the domain restriction $q \in \mathcal{D}_q$ is enforced).
2. **Step 2 ($v$-update)**:  
   Fix $(q^{(r+1)}, b^{(r)})$.  
   If $v^{(r+1)}$ is generated via the heuristic projection $v_n = e^{j \arg(w_{\mathrm{agg},n})}$:
   - Does $\widetilde{E}_v(v^{(r+1)}) \le E(q^{(r+1)}, v^{(r)}, b^{(r)})$? **NO PROOF.**
   - Is $v^{(r+1)}$ even feasible for the secrecy constraints? **NO PROOF.**
   - Does $E(q^{(r+1)}, v^{(r+1)}, b^{(r)}) \le E(q^{(r+1)}, v^{(r)}, b^{(r)})$? **FALSE IN GENERAL.**
   Because $v^{(r+1)}$ does not minimize a valid majorizer subject to the constraints, it can increase the true energy $E$ or cause infeasibility.
3. **Breakdown of the Chain**:  
   Because Step 2 fails, the entire descent chain collapses:
   $$E(q^{(r+1)}, v^{(r+1)}, b^{(r+1)}) \not\le E(q^{(r)}, v^{(r)}, b^{(r)}).$$
   **Monotonic descent is NOT established.**

---

## 6. WHAT IS THE GENUINELY DEFENSIBLE MATHEMATICAL STATUS?

Let us clearly separate what is mathematically proven from what is unproven:

| Problem Component | Current Mathematical Status | Defensible Formulation |
|---|---|---|
| **Resource Block $(E, b)$** | **PROVEN STRICTLY CONVEX** | Solvable to machine precision via CVX / interior-point. $\sum_k b_k = B$ strictly binds. |
| **UAV Position Block ($q$)** | **PROVEN CONVEX ON TRUST-REGION** | Requires explicit domain constraint $\widetilde{H}_k(q) \ge H_{\mathrm{thresh},k} + \delta_{\mathrm{sec}}$. Solvable via convex QCQP. |
| **IRS Phase Block ($v$)** | **NON-CONVEX / NP-HARD QCQP** | **NO CLOSED FORM EXISTS.** Requires a legitimate constrained algorithm (e.g., SDR + Gaussian randomization, or manifold trust-region with exact penalty). |
| **BCD Monotonicity** | **CONDITIONAL / UNPROVEN** | Holds **ONLY IF** the IRS subproblem is solved with guaranteed feasibility and objective descent. |

---

## 7. RECOMMENDATION AND FORMAL DECISION

### Formal Decision:
$$\boxed{\text{STAGE 2C STATUS: YELLOW — DEFICIT CERTIFIED}}$$
$$\boxed{\textbf{STAGE 2D AUTHORIZATION: SUSPENDED UNTIL IRS SOLVER IS RE-ARCHITECTED}}$$

### Required Remedial Steps Before Stage 2D:
1. **Retract the claim of a closed-form IRS update** $v_n = e^{j \arg(w_n)}$.
2. **Formulate the IRS subproblem as an explicit constrained non-convex optimization problem**:
   Choose a mathematically defensible solver architecture:
   - **Route A (Disciplined SDR)**: Linearize the DC terms in $V = v v^H$, solve the relaxed SDP in CVX, and establish a rank-1 approximation bound.
   - **Route B (Block Coordinate Descent over IRS Elements $\theta_n$)**: Optimize one phase $\theta_n \in [0, 2\pi]$ at a time in 1D while keeping the other $N-1$ phases fixed. For 1D, feasibility and descent can be checked exactly.
   - **Route C (Exact Penalty / Augmented Lagrangian on $\mathbb{T}^N$)**: Incorporate the secrecy constraints into a smooth penalty on $\mathbb{T}^N$, ensuring every step decreases a well-defined merit function.
3. **Incorporate the Trust-Region Domain Constraint** into the $q$-SCA subproblem.
