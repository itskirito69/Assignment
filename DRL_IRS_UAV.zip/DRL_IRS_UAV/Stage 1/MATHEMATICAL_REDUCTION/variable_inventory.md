# STAGE 1: VARIABLE INVENTORY & CLASSIFICATION
## Comprehensive Audit of All System Variables in $\mathcal{P}_0 \longrightarrow \mathcal{P}_1$

---

### Variable Audit Table

| Variable | Physical Meaning | Dimension / Domain | Classification | Mathematical Justification & Reference |
|:---|:---|:---:|:---:|:---|
| **$r = (x, y)$** | UAV horizontal hover position | $\mathbb{R}^2, \|r\|_2 \le d$ | **KEEP** | Directly optimizes spatial LoS path losses $d_{UA,k}(r)$ and $d_{IA}(r)$. Cannot be eliminated without loss of spatial degrees of freedom. |
| **$H_A$** | UAV flight altitude | $\mathbb{R}_{++}$ | **FIX** | Fixed operational altitude determined by FAA regulation / flight corridor constraints (Base paper Section 2). |
| **$H_I$** | IRS mounting height | $\mathbb{R}_{++}$ | **FIX** | Static building installation parameter. |
| **$v = [e^{j\theta_1}, \dots, e^{j\theta_N}]^T$** | IRS passive reflection vector | $\mathbb{T}^N \subset \mathbb{C}^N$ | **KEEP** | Controls multi-user channel alignment and spatial nulling toward Eve. Cannot be eliminated; essential for secrecy gain. |
| **$P_c$** | UAV WPT transmit power | $[0, P_c^{\max}]$ | **ELIMINATE** | **Proven redundant in Theorem 2 & WPT reduction.** Couples with $T$ strictly via $E_{\mathrm{WPT}} = P_c T$. Recovered uniquely as $P_c^* = E_{\mathrm{WPT}}/T$. |
| **$E_{\mathrm{WPT}}$** | Total UAV WPT energy | $\mathbb{R}_+$ | **KEEP (Primary Obj)** | Direct physical objective $E_{\mathrm{WPT}} = P_c T$. Makes energy harvesting linear in optimization variables. |
| **$T$** | Total FL task duration | $\mathbb{R}_{++}$ | **DERIVED / EPIGRAPH** | **Proven in Theorem 2.** Defined by latency lower bound $T^* = \max(T_{\mathrm{latency}}, E_{\mathrm{WPT}}/P_c^{\max})$. Retained as epigraph variable in latency-coupled blocks. |
| **$t_k^u$** | User $k$ uplink transmission delay | $\mathbb{R}_{++}$ | **ELIMINATE** | **Proven redundant in Theorem 1.** Optimal solution strictly attains boundary $t_k^{u*} = D / R_k(r, v, p_k, b_k)$. Replaced by explicit capacity function. |
| **$t_k^l$** | User $k$ local computing delay | $\mathbb{R}_{++}$ | **DERIVED** | Explicit function of CPU frequency: $t_k^l = R C_k D_k / f_k$. |
| **$e_k^l$** | User $k$ local computing energy | $\mathbb{R}_{+}$ | **DERIVED** | Explicit function of CPU frequency: $e_k^l = R \frac{\tau_k}{2} C_k D_k f_k^2$. |
| **$e_k^u$** | User $k$ communication energy | $\mathbb{R}_{+}$ | **DERIVED** | Explicit function of power and rate: $e_k^u = p_k t_k^u = p_k D / R_k$. |
| **$p_k$** | User $k$ transmit power | $[0, p_{\max}]$ | **KEEP** | Couples transmission rate $R_k$ and exact robust secrecy constraint C10. Can be conditionally optimized via Theorem 4. |
| **$b_k$** | User $k$ allocated bandwidth | $[0, B], \sum_k b_k \le B$ | **KEEP** | Couples spectral efficiency, secrecy capacity $\Gamma_k(b_k) = 2^{R_{s,k}/b_k}$, and upload latency. |
| **$f_k$** | User $k$ CPU clock frequency | $[f_k^{\min}, f_k^{\max}]$ | **DERIVED / KEEP** | **Analyzed in Theorem 3.** For fixed $T$, optimal frequency is $f_k^*(T) = \max\{f_k^{\min}, \frac{R C_k D_k}{T - t_k^u}\}$. Retained as scalar variable when optimizing computing allocation. |

---

### Variable Count Reduction Summary

- **Original Variables in $\mathcal{P}_0$:**
  - $P_c$ (1)
  - $T$ (1)
  - $r$ (2)
  - $\theta$ or $v$ ($N$)
  - $\{t_k^u\}$ ($K$)
  - $\{p_k\}$ ($K$)
  - $\{b_k\}$ ($K$)
  - $\{f_k\}$ ($K$)
  - **Total Variable Count:** $2 + N + 4K + 2 = N + 4K + 4$. For $N=40, K=20$, total = **124 variables**.

- **Reduced Variables in $\mathcal{P}_1$:**
  - $E_{\mathrm{WPT}}$ (1 scalar)
  - $T$ (1 scalar epigraph variable)
  - $r$ (2 spatial coordinates)
  - $v$ ($N$ phase variables)
  - $\{p_k\}$ ($K$ power variables)
  - $\{b_k\}$ ($K$ bandwidth variables)
  - $\{f_k\}$ ($K$ CPU frequencies)
  - **Total Variable Count:** $N + 3K + 4$. For $N=40, K=20$, total = **104 variables** (a reduction of $K = 20$ variables from $t_k^u$, with $P_c$ replaced by $E_{\mathrm{WPT}}$).
  - Furthermore, if $f_k$ and $p_k$ are evaluated in closed form conditionally within subproblems, the core continuous search space shrinks to **$(r, v, b, E_{\mathrm{WPT}}, T)$**, totaling only $N + K + 4 = 64$ continuous parameters!
