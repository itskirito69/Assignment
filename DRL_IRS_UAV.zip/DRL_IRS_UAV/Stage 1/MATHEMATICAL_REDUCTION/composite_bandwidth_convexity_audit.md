# STAGE 2B.1 — COMPOSITE BANDWIDTH CONVEXITY AND MONOTONICITY FORENSIC AUDIT

**Author / Auditor**: Antigravity Mathematical Optimization Forensic Auditor  
**Date**: October 27, 2026  
**Status**: CLOSED — MATHEMATICALLY PROVEN  
**Scope**: Exact reduction and global curvature audit of the composite user energy function $E_k(b_k; q, v)$ after the exact eliminations $f_k^* = f_k^{\min}$ and $p_k^* = p_k^{\mathrm{sec}}(b_k, q, v)$.

---

## A. EXECUTIVE VERDICT

$$\boxed{\text{GREEN — PROVEN}}$$

Every mathematical gate specified in the audit has been rigorously and analytically established:

1. **Strict Monotonicity Proven**: The composite user energy demand $E_k(b_k; q, v)$ is **strictly decreasing** in bandwidth $b_k$ throughout its entire open feasible domain $(b_{\min,k}^{\mathrm{sec}}, \infty)$:
   $$\frac{dE_k}{db_k} < 0, \quad \forall b_k \in (b_{\min,k}^{\mathrm{sec}}, \infty).$$
2. **Strict Convexity Proven**: The second derivative with respect to bandwidth $b_k$ is **strictly positive** throughout its entire open feasible domain:
   $$\frac{d^2E_k}{db_k^2} > 0, \quad \forall b_k \in (b_{\min,k}^{\mathrm{sec}}, \infty).$$
   The proof does not rely on numerical sampling, approximations, or empirical heuristics. The second derivative has been decomposed into an exact sum of products of elementary terms, each of which is analytically proven strictly positive via the Fundamental Theorem of Calculus.
3. **Global Resource Epigraph Convexity Certified**: For any fixed spatial geometry $(q, v)$, the resource allocation problem in variables $(E, b)$ subject to epigraph constraints $E \ge E_k(b_k)$, individual physical peak-power constraints $b_k \ge \underline{b}_k$, and the total bandwidth budget $\sum_{k=1}^K b_k \le B$ is a **disciplined, strictly convex optimization problem**.
4. **Bandwidth Budget Strict Saturation Proven**: Because every $E_k(b_k)$ is strictly decreasing, the sum-bandwidth budget **strictly binds with equality** at any optimal solution:
   $$\sum_{k=1}^K b_k^* = B.$$
5. **No SCA/MM Required for the Resource Block**: The resource subproblem requires zero Successive Convex Approximation (SCA), zero Minorization-Maximization (MM), and zero penalty/barrier heuristics. It can be solved to machine precision via standard interior-point methods (e.g., CVX, MOSEK, SDPT3).

---

## B. EXACT COMPOSITE FUNCTION

### 1. Channel Definitions and Secrecy Model
For a fixed UAV hovering location $q \in \mathbb{R}^2$ and IRS reflection vector $v \in \mathbb{T}^N$, define the legitimate composite channel power gain and the worst-case eavesdropper channel power gain for user $k$:
$$H_k \triangleq |h_k(q,v)|^2 > 0,$$
$$G_k \triangleq \left(|z_k(v)| + \Delta_{E,k}\right)^2 \ge 0,$$
where $\Delta_{E,k} = \epsilon_{UE,k} + \epsilon_{IE}\|h_{UI,k}\|_2$. Physical feasibility of positive secrecy rate requires $H_k > G_k$.

### 2. Elimination of CPU Frequency and Transmit Power
From Stage 2B (Lemmas 1 and 3):
- The optimal CPU frequency is identically at its physical floor:
  $$f_k^* = f_k^{\min},$$
  yielding constant computing energy:
  $$e_k^{\ell,\min} = R \frac{\tau_k}{2} C_k D_k (f_k^{\min})^2.$$
- The communication energy $e_k^u(p_k) = \frac{p_k D}{b_k \log_2(1 + p_k H_k / (N_0 b_k))}$ is strictly increasing in transmit power $p_k$. Hence, to minimize energy demand, the transmit power must lie exactly on the secrecy boundary:
  $$p_k^*(b_k) = p_k^{\mathrm{sec}}(b_k) = \frac{N_0 b_k (2^{R_s/b_k} - 1)}{H_k - 2^{R_s/b_k} G_k},$$
  provided $H_k > 2^{R_s/b_k} G_k$.

### 3. Substitution into Uplink Communication Energy
The uplink upload time is:
$$t_k^u = \frac{D}{b_k \log_2\left( 1 + \frac{p_k^{\mathrm{sec}}(b_k) H_k}{N_0 b_k} \right)}.$$
Compute the effective signal-to-noise ratio $\gamma_k(b_k)$:
$$\gamma_k(b_k) \triangleq \frac{p_k^{\mathrm{sec}}(b_k) H_k}{N_0 b_k} = \frac{H_k}{N_0 b_k} \cdot \frac{N_0 b_k (2^{R_s/b_k} - 1)}{H_k - 2^{R_s/b_k} G_k} = \frac{2^{R_s/b_k} - 1}{1 - 2^{R_s/b_k} (G_k / H_k)}.$$
Notice the critical algebraic cancellation: **$N_0$ and $b_k$ cancel out identically from the SNR term!**

Now, upload energy is:
$$e_k^u(b_k) = p_k^{\mathrm{sec}}(b_k) t_k^u = D \left( \frac{p_k^{\mathrm{sec}}(b_k)}{b_k} \right) \frac{1}{\log_2(1 + \gamma_k(b_k))}.$$
Since $\frac{p_k^{\mathrm{sec}}(b_k)}{b_k} = \frac{N_0}{H_k} \gamma_k(b_k)$, substituting this yields:
$$e_k^u(b_k) = D \left( \frac{N_0}{H_k} \gamma_k(b_k) \right) \frac{\ln 2}{\ln(1 + \gamma_k(b_k))} = \frac{N_0 D \ln 2}{H_k} \cdot \frac{\gamma_k(b_k)}{\ln(1 + \gamma_k(b_k))}.$$
Notice again: **$b_k$ completely cancels in the ratio $p_k / b_k$ outside the logarithm!**  
Consequently, $e_k^u(b_k)$ depends on $b_k$ **solely and exclusively** through the scalar SNR term $\gamma_k(b_k)$!

### 4. Total WPT Energy Epigraph Contribution
The total WPT energy required by user $k$ is:
$$E_k(b_k; q, v) = \frac{e_k^{\ell,\min} + e_k^u(b_k)}{\lambda H_k} = \frac{e_k^{\ell,\min}}{\lambda H_k} + \frac{N_0 D \ln 2}{\lambda H_k^2} \cdot \frac{\gamma_k(b_k)}{\ln(1 + \gamma_k(b_k))}.$$
Define the fixed channel/system constants:
$$C_k^{(0)} \triangleq \frac{e_k^{\ell,\min}}{\lambda H_k} > 0, \qquad C_k^{(1)} \triangleq \frac{N_0 D \ln 2}{\lambda H_k^2} > 0.$$
Then the exact composite energy function is:
$$\boxed{E_k(b_k; q, v) = C_k^{(0)} + C_k^{(1)} \cdot \frac{\gamma_k(b_k)}{\ln(1 + \gamma_k(b_k))}.}$$

---

## C. DIMENSIONLESS REFORMULATION

To make the curvature analysis invariant to physical units, introduce the dimensionless variables:

### 1. Dimensionless Variables
- **Dimensionless Bandwidth Invariant**:
  $$u \triangleq \frac{R_s \ln 2}{b_k} > 0 \iff b_k = \frac{R_s \ln 2}{u}.$$
  Let $C \triangleq R_s \ln 2 > 0$, so $b_k = C / u$.
- **Normalized Eavesdropper-to-Legitimate Channel Ratio**:
  $$\rho_k \triangleq \frac{G_k}{H_k} \in [0, 1).$$
- **Normalized Uplink SNR**:
  $$\gamma(u, \rho_k) = \frac{e^u - 1}{1 - \rho_k e^u}.$$
- **Logarithmic Spectral Efficiency Factor**:
  $$L(u, \rho_k) \triangleq \ln(1 + \gamma(u, \rho_k)).$$
  Notice that:
  $$1 + \gamma(u, \rho_k) = 1 + \frac{e^u - 1}{1 - \rho_k e^u} = \frac{(1 - \rho_k) e^u}{1 - \rho_k e^u}.$$
  Therefore, the logarithm takes the exact decoupled form:
  $$L(u, \rho_k) = u + \ln(1 - \rho_k) - \ln(1 - \rho_k e^u).$$

### 2. Dimensionless Core Functions
Define:
$$g(\gamma) \triangleq \frac{\gamma}{\ln(1 + \gamma)}, \quad \gamma > 0,$$
and the composite function:
$$\psi(u; \rho_k) \triangleq g(\gamma(u, \rho_k)) = \frac{\gamma(u, \rho_k)}{L(u, \rho_k)}.$$
Then the energy demand is:
$$E_k(b_k) = C_k^{(0)} + C_k^{(1)} \psi\left( \frac{C}{b_k}; \rho_k \right).$$

### 3. Exact Feasible Domains
- The denominator of $\gamma(u, \rho_k)$ must remain strictly positive:
  $$1 - \rho_k e^u > 0 \iff e^u < \frac{1}{\rho_k} \iff u < \ln(1 / \rho_k) \triangleq u_{\max}(\rho_k).$$
- In terms of $u$:
  $$u \in (0, u_{\max}(\rho_k)) = \left(0, \ln \frac{H_k}{G_k}\right).$$
- In terms of bandwidth $b_k$:
  $$b_k \in (b_{\min,k}^{\mathrm{sec}}, \infty), \quad \text{where } b_{\min,k}^{\mathrm{sec}} \triangleq \frac{R_s \ln 2}{\ln(H_k / G_k)} = \frac{R_s}{\log_2(H_k / G_k)}.$$
  *(Note: If $\rho_k = 0$, $u_{\max} = \infty$ and $b_{\min,k}^{\mathrm{sec}} = 0$.)*

---

## D. FIRST-DERIVATIVE PROOF: STRICT MONOTONICITY

### 1. Chain-Rule Formulation
Differentiating $E_k(b_k) = C_k^{(0)} + C_k^{(1)} \psi(u(b))$ with respect to $b$:
$$\frac{dE_k}{db} = C_k^{(1)} \psi'(u) \frac{du}{db}.$$
Since $u = C / b$, we have:
$$\frac{du}{db} = -\frac{C}{b^2} = -\frac{u^2}{C} < 0.$$
Therefore:
$$\frac{dE_k}{db} = - \frac{C_k^{(1)}}{C} u^2 \psi'(u).$$
Because $C_k^{(1)} > 0$, $C > 0$, and $u > 0$, the sign of $\frac{dE_k}{db}$ is strictly the negative of the sign of $\psi'(u)$:
$$\boxed{\frac{dE_k}{db} < 0 \iff \psi'(u) > 0.}$$

### 2. Analytical Evaluation of $\psi'(u)$
By definition, $\psi(u) = g(\gamma(u))$, so $\psi'(u) = g'(\gamma(u)) \gamma'(u)$.

**Lemma D.1 (Strict Positivity of $g'(\gamma)$)**:
For all $\gamma > 0$,
$$g'(\gamma) = \frac{\ln(1 + \gamma) - \frac{\gamma}{1 + \gamma}}{\ln^2(1 + \gamma)} > 0.$$
*Proof*: Define $m(\gamma) \triangleq \ln(1 + \gamma) - \frac{\gamma}{1 + \gamma}$. At $\gamma = 0$, $m(0) = 0$. Differentiating for $\gamma > 0$:
$$m'(\gamma) = \frac{1}{1 + \gamma} - \frac{(1 + \gamma) - \gamma}{(1 + \gamma)^2} = \frac{\gamma}{(1 + \gamma)^2} > 0.$$
By the Fundamental Theorem of Calculus, $m(\gamma) = \int_0^\gamma \frac{t}{(1+t)^2} dt > 0$ for all $\gamma > 0$. Since $\ln^2(1+\gamma) > 0$, $g'(\gamma) > 0$ strictly. $\blacksquare$

**Lemma D.2 (Strict Positivity of $\gamma'(u)$)**:
For all $u \in (0, u_{\max}(\rho_k))$,
$$\gamma'(u) = \frac{(1 - \rho_k) e^u}{(1 - \rho_k e^u)^2} > 0.$$
*Proof*: Direct quotient rule differentiation of $\gamma(u) = \frac{e^u - 1}{1 - \rho_k e^u}$:
$$\gamma'(u) = \frac{e^u(1 - \rho_k e^u) - (e^u - 1)(-\rho_k e^u)}{(1 - \rho_k e^u)^2} = \frac{e^u - \rho_k e^{2u} + \rho_k e^{2u} - \rho_k e^u}{(1 - \rho_k e^u)^2} = \frac{(1 - \rho_k) e^u}{(1 - \rho_k e^u)^2}.$$
Since $\rho_k \in [0, 1)$ and $e^u > 0$, the numerator is strictly positive, and the denominator is strictly positive on $u \in (0, u_{\max})$. Hence $\gamma'(u) > 0$ strictly. $\blacksquare$

### 3. Conclusion on First Derivative
Since $\psi'(u) = g'(\gamma(u)) \gamma'(u)$ is the product of two strictly positive terms:
$$\psi'(u) > 0, \quad \forall u \in (0, u_{\max}(\rho_k)).$$
Consequently:
$$\boxed{\frac{dE_k}{db_k} = - \frac{C_k^{(1)}}{C} u^2 \psi'(u) < 0, \quad \forall b_k \in (b_{\min,k}^{\mathrm{sec}}, \infty).}$$
**Result**: $E_k(b_k)$ is **strictly decreasing** throughout the entire feasible bandwidth domain.

---

## E. SECOND-DERIVATIVE PROOF: STRICT CONVEXITY

This is the primary mathematical gate of the forensic audit.

### 1. Reduction of Second Derivative to Scalar Invariant $\Theta(u; \rho_k)$
Differentiating $\frac{dE_k}{db} = - \frac{C_k^{(1)}}{C} \left[ u^2 \psi'(u) \right]$ with respect to $b$:
$$\frac{d^2E_k}{db^2} = \frac{d}{db}\left( - \frac{C_k^{(1)}}{C} \left[ u^2 \psi'(u) \right] \right) = - \frac{C_k^{(1)}}{C} \frac{d}{du}\left[ u^2 \psi'(u) \right] \frac{du}{db}.$$
Substituting $\frac{du}{db} = -\frac{u^2}{C}$:
$$\frac{d^2E_k}{db^2} = \frac{C_k^{(1)}}{C^2} u^2 \frac{d}{du}\left[ u^2 \psi'(u) \right].$$
Define the dimensionless curvature indicator:
$$\boxed{\Theta(u; \rho_k) \triangleq \frac{d}{du}\left[ u^2 \psi'(u) \right] = 2u \psi'(u) + u^2 \psi''(u).}$$
Since $\frac{C_k^{(1)}}{C^2} u^2 > 0$, the sign of $\frac{d^2E_k}{db^2}$ is **identically equal** to the sign of $\Theta(u; \rho_k)$:
$$\boxed{\frac{d^2E_k}{db^2} > 0 \iff \Theta(u; \rho_k) > 0.}$$

---

### 2. Exact Factorization of $\psi'(u)$
From Section C, $L(u) = \ln(1 + \gamma(u))$. Compute its derivative with respect to $u$:
$$L'(u) = \frac{d}{du}\left[ u + \ln(1 - \rho_k) - \ln(1 - \rho_k e^u) \right] = 1 - \frac{-\rho_k e^u}{1 - \rho_k e^u} = 1 + \frac{\rho_k e^u}{1 - \rho_k e^u} = \frac{1}{1 - \rho_k e^u}.$$
Now, differentiate $\psi(u) = \frac{\gamma(u)}{L(u)}$:
$$\psi'(u) = \frac{\gamma'(u) L(u) - \gamma(u) L'(u)}{L(u)^2} = \frac{\frac{(1 - \rho_k)e^u}{(1 - \rho_k e^u)^2} L(u) - \frac{e^u - 1}{(1 - \rho_k e^u)^2}}{L(u)^2} = \frac{(1 - \rho_k) e^u L(u) - (e^u - 1)}{(1 - \rho_k e^u)^2 L(u)^2}.$$
Using the algebraic identities $(1 - \rho_k) e^u = (1 + \gamma)(1 - \rho_k e^u)$ and $e^u - 1 = \gamma (1 - \rho_k e^u)$, the numerator factors exactly as:
$$(1 - \rho_k) e^u L(u) - (e^u - 1) = (1 - \rho_k e^u) \left[ (1 + \gamma) \ln(1 + \gamma) - \gamma \right].$$
Dividing through by the factor $(1 - \rho_k e^u)$ in the denominator yields the exact, simplified representation:
$$\boxed{\psi'(u) = \frac{1}{1 - \rho_k e^u} \cdot J(\gamma(u)),}$$
where $J(\gamma)$ is the fundamental SNR-efficiency kernel:
$$\boxed{J(\gamma) \triangleq \frac{(1 + \gamma) \ln(1 + \gamma) - \gamma}{\ln^2(1 + \gamma)}.}$$

---

### 3. Product-Rule Decomposition of $\Theta(u; \rho_k)$
Using $\psi'(u) = \frac{J(\gamma(u))}{1 - \rho_k e^u}$, write:
$$u^2 \psi'(u) = \left( \frac{u^2}{1 - \rho_k e^u} \right) \cdot J(\gamma(u)).$$
Differentiating this product with respect to $u$ via the product rule yields:
$$\boxed{\Theta(u; \rho_k) = \frac{d}{du}\left[ \frac{u^2}{1 - \rho_k e^u} \right] \cdot J(\gamma(u)) + \left( \frac{u^2}{1 - \rho_k e^u} \right) \cdot \frac{dJ}{d\gamma} \cdot \frac{d\gamma}{du}.}$$
Define the four constituent terms:
$$\text{Term A} \triangleq \frac{d}{du}\left( \frac{u^2}{1 - \rho_k e^u} \right), \qquad \text{Term B} \triangleq \frac{u^2}{1 - \rho_k e^u},$$
$$\text{Term C} \triangleq \frac{dJ}{d\gamma}, \qquad \text{Term D} \triangleq \frac{d\gamma}{du}.$$
Then:
$$\Theta(u; \rho_k) = \text{Term A} \cdot J(\gamma) + \text{Term B} \cdot \text{Term C} \cdot \text{Term D}.$$

---

### 4. Rigorous Sign Proof of Each Constituent Term

#### Proof of Term A $> 0$:
$$\text{Term A} = \frac{2u(1 - \rho_k e^u) - u^2(-\rho_k e^u)}{(1 - \rho_k e^u)^2} = \frac{2u(1 - \rho_k e^u) + \rho_k u^2 e^u}{(1 - \rho_k e^u)^2}.$$
On the domain $u \in (0, u_{\max})$, we have $u > 0$, $1 - \rho_k e^u > 0$, and $\rho_k e^u \ge 0$.  
Therefore, the numerator is strictly positive:
$$2u(1 - \rho_k e^u) + \rho_k u^2 e^u > 0.$$
Since the denominator is squared, $\text{Term A} > 0$ strictly. $\blacksquare$

#### Proof of $J(\gamma) > 0$:
The numerator of $J(\gamma)$ is $n(\gamma) \triangleq (1 + \gamma)\ln(1 + \gamma) - \gamma$.  
Notice that $n(0) = 0$, and $n'(\gamma) = \ln(1 + \gamma) + 1 - 1 = \ln(1 + \gamma) > 0$ for all $\gamma > 0$.  
By the Fundamental Theorem of Calculus:
$$n(\gamma) = \int_0^\gamma \ln(1 + t) dt > 0, \quad \forall \gamma > 0.$$
Since the denominator $\ln^2(1 + \gamma) > 0$, we have $J(\gamma) > 0$ strictly for all $\gamma > 0$. $\blacksquare$

#### Proof of Term B $> 0$:
$$\text{Term B} = \frac{u^2}{1 - \rho_k e^u} > 0,$$
which is strictly positive because $u > 0$ and $1 - \rho_k e^u > 0$. $\blacksquare$

#### Proof of Term C $\triangleq \frac{dJ}{d\gamma} > 0$ (Key Analytical Step):
Differentiate $J(\gamma) = \frac{(1 + \gamma)\ln(1 + \gamma) - \gamma}{\ln^2(1 + \gamma)}$ with respect to $\gamma$:
$$\frac{dJ}{d\gamma} = \frac{\left[\ln(1 + \gamma) \cdot \ln^2(1 + \gamma)\right] - \left[(1 + \gamma)\ln(1 + \gamma) - \gamma\right] \cdot \left[2 \ln(1 + \gamma) \frac{1}{1 + \gamma}\right]}{\ln^4(1 + \gamma)}.$$
Divide numerator and denominator by $\ln(1 + \gamma)$:
$$\frac{dJ}{d\gamma} = \frac{(1 + \gamma)\ln^2(1 + \gamma) - 2(1 + \gamma)\ln(1 + \gamma) + 2\gamma}{(1 + \gamma)\ln^3(1 + \gamma)}.$$
Let $x \triangleq \ln(1 + \gamma) > 0$, so $1 + \gamma = e^x$ and $\gamma = e^x - 1$. Express the numerator as a function of $x$:
$$N(x) \triangleq e^x x^2 - 2 e^x x + 2(e^x - 1) = e^x(x^2 - 2x + 2) - 2.$$
Let us evaluate $N(x)$ for all $x > 0$:
1. At $x = 0$:
   $$N(0) = e^0(0 - 0 + 2) - 2 = 2 - 2 = 0.$$
2. Compute the derivative $N'(x)$:
   $$N'(x) = e^x(x^2 - 2x + 2) + e^x(2x - 2) = e^x\left(x^2 - 2x + 2 + 2x - 2\right) = x^2 e^x.$$
3. Notice that $x^2 e^x > 0$ strictly for all $x > 0$.
4. By the Fundamental Theorem of Calculus:
   $$N(x) = \int_0^x t^2 e^t dt > 0, \quad \forall x > 0.$$
Because the denominator is $(1 + \gamma)\ln^3(1 + \gamma) = e^x x^3 > 0$ for all $x > 0$:
$$\boxed{\frac{dJ}{d\gamma} = \frac{\int_0^{\ln(1+\gamma)} t^2 e^t dt}{(1 + \gamma)\ln^3(1 + \gamma)} > 0, \quad \forall \gamma > 0.}$$
This proves that Term C is **strictly positive everywhere on $\gamma > 0$ without exception**. $\blacksquare$

#### Proof of Term D $\triangleq \frac{d\gamma}{du} > 0$:
Proven in Lemma D.2: $\frac{d\gamma}{du} = \frac{(1 - \rho_k)e^u}{(1 - \rho_k e^u)^2} > 0$ strictly. $\blacksquare$

---

### 5. Final Synthesis of the Curvature Proof
Every constituent term in $\Theta(u; \rho_k)$ is strictly positive:
- $\text{Term A} > 0$,
- $J(\gamma) > 0$,
- $\text{Term B} > 0$,
- $\text{Term C} > 0$,
- $\text{Term D} > 0$.

Therefore:
$$\Theta(u; \rho_k) = \underbrace{\text{Term A} \cdot J(\gamma)}_{> 0} + \underbrace{\text{Term B} \cdot \text{Term C} \cdot \text{Term D}}_{> 0} > 0, \quad \forall u \in (0, u_{\max}(\rho_k)).$$
Consequently, the second derivative of the user energy demand:
$$\boxed{\frac{d^2E_k}{db_k^2} = \frac{C_k^{(1)}}{C^2} u^2 \Theta(u; \rho_k) > 0, \quad \forall b_k \in (b_{\min,k}^{\mathrm{sec}}, \infty).}$$
**Result**: $E_k(b_k)$ is **strictly convex** over its entire open feasible domain $(b_{\min,k}^{\mathrm{sec}}, \infty)$.

---

## F. BOUNDARY ANALYSIS

### 1. Secrecy Boundary Limit ($b_k \downarrow b_{\min,k}^{\mathrm{sec}}$)
As $b_k \to b_{\min,k}^{\mathrm{sec}} = \frac{R_s}{\log_2(H_k / G_k)}$ from above:
- $u \uparrow u_{\max} = \ln(1 / \rho_k)$.
- $1 - \rho_k e^u \downarrow 0^+$.
- $\gamma_k(u) \to +\infty$.
- Transmit power $p_k^{\mathrm{sec}}(b_k) \to +\infty$.
- Upload energy $e_k^u(b_k) \approx \frac{N_0 D \ln 2}{H_k} \frac{\gamma_k}{\ln \gamma_k} \to +\infty$.
- Total energy $E_k(b_k) \to +\infty$.
- Derivative: $\frac{dE_k}{db_k} \to -\infty$.
- Second derivative: $\frac{d^2E_k}{db_k^2} \to +\infty$.
*Physical meaning*: Achieving secrecy rate $R_s$ with bandwidth approaching the physical cut-off $b_{\min}^{\mathrm{sec}}$ demands infinite transmit power and infinite energy. The function has a vertical asymptote at $b_{\min,k}^{\mathrm{sec}}$, forming a natural barrier.

### 2. Large-Bandwidth Limit ($b_k \to \infty$)
As $b_k \to \infty$:
- $u \downarrow 0^+$.
- $\gamma_k(u) \downarrow 0^+$.
- $\lim_{u \to 0} \psi(u) = \lim_{\gamma \to 0} \frac{\gamma}{\ln(1+\gamma)} = 1$.
- Upload energy approaches the wideband Shannon limit:
  $$\lim_{b_k \to \infty} e_k^u(b_k) = \frac{N_0 D \ln 2}{H_k}.$$
  *(This is the fundamental minimum physical energy required to transmit $D$ bits over AWGN with gain $H_k$, corresponding to $E_b/N_0 = \ln 2$.)*
- Total WPT energy approaches the horizontal asymptote:
  $$\lim_{b_k \to \infty} E_k(b_k) = \frac{e_k^{\ell,\min} + \frac{N_0 D \ln 2}{H_k}}{\lambda H_k} > 0.$$
- Derivatives:
  $$\lim_{b_k \to \infty} \frac{dE_k}{db_k} = 0^-, \qquad \lim_{b_k \to \infty} \frac{d^2E_k}{db_k^2} = 0^+.$$

### 3. Peak-Power Boundary ($p_k^{\mathrm{sec}}(b_k) \le p_{\max}$)
The transmit power is:
$$p_k^{\mathrm{sec}}(b_k) = \frac{N_0 b_k (2^{R_s/b_k} - 1)}{H_k - 2^{R_s/b_k} G_k} = \frac{N_0 C}{H_k} \cdot \frac{e^u - 1}{u(1 - \rho_k e^u)}.$$
Differentiating with respect to $u$:
$$\frac{d}{du}\left[ \frac{e^u - 1}{u(1 - \rho_k e^u)} \right] = \frac{(u e^u - e^u + 1)(1 - \rho_k e^u) + \rho_k u e^u (e^u - 1)}{u^2 (1 - \rho_k e^u)^2} > 0, \quad \forall u \in (0, u_{\max}).$$
Because $\frac{du}{db_k} < 0$, we have:
$$\frac{dp_k^{\mathrm{sec}}}{db_k} < 0, \quad \forall b_k \in (b_{\min,k}^{\mathrm{sec}}, \infty).$$
$p_k^{\mathrm{sec}}(b_k)$ is **strictly decreasing** in $b_k$.
- As $b_k \to \infty$, $p_k^{\mathrm{sec}}(b_k) \to \frac{N_0 R_s \ln 2}{H_k - G_k} \triangleq p_k^{\mathrm{sec},\infty}$.
- If $p_{\max} \le p_k^{\mathrm{sec},\infty}$, the problem is physically infeasible.
- If $p_{\max} > p_k^{\mathrm{sec},\infty}$, there exists a unique bandwidth threshold $b_k^{p_{\max}} > b_{\min,k}^{\mathrm{sec}}$ such that:
  $$p_k^{\mathrm{sec}}(b_k) \le p_{\max} \iff b_k \ge b_k^{p_{\max}}.$$
Therefore, the effective feasible lower bound on bandwidth for user $k$ is:
$$\underline{b}_k \triangleq \max\left\{ b_{\min,k}^{\mathrm{sec}}, b_k^{p_{\max}} \right\} = b_k^{p_{\max}}.$$
Over the physically feasible domain $[\underline{b}_k, \infty)$, $E_k(b_k)$ remains **strictly decreasing and strictly convex**.

---

## G. GLOBAL BANDWIDTH PROBLEM

For any fixed spatial state $(q, v)$, the resource allocation problem is:
$$\begin{aligned}
\min_{E \in \mathbb{R},\, b \in \mathbb{R}^K} \quad & E \\
\text{subject to} \quad & E - E_k(b_k) \ge 0, \quad \forall k=1,\ldots,K, \\
& \sum_{k=1}^K b_k \le B, \\
& b_k \ge \underline{b}_k, \quad \forall k=1,\ldots,K.
\end{aligned}$$

### Convexity Certification:
1. **Objective Function**: $f_0(E, b) = E$ is affine, hence convex.
2. **Epigraph Constraints**: For each $k$, the function $h_k(E, b_k) \triangleq E_k(b_k) - E$ has Hessian:
   $$\nabla^2 h_k(E, b_k) = \begin{bmatrix} 0 & 0 \\ 0 & E_k''(b_k) \end{bmatrix}.$$
   Since $E_k''(b_k) > 0$, $\nabla^2 h_k(E, b_k) \succeq 0$, so $h_k(E, b_k) \le 0$ is a **strictly convex constraint**.
3. **Bandwidth Budget**: $\sum_{k=1}^K b_k \le B$ is an affine inequality constraint.
4. **Box Bounds**: $b_k \ge \underline{b}_k$ define a convex polyhedral box.

Therefore, the global resource problem $(E, b)$ is a **disciplined, strictly convex optimization problem**.

---

## H. BANDWIDTH BUDGET: STRICT ACTIVE SATURATION

**Theorem H.1 (Strict Saturation of Total Bandwidth)**:  
At every optimal solution $(E^*, b^*)$, the total bandwidth budget constraint is strictly active:
$$\sum_{k=1}^K b_k^* = B.$$

*Proof*:  
Suppose for the sake of contradiction that $\sum_{k=1}^K b_k^* < B$. Then there exists a strictly positive slack:
$$\delta \triangleq B - \sum_{k=1}^K b_k^* > 0.$$
Define the active user index set at the optimum:
$$\mathcal{A} \triangleq \left\{ k \in \{1,\ldots,K\} : E_k(b_k^*) = E^* \right\}.$$
Because $E^* = \max_k E_k(b_k^*)$, the active set is non-empty: $|\mathcal{A}| \ge 1$.

Now construct a perturbed bandwidth allocation $\tilde{b}$:
$$\tilde{b}_k = \begin{cases}
b_k^* + \frac{\delta}{|\mathcal{A}|}, & \text{if } k \in \mathcal{A}, \\
b_k^*, & \text{if } k \notin \mathcal{A}.
\end{cases}$$
Check feasibility of $\tilde{b}$:
1. Total bandwidth:
   $$\sum_{k=1}^K \tilde{b}_k = \sum_{k \notin \mathcal{A}} b_k^* + \sum_{k \in \mathcal{A}} \left(b_k^* + \frac{\delta}{|\mathcal{A}|}\right) = \sum_{k=1}^K b_k^* + \delta = B \le B.$$
2. Lower bounds: $\tilde{b}_k \ge b_k^* \ge \underline{b}_k$.

Now evaluate the resulting energy demands:
- For any inactive user $j \notin \mathcal{A}$, $E_j(\tilde{b}_j) = E_j(b_j^*) < E^*$.
- For every active user $k \in \mathcal{A}$, because $E_k'(b) < 0$ strictly (proven in Section D) and $\frac{\delta}{|\mathcal{A}|} > 0$:
  $$E_k(\tilde{b}_k) < E_k(b_k^*) = E^*.$$
Consequently, the new maximum energy demand across all users satisfies:
$$\tilde{E} \triangleq \max_{k=1,\ldots,K} E_k(\tilde{b}_k) < E^*.$$
The pair $(\tilde{E}, \tilde{b})$ is strictly feasible and achieves an objective value strictly smaller than $E^*$. This contradicts the optimality of $(E^*, b^*)$.  
Therefore, no slack can exist at optimum: $\sum_{k=1}^K b_k^* = B$. $\blacksquare$

---

## I. MATHEMATICAL LEMMAS

### Lemma 1 (Exact Composite Representation) — PROVEN
The user WPT energy epigraph contribution after exact elimination of $f_k$ and $p_k$ is uniquely given by:
$$E_k(b_k) = C_k^{(0)} + C_k^{(1)} \cdot \frac{\gamma_k(b_k)}{\ln(1 + \gamma_k(b_k))},$$
where $C_k^{(0)}, C_k^{(1)} > 0$ are constants with respect to $b_k$, and $\gamma_k(b_k) = \frac{2^{R_s/b_k} - 1}{1 - 2^{R_s/b_k}(G_k / H_k)}$.

### Lemma 2 (Global Strict Monotonicity) — PROVEN
For any $q, v$ such that $H_k > G_k$, $E_k(b_k)$ is strictly decreasing on $(b_{\min,k}^{\mathrm{sec}}, \infty)$:
$$E_k'(b_k) < 0, \quad \forall b_k > b_{\min,k}^{\mathrm{sec}}.$$

### Lemma 3 (Global Strict Convexity) — PROVEN
For any $q, v$ such that $H_k > G_k$, $E_k(b_k)$ is strictly convex on $(b_{\min,k}^{\mathrm{sec}}, \infty)$:
$$E_k''(b_k) > 0, \quad \forall b_k > b_{\min,k}^{\mathrm{sec}}.$$

### Lemma 4 (Peak-Power Feasibility Interval) — PROVEN
The peak-power constraint $p_k^{\mathrm{sec}}(b_k) \le p_{\max}$ is equivalent to a single lower bound $b_k \ge \underline{b}_k$, preserving the strict convexity of the feasible set.

### Lemma 5 (Budget Equality) — PROVEN
At any optimal solution of the resource subproblem, $\sum_{k=1}^K b_k^* = B$.

---

## J. STAGE 1 / STAGE 2B CLAIM AUDIT

| Claim | Stage 1 Status | Stage 2B Status | Stage 2B.1 Audit Verdict | Mathematical Basis |
|---|---|---|---|---|
| $f_k^* = f_k^{\min}$ | Heuristic | Proven (Lemma 1) | **PROVEN** | Strictly minimizes local computing energy without altering feasible space. |
| $p_k^* = \max(p_k^{\mathrm{sec}}, p_k^{\mathrm{comm}})$ | Proposed | Refuted | **DISPROVEN / SUPERSEDED** | $p_k^{\mathrm{comm}}$ is a legacy artifact; unique optimum is $p_k^* = p_k^{\mathrm{sec}}(b_k)$. |
| $p_k^* = p_k^{\mathrm{sec}}(b_k)$ | Not recognized | Proven | **PROVEN** | Communication energy $e_k^u(p_k)$ is strictly increasing in $p_k$. |
| Joint $(p_k, b_k)$ convex | Claimed | Refuted (Indefinite) | **DISPROVEN** | Unconstrained $\det \nabla^2 e_k^u(p_k, b_k) < 0$; saddle function. |
| $E_k(b_k)$ strictly decreasing | Unproven | Numerical only | **PROVEN** | Analytical proof via Lemma D.1 & D.2: $E_k'(b) < 0$ everywhere. |
| $E_k(b_k)$ strictly convex | Unproven | Numerical only | **PROVEN** | Analytical proof via Theorem E: Term A, J, Term B, Term C, Term D all $>0$. |
| Global $(E, b)$ convex | Unproven | Plausible | **PROVEN** | Linear objective, convex epigraph, affine constraints. |
| SCA needed for resource block | Assumed | Unclear | **DISPROVEN / UNNECESSARY** | Resource block is 100% disciplined convex; standard interior-point solver solves it globally. |

---

## K. FINAL REDUCED MATHEMATICAL PROBLEM

With $T$, $P_c$, $f$, and $p$ rigorously and analytically eliminated, the exact full UAV-IRS secure WPCN-FL problem reduces to:

$$\boxed{
\begin{aligned}
\min_{E \in \mathbb{R},\, q \in \mathbb{R}^2,\, v \in \mathbb{T}^N,\, b \in \mathbb{R}^K} \quad & E \\
\text{subject to} \quad & E \ge \frac{e_k^{\ell,\min} + \frac{N_0 D \ln 2}{H_k(q,v)} \cdot \frac{\gamma_k(b_k, q, v)}{\ln(1 + \gamma_k(b_k, q, v))}}{\lambda H_k(q,v)}, \quad \forall k=1,\ldots,K, \\
& \sum_{k=1}^K b_k = B, \\
& b_k \ge \underline{b}_k(q,v), \quad \forall k=1,\ldots,K, \\
& q \in \mathcal{Q}, \\
& |v_n| = 1, \quad \forall n=1,\ldots,N.
\end{aligned}
}$$

### Variable Dimensionality Reduction:
- Original problem ($\mathcal{P}_0$): Variables $(E, T, P_c, q, v, p, b, f) \in \mathbb{R}^{3K + N + 5}$. For $K=20, N=40$, dimension was **105 variables**.
- Fully reduced problem ($\mathcal{P}_2$): Variables $(E, q, v, b) \in \mathbb{R}^{K + N + 3}$. For $K=20, N=40$, dimension is **63 variables** (a **40% reduction in search dimensions**).
- More critically: The entire resource block $(E, b)$ for fixed $(q, v)$ is **100% strictly convex**, meaning non-convexity in the entire system is strictly confined to:
  1. UAV horizontal position $q \in \mathbb{R}^2$ (addressed via geometric SCA in Stage 2C).
  2. IRS reflection phase vector $v \in \mathbb{T}^N$ (addressed via manifold MM on the complex torus in Stage 2C).

---

## L. STAGE 2B.1 DECISION & AUTHORIZATION

### Formal Decision:
$$\boxed{\text{CLOSED — GREEN}}$$

The exact mathematical status of the composite bandwidth function $E_k(b_k)$ is fully resolved and proven strictly convex and strictly decreasing.

### Stage 2C Authorization:
$$\boxed{\textbf{STAGE 2C IS AUTHORIZED}}$$

Stage 2C will now derive the exact surrogate minorizers for:
- **Block 1 (UAV Coordinates $q \in \mathbb{R}^2$)**: Successive Convex Approximation (SCA) surrogate for composite channel $H_k(q)$.
- **Block 2 (IRS Vector $v \in \mathbb{T}^N$)**: Minorization-Maximization (MM) surrogate for the Difference-of-Convex (DC) secrecy metric on the complex torus.
- **Block 3 (Resource Block $(E, b)$)**: Canonical disciplined convex formulation.
