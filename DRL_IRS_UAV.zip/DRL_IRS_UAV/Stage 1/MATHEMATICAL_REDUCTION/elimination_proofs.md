# STAGE 1: MATHEMATICAL AUDIT OF VARIABLE ELIMINATIONS
## Rigorous Equivalence Proofs for $t_k^u$, $T$, $(P_c, T) \to E_{\mathrm{WPT}}$, and $f_k$

---

### Theorem 1 (Exact Elimination of Uplink Transmission Delay $t_k^u$)

#### Statement
Let $(P_c, T, r, v, \{p_k\}, \{b_k\}, \{f_k\}, \{t_k^u\})$ be any feasible solution to $\mathcal{P}_0$. Then:
1. There exists an optimal solution $(P_c^*, T^*, r^*, v^*, \{p_k^*\}, \{b_k^*\}, \{f_k^*\}, \{t_k^{u*}\})$ in which constraint C3 holds with exact equality for every user $k \in \mathcal{K}$:
   $$t_k^{u*} b_k^* \log_2\left(1 + \frac{p_k^* |h_k(r^*,v^*)|^2}{N_0 b_k^*}\right) = D \iff t_k^{u*} = \frac{D}{R_k(r^*, v^*, p_k^*, b_k^*)}.$$
2. Replacing $t_k^u$ everywhere in $\mathcal{P}_0$ by the explicit function:
   $$t_k^u(r, v, p_k, b_k) \triangleq \frac{D}{b_k \log_2\left(1 + \frac{p_k |h_k(r,v)|^2}{N_0 b_k}\right)}$$
   preserves the optimal objective value and the feasible set of the remaining variables.

#### Proof
1. **Monotonicity in Constraints:**
   Examine every constraint in $\mathcal{P}_0$ where $t_k^u$ appears:
   - **Objective:** $\min P_c T$ (independent of $t_k^u$).
   - **C1 (Latency):** $\frac{R C_k D_k}{f_k} + t_k^u \le T$. Since the coefficient of $t_k^u$ is $+1 > 0$, decreasing $t_k^u$ strictly decreases the left-hand side, strictly loosening C1.
   - **C2 (Energy Causality):** $R \frac{\tau_k}{2} C_k D_k f_k^2 + p_k t_k^u \le \lambda T P_c |h_k|^2$. Since $p_k \ge 0$, the coefficient of $t_k^u$ is $p_k \ge 0$. Decreasing $t_k^u$ decreases (or leaves unchanged if $p_k=0$) the consumed communication energy $p_k t_k^u$, loosening C2.
   - **C3 (Upload Requirement):** $t_k^u R_k \ge D \iff t_k^u \ge \frac{D}{R_k}$. This is a simple lower bound on $t_k^u$.
   - **All other constraints (C4–C10):** Independent of $t_k^u$.
2. **Optimality of the Boundary:**
   Suppose for contradiction that an optimal solution has $t_k^u > \frac{D}{R_k}$ for some user $k$. Define $\widetilde{t}_k^u = \frac{D}{R_k} < t_k^u$.
   - Under $\widetilde{t}_k^u$, C3 remains satisfied: $\widetilde{t}_k^u R_k = D \ge D$.
   - Under $\widetilde{t}_k^u$, C1 satisfies: $\frac{R C_k D_k}{f_k} + \widetilde{t}_k^u < \frac{R C_k D_k}{f_k} + t_k^u \le T$.
   - Under $\widetilde{t}_k^u$, C2 satisfies: $e_k^l + p_k \widetilde{t}_k^u \le e_k^l + p_k t_k^u \le e_k$.
   - The objective $P_c T$ is unchanged.
   Hence, $\widetilde{t}_k^u$ is feasible and yields the exact same objective. Furthermore, setting $t_k^u = D/R_k$ creates slack in C1 and C2, which can only expand the feasible space for $(T, P_c, f_k)$.
3. **Conclusion:**
   $t_k^u$ is an auxiliary slack variable. Substituting $t_k^u = D/R_k$ into C1 and C2 is **strictly equivalent** and eliminates $K$ optimization variables. $\blacksquare$

---

### Theorem 2 (Condensation of $P_c$ and $T$ via $E_{\mathrm{WPT}} = P_c T$)

#### Statement
In problem $\mathcal{P}_0$, the pair of continuous scalar variables $(P_c, T) \in [0, P_c^{\max}] \times (0, \infty)$ can be condensed into the single energy variable:
$$E_{\mathrm{WPT}} \triangleq P_c T \ge 0,$$
and mission duration $T$, where:
1. The objective is directly $\min E_{\mathrm{WPT}}$.
2. The user harvested energy in C2 depends on $(P_c, T)$ **strictly** through their product:
   $$e_k = \lambda T P_c |h_k|^2 = \lambda E_{\mathrm{WPT}} |h_k|^2.$$
3. The coupling constraint C8 ($P_c \le P_c^{\max}$) is equivalent to the linear inequality:
   $$E_{\mathrm{WPT}} \le P_c^{\max} T \iff T \ge \frac{E_{\mathrm{WPT}}}{P_c^{\max}}.$$
4. If $T$ has no upper bound $T_{\max}$ (as in Li et al. 2024), $T$ can be set to its exact lower bound:
   $$T^*(E_{\mathrm{WPT}}, r, v, p, b, f) = \max\left\{ \frac{E_{\mathrm{WPT}}}{P_c^{\max}}, \; \max_{k \in \mathcal{K}} \left( \frac{R C_k D_k}{f_k} + \frac{D}{R_k(r,v,p_k,b_k)} \right) \right\},$$
   and $P_c^*$ is uniquely recovered as $P_c^* = E_{\mathrm{WPT}} / T^* \in [0, P_c^{\max}]$.

#### Proof
1. **Objective Equivalence:** $e_{\mathrm{UAV}} = P_c T \equiv E_{\mathrm{WPT}}$.
2. **Energy Harvested Equivalence:** In C2, the harvested energy term is $\lambda T P_c |h_k|^2$. By definition of $E_{\mathrm{WPT}} = P_c T$, this term is $\lambda E_{\mathrm{WPT}} |h_k|^2$. Neither $P_c$ nor $T$ appears individually anywhere in C2.
3. **Power Budget Equivalence:** $P_c \le P_c^{\max} \iff \frac{E_{\mathrm{WPT}}}{T} \le P_c^{\max} \iff E_{\mathrm{WPT}} \le P_c^{\max} T$, since $T > 0$.
4. **Feasibility of Recovery:** For any pair $(E_{\mathrm{WPT}}, T)$ satisfying $E_{\mathrm{WPT}} \ge 0$ and $T \ge E_{\mathrm{WPT}} / P_c^{\max}$, defining $P_c = E_{\mathrm{WPT}} / T$ yields $0 \le P_c \le P_c^{\max}$, satisfying C8.
5. **Impact on Problem Structure:** This transformation eliminates the bilinear product $P_c T$ from both the objective and constraint C2, making the energy causality constraint linear in the optimization variable $E_{\mathrm{WPT}}$. $\blacksquare$

---

### Theorem 3 (Analysis of CPU Computing Frequency $f_k$)

#### Statement
For given $(T, r, v, p_k, b_k)$, user $k$'s CPU frequency $f_k$ is subject to:
$$\begin{aligned}
\text{Latency (C1):} \quad & \frac{R C_k D_k}{f_k} \le T - t_k^u \iff f_k \ge \frac{R C_k D_k}{T - t_k^u} \triangleq f_k^{\mathrm{req}}, \\
\text{Energy (C2):} \quad & R \frac{\tau_k}{2} C_k D_k f_k^2 \le \lambda E_{\mathrm{WPT}} |h_k|^2 - p_k t_k^u, \\
\text{Hardware (C6):} \quad & f_k^{\min} \le f_k \le f_k^{\max}.
\end{aligned}$$
Then:
1. The local computation energy $e_k^l(f_k) = R \frac{\tau_k}{2} C_k D_k f_k^2$ is **strictly convex and strictly increasing** in $f_k > 0$.
2. To minimize energy consumption and maximize slack in the energy causality constraint C2, $f_k$ must be chosen as small as possible while meeting C1 and C6:
   $$f_k^*(T, t_k^u) = \max\left\{ f_k^{\min}, \; \frac{R C_k D_k}{T - t_k^u} \right\}.$$
3. A feasible frequency exists if and only if $f_k^*(T, t_k^u) \le f_k^{\max}$.
4. If $T$ is fixed, $f_k$ is **completely determined** in closed form. If $T$ is an optimization variable, $f_k$ can be retained as a bounded convex scalar or parameterized directly via $T$. $\blacksquare$

---

### Theorem 4 (Transmit Power $p_k$ vs Secrecy Rate)

#### Statement
In the base paper (without secrecy), constraint C3 yields $p_k^*(b_k) = \frac{N_0 b_k}{|h_k|^2} (2^{\frac{D}{t_k^u b_k}} - 1)$.
Under **exact robust secrecy**, user $k$ must simultaneously satisfy:
1. Uplink upload rate: $R_k \ge D / t_k^u$.
2. Exact robust secrecy:
   $$|h_k(r,v)|^2 \ge \Gamma_k(b_k) (|z_k(v)| + \Delta_{E,k})^2 + \frac{N_0 b_k}{p_k} (\Gamma_k(b_k) - 1), \quad \text{where } \Gamma_k(b_k) = 2^{R_{s,k}/b_k}.$$

#### Crucial Mathematical Consequence:
Rearranging C10 for $p_k$:
If $|h_k(r,v)|^2 > \Gamma_k(b_k) (|z_k(v)| + \Delta_{E,k})^2$, the robust secrecy constraint imposes a **strict lower bound** on transmit power:
$$p_k \ge \frac{N_0 b_k (\Gamma_k(b_k) - 1)}{|h_k(r,v)|^2 - \Gamma_k(b_k) (|z_k(v)| + \Delta_{E,k})^2} \triangleq p_k^{\mathrm{sec}}(r, v, b_k).$$
If $|h_k(r,v)|^2 \le \Gamma_k(b_k) (|z_k(v)| + \Delta_{E,k})^2$, no finite transmit power $p_k > 0$ can achieve the target secrecy rate $R_{s,k}$.

Simultaneously, from the upload volume constraint C3:
$$p_k \ge \frac{N_0 b_k}{|h_k(r,v)|^2} \left( 2^{\frac{D}{t_k^u b_k}} - 1 \right) \triangleq p_k^{\mathrm{comm}}(r, v, b_k, t_k^u).$$

Therefore, for any fixed $(r, v, b_k, t_k^u)$, the transmit power $p_k$ must satisfy:
$$p_k \ge \max\left\{ p_k^{\mathrm{sec}}(r, v, b_k), \; p_k^{\mathrm{comm}}(r, v, b_k, t_k^u) \right\}.$$

Since energy consumption $e_k^u = p_k t_k^u$ is strictly increasing in $p_k$, and no other constraint benefits from a larger $p_k$, at an optimum with fixed $(r, v, b_k, t_k^u)$:
$$p_k^*(r, v, b_k, t_k^u) = \max\left\{ p_k^{\mathrm{sec}}(r, v, b_k), \; p_k^{\mathrm{comm}}(r, v, b_k, t_k^u) \right\},$$
provided this does not exceed $p_{\max}$.

This is a fundamental closed-form reduction that connects communication throughput and physical-layer secrecy directly to energy consumption. $\blacksquare$
