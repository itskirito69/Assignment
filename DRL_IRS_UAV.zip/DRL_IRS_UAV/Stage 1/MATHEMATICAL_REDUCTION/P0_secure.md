# STAGE 1: PROBLEM P0 — EXACT SECURE FORMULATION
## Secure IRS-Assisted UAV Wireless-Powered Federated Learning

---

### 1. Robust Eavesdropper Model and Exact Worst-Case Derivation

We consider a ground eavesdropper (Eve) located at coordinate $r_E = (x_E, y_E, 0)$ seeking to overhear the uplink model updates transmitted by the $K$ wireless-powered FL users.

The eavesdropper channel for user $U_k$ comprises both the direct link $g_{UE,k} \in \mathbb{C}$ and the IRS-reflected link $g_{IE}^H \operatorname{diag}(v) h_{UI,k} \in \mathbb{C}$:
$$g_{e,k}(v) = g_{UE,k} + g_{IE}^H \operatorname{diag}(v) h_{UI,k},$$
where $v = [e^{j\theta_1}, \dots, e^{j\theta_N}]^T \in \mathbb{T}^N$ is the IRS reflection vector.

#### Imperfect Eavesdropper CSI Model
The CSI for the non-cooperative eavesdropper is subject to bounded deterministic uncertainty:
$$\begin{aligned}
g_{IE} &= \widehat{g}_{IE} + \Delta g_{IE}, \quad &&\|\Delta g_{IE}\|_2 \le \epsilon_{IE}, \\
g_{UE,k} &= \widehat{g}_{UE,k} + \Delta g_{UE,k}, \quad &&|\Delta g_{UE,k}| \le \epsilon_{UE,k},
\end{aligned}$$
where $\widehat{g}_{IE}$ and $\widehat{g}_{UE,k}$ are the estimated nominal channel components, and $\epsilon_{IE}, \epsilon_{UE,k} \ge 0$ denote the known uncertainty radii.

#### Exact Worst-Case Eavesdropper Channel Gain
Substituting the uncertainty model into $g_{e,k}(v)$:
$$g_{e,k}(v) = \underbrace{\widehat{g}_{UE,k} + \widehat{g}_{IE}^H \operatorname{diag}(v) h_{UI,k}}_{z_k(v)} + \Delta g_{UE,k} + \Delta g_{IE}^H \operatorname{diag}(v) h_{UI,k}.$$

By the triangle inequality and Cauchy–Schwarz inequality, the maximum possible channel magnitude over all admissible channel errors is:
$$\begin{aligned}
\max_{\substack{|\Delta g_{UE,k}| \le \epsilon_{UE,k} \\ \|\Delta g_{IE}\|_2 \le \epsilon_{IE}}} |g_{e,k}(v)| 
&\le |z_k(v)| + |\Delta g_{UE,k}| + \|\Delta g_{IE}\|_2 \|\operatorname{diag}(v) h_{UI,k}\|_2 \\
&= |z_k(v)| + \epsilon_{UE,k} + \epsilon_{IE} \|h_{UI,k}\|_2, \quad \text{since } |v_n| = 1 \implies \|\operatorname{diag}(v) h_{UI,k}\|_2 = \|h_{UI,k}\|_2.
\end{aligned}$$

Defining the aggregate deterministic uncertainty radius:
$$\Delta_{E,k} \triangleq \epsilon_{UE,k} + \epsilon_{IE} \|h_{UI,k}\|_2,$$
the upper bound is attained by selecting the phase of the errors to align with $z_k(v)$:
$$\max_{\text{admissible errors}} |g_{e,k}(v)| = |z_k(v)| + \Delta_{E,k}.$$

The exact worst-case eavesdropper rate for user $k$ over bandwidth $b_k$ is therefore:
$$R_{e,k}^{\mathrm{wc}} = b_k \log_2\left(1 + \frac{p_k (|z_k(v)| + \Delta_{E,k})^2}{N_0 b_k}\right).$$

---

### 2. Derivation of the Exact Deterministic Robust Secrecy Constraint

The physical-layer achievable secrecy rate for user $k$ is defined as:
$$R_{\mathrm{sec},k} \triangleq [R_k - R_{e,k}^{\mathrm{wc}}]^+ = \left[ b_k \log_2\left(1 + \frac{p_k |h_k(r,v)|^2}{N_0 b_k}\right) - b_k \log_2\left(1 + \frac{p_k (|z_k(v)| + \Delta_{E,k})^2}{N_0 b_k}\right) \right]^+.$$

To guarantee confidentiality of the transmitted model updates, the system requires:
$$R_{\mathrm{sec},k} \ge R_{s,k}, \quad \forall k \in \mathcal{K},$$
where $R_{s,k} > 0$ is the target secrecy rate (bits/sec).

Since $R_{s,k} > 0$, the constraint is equivalent to:
$$\frac{1 + \frac{p_k |h_k(r,v)|^2}{N_0 b_k}}{1 + \frac{p_k (|z_k(v)| + \Delta_{E,k})^2}{N_0 b_k}} \ge 2^{R_{s,k}/b_k} \triangleq \Gamma_k(b_k).$$

Rearranging algebraically:
$$1 + \frac{p_k |h_k(r,v)|^2}{N_0 b_k} \ge \Gamma_k(b_k) \left( 1 + \frac{p_k (|z_k(v)| + \Delta_{E,k})^2}{N_0 b_k} \right).$$

Subtracting 1 and multiplying both sides by $\frac{N_0 b_k}{p_k} > 0$:
$$\boxed{|h_k(r,v)|^2 \ge \Gamma_k(b_k) (|z_k(v)| + \Delta_{E,k})^2 + \frac{N_0 b_k}{p_k} (\Gamma_k(b_k) - 1)} \quad (\text{Constraint } C10).$$

This inequality is mathematically **exact**, closed-form, and deterministic. It requires NO conservative S-procedure or approximate rank-reduction relaxations.

---

### 3. Full Optimization Problem $\mathcal{P}_0$

$$\min_{P_c, T, r, v, \{p_k\}, \{b_k\}, \{f_k\}, \{t_k^u\}} P_c T$$
subject to:
$$\begin{aligned}
C1: \quad & \frac{R C_k D_k}{f_k} + t_k^u \le T, && \forall k \in \mathcal{K} \\
C2: \quad & R \frac{\tau_k}{2} C_k D_k f_k^2 + p_k t_k^u \le \lambda T P_c |h_k(r,v)|^2, && \forall k \in \mathcal{K} \\
C3: \quad & t_k^u b_k \log_2\left(1 + \frac{p_k |h_k(r,v)|^2}{N_0 b_k}\right) \ge D, && \forall k \in \mathcal{K} \\
C4: \quad & 0 \le p_k \le p_{\max}, && \forall k \in \mathcal{K} \\
C5: \quad & \sum_{k=1}^K b_k \le B, \quad b_k \ge 0, && \forall k \in \mathcal{K} \\
C6: \quad & f_k^{\min} \le f_k \le f_k^{\max}, && \forall k \in \mathcal{K} \\
C7: \quad & |v_n| = 1, && \forall n \in \mathcal{N} \\
C8: \quad & 0 \le P_c \le P_c^{\max} \\
C9: \quad & \|r\|_2^2 \le d^2 \\
C10: \quad & |h_k(r,v)|^2 \ge \Gamma_k(b_k) (|z_k(v)| + \Delta_{E,k})^2 + \frac{N_0 b_k}{p_k} (\Gamma_k(b_k) - 1), && \forall k \in \mathcal{K}
\end{aligned}$$

---

### 4. Complete Constraint Audit & Classification Table

| Constraint | Mathematical Expression | Physical Meaning | Provenance | Exact / Approx | Convexity Status |
|:---:|:---|:---|:---:|:---:|:---:|
| **Obj** | $\min P_c T$ | UAV total WPT transmission energy | Base Eq. (8) | Exact | Bi-affine (non-convex jointly in $P_c, T$) |
| **C1** | $\frac{R C_k D_k}{f_k} + t_k^u \le T$ | Total FL latency budget | Base Eq. (16) | Exact | Convex in $(1/f_k, t_k^u, T)$ |
| **C2** | $R \frac{\tau_k}{2} C_k D_k f_k^2 + p_k t_k^u \le \lambda T P_c \|h_k\|^2$ | User RF energy harvesting causality | Base Eq. (17) | Exact | Non-convex (bilinear $P_c T$, non-convex $\|h_k\|^2$) |
| **C3** | $t_k^u b_k \log_2(1 + \frac{p_k \|h_k\|^2}{N_0 b_k}) \ge D$ | Model upload data volume | Base Eq. (14) | Exact | Non-convex (coupled in $t_k^u, b_k, p_k, r, v$) |
| **C4** | $0 \le p_k \le p_{\max}$ | User transmit power limits | Base Eq. (18) | Exact | Linear / Box (Convex) |
| **C5** | $\sum_k b_k \le B, b_k \ge 0$ | Total system bandwidth budget | Base Eq. (18) | Exact | Linear Simplex (Convex) |
| **C6** | $f_k^{\min} \le f_k \le f_k^{\max}$ | User CPU frequency limits | Base Eq. (18) | Exact | Box interval (Convex) |
| **C7** | $\|v_n\| = 1, \forall n$ | IRS passive unit-modulus phases | Base Eq. (18) | Exact | Non-convex (Complex Torus $\mathbb{T}^N$) |
| **C8** | $0 \le P_c \le P_c^{\max}$ | UAV WPT transmitter power budget | Base Eq. (18) | Exact | Box interval (Convex) |
| **C9** | $\|r\|_2 \le d$ | UAV flight operational radius | Base Eq. (18) | Exact | Euclidean 2-norm ball (Convex) |
| **C10** | $\|h_k\|^2 \ge \Gamma_k (|z_k| + \Delta_{E,k})^2 + \frac{N_0 b_k}{p_k}(\Gamma_k - 1)$ | **Exact Robust Secrecy Requirement** | **NEW** | **Exact** | **Non-convex** (coupled in $r, v, b_k, p_k$) |
