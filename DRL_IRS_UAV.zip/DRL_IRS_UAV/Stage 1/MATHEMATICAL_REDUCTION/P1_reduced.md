# STAGE 1: MINIMAL REDUCED OPTIMIZATION PROBLEM P1
## Secure IRS-Assisted UAV Wireless-Powered Federated Learning

---

### Formulation of Problem $\mathcal{P}_1$

Applying the exact eliminations of $t_k^u = \frac{D}{R_k}$ (Theorem 1) and $P_c = \frac{E_{\mathrm{WPT}}}{T}$ (Theorem 2), the complete optimization problem is reduced to:

$$\min_{E_{\mathrm{WPT}}, T, r, v, \{p_k\}, \{b_k\}, \{f_k\}} E_{\mathrm{WPT}}$$

subject to:

$$\begin{aligned}
\widetilde{C1} \text{ (Latency):} \quad & \frac{R C_k D_k}{f_k} + \frac{D}{b_k \log_2\left(1 + \frac{p_k |h_k(r,v)|^2}{N_0 b_k}\right)} \le T, && \forall k \in \mathcal{K} \\
\widetilde{C2} \text{ (Energy):} \quad & R \frac{\tau_k}{2} C_k D_k f_k^2 + \frac{p_k D}{b_k \log_2\left(1 + \frac{p_k |h_k(r,v)|^2}{N_0 b_k}\right)} \le \lambda E_{\mathrm{WPT}} |h_k(r,v)|^2, && \forall k \in \mathcal{K} \\
\widetilde{C3} \text{ (WPT Budget):} \quad & E_{\mathrm{WPT}} \le P_c^{\max} T \\
C4 \text{ (User Power):} \quad & 0 \le p_k \le p_{\max}, && \forall k \in \mathcal{K} \\
C5 \text{ (Bandwidth):} \quad & \sum_{k=1}^K b_k \le B, \quad b_k \ge 0, && \forall k \in \mathcal{K} \\
C6 \text{ (CPU Frequency):} \quad & f_k^{\min} \le f_k \le f_k^{\max}, && \forall k \in \mathcal{K} \\
C7 \text{ (IRS Manifold):} \quad & |v_n| = 1, && \forall n \in \mathcal{N} \\
C8 \text{ (UAV Hover Area):} \quad & \|r\|_2^2 \le d^2 \\
C9 \text{ (Robust Secrecy):} \quad & |h_k(r,v)|^2 \ge \Gamma_k(b_k) (|z_k(v)| + \Delta_{E,k})^2 + \frac{N_0 b_k}{p_k} (\Gamma_k(b_k) - 1), && \forall k \in \mathcal{K}
\end{aligned}$$

where:
- $\Gamma_k(b_k) \triangleq 2^{R_{s,k}/b_k}$.
- $z_k(v) \triangleq \widehat{g}_{UE,k} + \widehat{g}_{IE}^H \operatorname{diag}(v) h_{UI,k}$.
- $\Delta_{E,k} \triangleq \epsilon_{UE,k} + \epsilon_{IE} \|h_{UI,k}\|_2$.
- $h_k(r, v) \triangleq h_{IA}(r) \operatorname{diag}(h_{UI,k}) v + h_{UA,k}(r)$.

---

### Equivalence Guarantee

1. **Exact Feasible Set Preservation**: For any feasible point of $\mathcal{P}_0$, the point in $\mathcal{P}_1$ obtained by setting $E_{\mathrm{WPT}} = P_c T$ is feasible with identical objective value.
2. **Exact Solution Recovery**: For any solution $(E_{\mathrm{WPT}}^*, T^*, r^*, v^*, p^*, b^*, f^*)$ of $\mathcal{P}_1$, defining $P_c^* = E_{\mathrm{WPT}}^*/T^*$ and $t_k^{u*} = D / R_k(r^*, v^*, p_k^*, b_k^*)$ yields an exact feasible solution to $\mathcal{P}_0$ with objective value $P_c^* T^* = E_{\mathrm{WPT}}^*$.
3. **No Relaxation**: No approximation, smoothing, or slack relaxation has been applied. $\mathcal{P}_1$ is mathematically identical to $\mathcal{P}_0$.
