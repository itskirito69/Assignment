# STAGE 1: DEDICATED AUDIT — WPT ENERGY REDUCTION
## Analysis of the Transformation $(P_c, T) \longrightarrow E_{\mathrm{WPT}} = P_c T$

---

### 1. Research Question

Can the two optimization variables—UAV WPT transmit power $P_c$ and mission duration $T$—be mathematically replaced by the single scalar variable:
$$E_{\mathrm{WPT}} \triangleq P_c T,$$
without altering the feasible set, the objective value, or the physical interpretability of the optimal solution?

---

### 2. Physical System Interaction Audit

Let us trace every occurrence of $P_c$ and $T$ in the full formulation $\mathcal{P}_0$:

| Location | Mathematical Expression | Dependencies on $P_c$ and $T$ | Can it be written in terms of $E_{\mathrm{WPT}}$? |
|:---|:---|:---|:---:|
| **Objective** | $\min P_c T$ | Appears strictly as product $P_c T$ | **YES:** $E_{\mathrm{WPT}}$ |
| **C1 (Latency)** | $t_k^l + t_k^u \le T$ | Depends on $T$ linearly; independent of $P_c$ | **Depends on $T$** |
| **C2 (Harvesting)** | $e_k^l + e_k^u \le \lambda T P_c |h_k|^2$ | Appears strictly as product $P_c T$ | **YES:** $\lambda E_{\mathrm{WPT}} |h_k|^2$ |
| **C8 (Power Limit)** | $0 \le P_c \le P_c^{\max}$ | Depends on $P_c$ linearly; independent of $T$ | **Coupled:** $\frac{E_{\mathrm{WPT}}}{T} \le P_c^{\max}$ |
| **C3–C7, C9–C10** | (Channels, power, bandwidth, secrecy) | Completely independent of $P_c$ and $T$ | **Independent** |

---

### 3. Detailed Feasibility and Recovery Analysis

#### 3.1 Can $P_c$ be Completely Eliminated?
**YES.**
Notice that $P_c$ appears in the problem **only** in:
1. The product $P_c T$ (in the objective and in C2).
2. The box constraint $0 \le P_c \le P_c^{\max}$ (in C8).

If we define $E_{\mathrm{WPT}} = P_c T$, then:
$$P_c = \frac{E_{\mathrm{WPT}}}{T}.$$
Substituting this into C8 yields:
$$0 \le \frac{E_{\mathrm{WPT}}}{T} \le P_c^{\max} \iff 0 \le E_{\mathrm{WPT}} \le P_c^{\max} T.$$
Therefore, $P_c$ can be removed entirely from the optimization variable list, replaced by $E_{\mathrm{WPT}} \ge 0$ along with the linear coupling constraint:
$$E_{\mathrm{WPT}} \le P_c^{\max} T.$$

Once $(E_{\mathrm{WPT}}^*, T^*)$ are computed, $P_c^*$ is recovered unambiguously as:
$$P_c^* = \frac{E_{\mathrm{WPT}}^*}{T^*},$$
which is guaranteed to satisfy $0 \le P_c^* \le P_c^{\max}$.

#### 3.2 Can $T$ Also Be Eliminated?
Let us investigate whether $T$ itself can be eliminated by setting it to its lower bound.

In $\mathcal{P}_0$, $T$ is subject to two sets of lower bounds:
1. **From FL task latency (C1):**
   $$T \ge \max_{k \in \mathcal{K}} \left\{ t_k^l + t_k^u \right\} = \max_{k \in \mathcal{K}} \left\{ \frac{R C_k D_k}{f_k} + \frac{D}{R_k} \right\} \triangleq T_{\mathrm{latency}}(r, v, p, b, f).$$
2. **From the UAV power budget (C8):**
   $$T \ge \frac{E_{\mathrm{WPT}}}{P_c^{\max}} \triangleq T_{\mathrm{power}}(E_{\mathrm{WPT}}).$$

Therefore, the exact admissible range for $T$ is:
$$T \ge \max\left\{ T_{\mathrm{latency}}(r, v, p, b, f), \; \frac{E_{\mathrm{WPT}}}{P_c^{\max}} \right\}.$$

**Crucial Observation:**
Does the objective $\min E_{\mathrm{WPT}}$ depend directly on $T$?
**NO.** The objective is solely $E_{\mathrm{WPT}}$.
Furthermore, in constraint C2, the harvested energy term is $\lambda E_{\mathrm{WPT}} |h_k|^2$, which is also **completely independent of $T$**.

Does increasing $T$ harm any other constraint?
- In C1: Increasing $T$ creates more latency slack.
- In C8: Increasing $T$ creates more power budget slack ($P_c = E_{\mathrm{WPT}}/T \le P_c^{\max}$).
- Nowhere does $T$ appear in an upper bound constraint ($T \le T_{\max}$ does NOT exist in the base paper formulation).

Therefore, for any fixed $(E_{\mathrm{WPT}}, r, v, p, b, f)$, the optimal choice of $T$ is:
$$T^* = \max\left\{ T_{\mathrm{latency}}(r, v, p, b, f), \; \frac{E_{\mathrm{WPT}}}{P_c^{\max}} \right\}.$$

#### 3.3 What If a Finite Mission Budget $T \le T_{\max}$ Is Added Later?
If an explicit mission deadline $T \le T_{\max}$ is enforced, feasibility requires:
$$\max\left\{ T_{\mathrm{latency}}, \; \frac{E_{\mathrm{WPT}}}{P_c^{\max}} \right\} \le T_{\max},$$
which decomposes into two separate, independent linear constraints:
$$T_{\mathrm{latency}}(r, v, p, b, f) \le T_{\max} \quad \text{and} \quad E_{\mathrm{WPT}} \le P_c^{\max} T_{\max}.$$

In either case, the variable $P_c$ is **completely redundant**.

---

### 4. Summary of Audit Outcome

1. **$P_c$ is ELIMINATED EXACTLY**: Replaced by $E_{\mathrm{WPT}} = P_c T$.
2. **$E_{\mathrm{WPT}}$ is RETAINED**: As the primary scalar objective variable.
3. **$T$ is DERIVED / EPIGRAPH**: In a decoupled BCD architecture, $T$ can either be treated as an explicit epigraph variable or derived in closed form via $T^* = \max(T_{\mathrm{latency}}, E_{\mathrm{WPT}}/P_c^{\max})$.
4. **Bilinear Decoupling**: The product $P_c T$ in both the objective and C2 is eliminated, converting a non-convex bi-affine harvesting term into a linear term in $E_{\mathrm{WPT}}$.
