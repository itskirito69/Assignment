# STAGE 1: ROBUST SECRECY BLOCK MAPPING & CLASSIFICATION
## Tracking the Exact Robust Secrecy Constraint Across BCD Blocks

---

### 1. The Exact Robust Secrecy Constraint

The exact deterministic robust secrecy constraint is:
$$|h_k(r,v)|^2 \ge \Gamma_k(b_k) (|z_k(v)| + \Delta_{E,k})^2 + \frac{N_0 b_k}{p_k} (\Gamma_k(b_k) - 1), \quad \forall k \in \mathcal{K}, \tag{C9}$$
where:
- $\Gamma_k(b_k) = 2^{R_{s,k}/b_k}$.
- $|h_k(r,v)|^2 = \left| h_{IA}(r) \operatorname{diag}(h_{UI,k}) v + h_{UA,k}(r) \right|^2$.
- $z_k(v) = \widehat{g}_{UE,k} + \widehat{g}_{IE}^H \operatorname{diag}(v) h_{UI,k}$.
- $\Delta_{E,k} = \epsilon_{UE,k} + \epsilon_{IE} \|h_{UI,k}\|_2$ (constant).

---

### 2. Block-by-Block Secrecy Mapping

We investigate how (C9) behaves when optimizing each subset of variables while holding the others fixed.

---

### Block 1: UAV Position $r = (x, y) \in \mathbb{R}^2$

#### 1. Which terms of (C9) depend on $r$?
- Left-Hand Side (LHS): $|h_k(r,v)|^2$ depends on $r$ through the spatial distances $d_{UA,k}(r) = \sqrt{\|r_k - r\|^2 + H_A^2}$ and $d_{IA}(r) = \sqrt{\|r\|^2 + (H_A - H_I)^2}$.
- Right-Hand Side (RHS): $\Gamma_k(b_k) (|z_k(v)| + \Delta_{E,k})^2 + \frac{N_0 b_k}{p_k} (\Gamma_k(b_k) - 1)$ is **completely independent of $r$** (since Eve is on the ground, IRS is static, and ground-to-IRS links do not depend on the UAV position).

#### 2. Mathematical Structure in $r$:
Denoting the constant RHS as $\zeta_k^{\mathrm{sec}}(v, p_k, b_k) > 0$, the secrecy constraint in Block $r$ simplifies to:
$$|h_k(r, v)|^2 \ge \zeta_k^{\mathrm{sec}}, \quad \forall k \in \mathcal{K}.$$

#### 3. Classification:
- **Classification:** **Difference-of-Convex (DC) / Non-convex smooth**.
- **Source of Non-Convexity:** The composite channel gain $|h_k(r,v)|^2$ is non-convex in $r$ because the path-loss functions $d_{UA,k}(r)^{-\alpha_1/2}$ and $d_{IA}(r)^{-1}$ are convex decreasing in distance, but their sum squared is non-concave in $r$.
- **Surrogate Design (SCA):** 
  Following standard UAV communication optimization (Zeng, Zhang, Lim, IEEE WCM 2016; Li et al. 2024), we introduce slack variables for the distances:
  $$d_{UA,k}(r) \le \mu_k, \qquad d_{IA}(r) \le \kappa.$$
  Since $d_{UA,k}(r)$ and $d_{IA}(r)$ are convex in $r$, the lower bound $|h_k(r,v)|^2 \ge \left( \frac{\chi_k}{\kappa} + \frac{\omega_k}{\mu_k^{\alpha_1/2}} \right)^2$ is convex with respect to $(\kappa, \mu_k)$. A first-order Taylor expansion (minorization) around the current iterate $(\kappa^{(i)}, \mu_k^{(i)})$ provides a strict global underestimator:
  $$|h_k(r,v)|^2 \ge \mathcal{L}_k(r; r^{(i)}) \ge \zeta_k^{\mathrm{sec}}.$$
- **Tangency & Feasibility:** The surrogate touches the original function at $r^{(i)}$ with matching first derivatives. Because it is a global minorizer, any point satisfying the surrogate constraint strictly satisfies the true robust secrecy constraint (**conservative inner approximation**).

---

### Block 2: IRS Reflection Vector $v \in \mathbb{T}^N \subset \mathbb{C}^N$ ($|v_n| = 1$)

#### 1. Which terms of (C9) depend on $v$?
- LHS: Legitimate channel gain $|h_k(r,v)|^2 = v^H \mathbf{\Phi}_k v + 2 \operatorname{Re}\{v^H \mathbf{u}_k\} + c_k$.
- RHS: Eavesdropper channel gain $|z_k(v)|^2 = v^H \mathbf{\Psi}_k v + 2 \operatorname{Re}\{v^H \mathbf{w}_k\} + d_k$.
- Power/Bandwidth term: $\frac{N_0 b_k}{p_k} (\Gamma_k(b_k) - 1)$ is constant.

#### 2. Mathematical Structure in $v$:
Rearranging (C9) with respect to $v$:
$$|h_k(r,v)|^2 - \Gamma_k(b_k) \left( |z_k(v)| + \Delta_{E,k} \right)^2 \ge \frac{N_0 b_k}{p_k} (\Gamma_k(b_k) - 1).$$

Notice that:
- $|h_k(r,v)|^2$ is a convex quadratic function of $v$.
- $|z_k(v)|$ is convex in $v$ (norm of an affine function).
- Hence, $(|z_k(v)| + \Delta_{E,k})^2$ is a **convex function of $v$** (composition of convex non-negative function with quadratic).
- Therefore, the difference:
  $$\Delta \mathcal{R}_k(v) \triangleq |h_k(r,v)|^2 - \Gamma_k(b_k) (|z_k(v)| + \Delta_{E,k})^2$$
  is a **Difference of Convex (DC) function** in $v$, constrained to the complex torus $\mathbb{T}^N$!

#### 3. Classification:
- **Classification:** **Non-convex unit-modulus DC (Difference-of-Convex)**.
- **Surrogate Design (SCA / MM):**
  To handle the DC structure:
  1. The legitimate channel $|h_k(r,v)|^2$ is convex quadratic, so it can be linearized around $v^{(i)}$ via its first-order Taylor expansion to obtain a concave minorizer:
     $$|h_k(r,v)|^2 \ge 2 \operatorname{Re}\{ v^H \mathbf{\Phi}_k v^{(i)} \} - (v^{(i)})^H \mathbf{\Phi}_k v^{(i)} + 2 \operatorname{Re}\{ v^H \mathbf{u}_k \} + c_k.$$
  2. The eavesdropper upper bound $(|z_k(v)| + \Delta_{E,k})^2$ can be majorized by a quadratic upper bound using the Lipschitz gradient property:
     $$\nabla f(v) \text{ is } L\text{-Lipschitz} \implies f(v) \le f(v^{(i)}) + \operatorname{Re}\{\nabla f(v^{(i)})^H (v - v^{(i)})\} + \frac{L}{2} \|v - v^{(i)}\|^2.$$
     On the unit torus $|v_n| = 1$, $\|v - v^{(i)}\|^2 = 2N - 2\operatorname{Re}\{v^H v^{(i)}\}$, which is **linear in $v$**!
  3. The unit-modulus constraint $|v_n| = 1$ can be addressed either via:
     - **Option A (SDR / S-Procedure):** Rank-one relaxation $V = v v^H, V \succeq 0, V_{n,n} = 1$.
     - **Option B (Manifold / Projected Gradient MM):** Direct closed-form phase projection $v_n = e^{j \arg(w_n)}$ solving a linear subproblem at each MM iteration.
- **Guarantee:** MM surrogate strictly minorizes the secrecy margin, guaranteeing that every surrogate-improving step improves or preserves true secrecy feasibility.

---

### Block 3: Resource Allocation $(p, b, f, E_{\mathrm{WPT}}, T)$

#### 1. Which terms of (C9) depend on this block?
- Fixed: $|h_k(r,v)|^2 = \gamma_{h,k}$ and $(|z_k(v)| + \Delta_{E,k})^2 = \gamma_{e,k}$.
- Active variables: $b_k$ and $p_k$. (Independent of $f_k, E_{\mathrm{WPT}}, T$).

#### 2. Mathematical Structure in $(p_k, b_k)$:
The constraint is:
$$\gamma_{h,k} \ge \Gamma_k(b_k) \gamma_{e,k} + \frac{N_0 b_k}{p_k} (\Gamma_k(b_k) - 1), \quad \text{where } \Gamma_k(b_k) = 2^{R_{s,k}/b_k}.$$

Let us examine the function:
$$\psi(p_k, b_k) \triangleq \Gamma_k(b_k) \gamma_{e,k} + \frac{N_0 b_k}{p_k} (\Gamma_k(b_k) - 1).$$

- As $b_k \to 0^+$, $\Gamma_k(b_k) = 2^{R_{s,k}/b_k} \to \infty$, so $\psi(p_k, b_k) \to \infty$.
- As $b_k \to \infty$, $\Gamma_k(b_k) \to 1$ and $b_k (\Gamma_k - 1) = b_k (2^{R_s/b_k} - 1) \to R_s \ln 2$.
- In $p_k$: $\psi(p_k, b_k)$ is **strictly convex and strictly decreasing** in $p_k > 0$ for any fixed $b_k$.
- Therefore, for any feasible $b_k$ such that $\gamma_{h,k} > \Gamma_k(b_k) \gamma_{e,k}$, the constraint is **convex in $1/p_k$**!
  $$\frac{1}{p_k} \le \frac{\gamma_{h,k} - \Gamma_k(b_k) \gamma_{e,k}}{N_0 b_k (\Gamma_k(b_k) - 1)}.$$

#### 3. Classification:
- **Classification:** **Convex with respect to $1/p_k$ / Monotonic threshold**.
- **Closed-Form Representation:** As proven in Theorem 4, the exact minimum power required to sustain robust secrecy is:
  $$p_k \ge p_k^{\mathrm{sec}}(b_k) \triangleq \frac{N_0 b_k (2^{R_{s,k}/b_k} - 1)}{\gamma_{h,k} - 2^{R_{s,k}/b_k} \gamma_{e,k}}.$$
  This function is non-negative and convex over the feasible domain $b_k > R_{s,k} / \log_2(\gamma_{h,k} / \gamma_{e,k})$.

---

### 3. Summary of Secrecy Mapping

| Block | Variables | Secrecy Expression | Mathematical Classification | Solution Method |
|:---:|:---:|:---|:---:|:---|
| **Block 1** | $r \in \mathbb{R}^2$ | $\|h_k(r,v)\|^2 \ge \zeta_k^{\mathrm{sec}}$ | Difference of Convex (DC) in spatial distance | Minorizing SCA (Taylor expansion on path losses) |
| **Block 2** | $v \in \mathbb{T}^N$ | $v^H \mathbf{\Phi}_k v - \Gamma_k (\|z_k(v)\| + \Delta_{E,k})^2 \ge \text{const}$ | Unit-modulus DC quadratic | Minorization-Maximization (MM) / Phase Projection |
| **Block 3** | $(p, b)$ | $p_k \ge p_k^{\mathrm{sec}}(b_k)$ | Convex in $1/p_k$; closed-form threshold in $p_k$ | Closed-form substitution / Convex programming |
