# STAGE 2A-1: MATHEMATICAL FORENSIC AUDIT OF THE BASE-PAPER $T$-CONSTRAINT
## Exhaustive Forensic Verification of Mission Duration $T$ in Li et al. (2024) and Freeze_V2

---

### A. Executive Verdict

A comprehensive forensic audit of the original base paper (*Physical Communication*, 2024, Article 102504) and the secondary *Freeze_V2* codebase confirms that **no finite upper bound or deadline constraint on task duration $T$ ($T \le T_{\max}$) exists anywhere in the source material**. In the base paper, $T$ is formulated strictly as an unbounded epigraph variable constrained from below by the users' computation-plus-communication latency ($\frac{R C_k D_k}{f_k} + t_k^u \le T$, C1) and the UAV maximum transmit power ($E \le P_c^{\max} T$, C8). Because the objective is total radiated energy $E_{\mathrm{WPT}} = P_c T$ and harvested energy depends solely on $E_{\mathrm{WPT}}$, $T$ can be **exactly eliminated from the optimization problem via feasible-set projection**. The resulting projected model is mathematically well-posed, has a strictly positive physical energy floor, and admits exact, unique recovery of the minimal-latency operational point $T^* = \max\left\{ T_{\mathrm{lat}}, \frac{E_{\mathrm{WPT}}}{P_c^{\max}} \right\}$ with $P_c^* = E_{\mathrm{WPT}} / T^* \in [0, P_c^{\max}]$.

---

### B. Original Paper Evidence

All citations and equations below refer directly to the primary authority:  
**Ruijie Li, Guoping Zhang, Yun Chen, "IRS-assisted UAV wireless powered communication network for sustainable federated learning", *Physical Communication*, vol. 67, 102504, 2024.**

1. **System Model Definition (Section 2.1, Eq. 8–9, Page 3):**
   - *"Within the total mission time $T$ of UAV, the energy transmitted by UAV is: $e_{\mathrm{UAV}} = P_c T$ (8)."*
   - *"the energy received by $U_k$ from the UAV within the total mission time $T$ is: $e_k = \lambda T P_c |h_k|^2$ (9)."*
   - *Audit finding:* $T$ is defined as the total mission duration during which WPT occurs; $P_c$ is average transmit power. Both the radiated energy (Eq. 8) and harvested energy (Eq. 9) depend exclusively on the product $P_c T$.
2. **Latency Model (Section 2.3, Eq. 16, Page 3):**
   - *"the delay and energy consumption of the user needs to meet the following relationships: $t_k^l + t_k^u = \frac{R C_k D_k}{f_k} + t_k^u \le T$ (16)."*
   - *Audit finding:* $T$ acts as a common completion deadline for all $K$ parallel users.
3. **Problem Formulation (Section 3, Eq. 18, Page 4):**
   - The optimization problem is stated as:
     $$\min_{P_c, T, \Theta, r, p_k, b_k, f_k} e_{\mathrm{UAV}}$$
     $$\text{s.t.} \quad C1: \frac{R C_k D_k}{f_k} + t_k^u \le T, \quad C2: e_k^l + p_k t_k^u \le e_k, \quad C8: 0 \le P_c \le P_c^{\max}, \quad C9: \|r\|_2^2 \le d^2.$$
   - *Audit finding:* Constraints C1–C9 contain **no upper bound on $T$**. The domain of $T$ is implicitly $[0, \infty)$.
4. **Subproblem 2 Formulation (Section 4.2, Eq. 22–23, Page 4):**
   - *"Let $E = P_c T$, then the problem (22) is transformed as: $\min_{E,T} E$ s.t. $\frac{R C_k D_k}{f_k} + t_k^u \le T, \forall k \in \mathcal{K}; R \frac{\tau}{2} C_k D_k f_k^2 + p_k t_k^u \le \lambda E |h_k|^2, \forall k \in \mathcal{K}; 0 \le E \le P_c^{\max} T$ (23)."*
   - *Audit finding:* In Eq. (23), the objective is $\min E$. $T$ does not enter the objective, and $T$ has no upper bound constraint.
5. **Simulation Parameter Table (Table 1, Page 5) and Section 5:**
   - Table 1 lists: $B = 20\text{ MHz}, P_c^{\max} = 42\text{ dBm}, H_I = 20\text{ m}, C_k = 30\text{ cycles/bit}, f_k^{\max} = 2.0\text{ GHz}, f_k^{\min} = 0.1\text{ GHz}, \beta_0 = -30\text{ dB}, D_k = 400, \tau = 2 \times 10^{-28}, \lambda = 0.8, N_0 = -174\text{ dBm/Hz}$.
   - *Audit finding:* **No parameter for $T$, $T_{\max}$, or maximum latency is present in Table 1 or Section 5.**

---

### C. Complete $T$-Occurrence Audit

Every occurrence of time-related symbols in the base paper was systematically extracted and audited:

| Location in Paper | Exact Expression / Snippet | Context / Physical Meaning | Mathematical Role | Upper Bound / Constraint? |
|:---|:---|:---|:---|:---:|
| **Abstract (p. 1)** | *"total task time"* | Summary of optimized variables | Variable mention | None |
| **Section 1 (p. 2)** | *"total task time"* | Introduction of system parameters | Variable mention | None |
| **Section 2.1 (p. 3)** | *"total mission time $T$"* | Time window of UAV wireless power transfer | Variable definition | Lower bound ($T > 0$) |
| **Equation (8)** | $e_{\mathrm{UAV}} = P_c T$ | Total UAV radiated RF energy | Objective function | None |
| **Equation (9)** | $e_k = \lambda T P_c \|h_k\|^2$ | Harvested RF energy by user $k$ | Energy scaling | None |
| **Equation (10)** | $t_k^l = R C_k D_k / f_k$ | Local computing delay of user $k$ | Component delay | Lower bound on $T$ |
| **Equation (14)** | $t_k^u R_k \ge D$ | Uplink transmission delay of user $k$ | Component delay | Lower bound on $T$ |
| **Equation (16) / C1** | $t_k^l + t_k^u \le T, \forall k$ | Parallel user task completion delay | Inequality constraint | **Lower bound on $T$** ($T \ge t_k^l + t_k^u$) |
| **Equation (17) / C2** | $e_k^l + e_k^u \le \lambda T P_c \|h_k\|^2$ | User energy causality | Inequality constraint | **Lower bound on $T$** (for fixed $P_c$) |
| **Equation (18)** | $\min_{P_c, T, \Theta, r, p_k, b_k, f_k} e_{\mathrm{UAV}}$ | Master problem formulation | Primal optimization variable | **Unbounded above** ($T \in [T_{\min}, \infty)$) |
| **Section 4.1 (p. 3)** | *"fix the variables $(P_c, T), \dots$"* | Subproblem 1 setup | Fixed parameter in SP1 | None |
| **Section 4.2 (p. 4)** | $\min_{P_c, T} P_c T \text{ s.t. } C1, C2, C8$ | Subproblem 2 master statement | Optimization variable pair | Lower bound on $T$ |
| **Equation (23)** | $\min_{E,T} E \text{ s.t. } C1, C2, E \le P_c^{\max} T$ | Subproblem 2 reformulated LP | Optimization variable | **Lower bound on $T$** ($T \ge E/P_c^{\max}$) |
| **Equation (25)** | $f_k^{\min} = R C_k D_k / (T - t_k^u)$ | Optimal CPU frequency derivation | Denominator parameter | Requires $T > t_k^u$ |
| **Section 4.4 (p. 4)** | *"Using the optimized $\Theta, (P_c, T), \dots$"* | Subproblem 4 setup | Fixed parameter in SP4 | None |
| **Table 1 (p. 5)** | (All parameter entries) | System simulation settings | Table entries | **NO $T_{\max}$ entry** |
| **Section 5 (p. 5–7)** | *"total task time $T$"* | Performance discussion | Narrative description | None |
| **Section 6 (p. 7)** | *"total task time"* | Conclusion | Summary | None |

**Formal Conclusion:**
> **“No finite upper bound on $T$ was found in the original source material.”**

---

### D. C1–C9 $T$-Dependence Audit

We evaluate whether and how each constraint of the original problem (18) restricts $T$:

| Constraint | Mathematical Form in Eq. (18) | Contains $T$? | Direction of Constraint on $T$ | Physical & Mathematical Interpretation |
|:---:|:---|:---:|:---:|:---|
| **C1** | $\frac{R C_k D_k}{f_k} + t_k^u \le T, \quad \forall k \in \mathcal{K}$ | **YES** | **Lower Bound** ($T \ge t_k^l + t_k^u$) | $T$ must be at least as large as the total latency of the slowest user. Increasing $T$ strictly loosens C1. |
| **C2** | $e_k^l + p_k t_k^u \le \lambda T P_c \|h_k\|^2, \quad \forall k \in \mathcal{K}$ | **YES** (via $P_c T$) | **Lower Bound** ($T P_c \ge \frac{e_k}{\lambda \|h_k\|^2}$) | Depends on $(P_c, T)$ strictly through product $E = P_c T$. For fixed $P_c$, forces $T \ge \frac{e_k}{\lambda P_c \|h_k\|^2}$. |
| **C3** | $t_k^u b_k \log_2(1 + \frac{p_k \|h_k\|^2}{N_0 b_k}) \ge D, \quad \forall k \in \mathcal{K}$ | **NO** | None | Directly bounds $t_k^u \ge D/R_k$. Independent of $T$. |
| **C4** | $0 \le p_k \le p_{\max}, \quad \forall k \in \mathcal{K}$ | **NO** | None | User transmit power limits. Independent of $T$. |
| **C5** | $\sum_{k=1}^K b_k \le B, \quad b_k \ge 0, \quad \forall k \in \mathcal{K}$ | **NO** | None | Bandwidth conservation. Independent of $T$. |
| **C6** | $f_k^{\min} \le f_k \le f_k^{\max}, \quad \forall k \in \mathcal{K}$ | **NO** | None | User CPU frequency limits. Independent of $T$. |
| **C7** | $0 \le \theta_n \le 2\pi, \quad \forall n \in \mathcal{N}$ | **NO** | None | IRS phase domain. Independent of $T$. |
| **C8** | $0 \le P_c \le P_c^{\max}$ | **YES** (via $P_c = E/T$) | **Lower Bound** ($T \ge E / P_c^{\max}$) | In variables $(E, T)$, $P_c \le P_c^{\max} \iff T \ge E/P_c^{\max}$. Increasing $T$ strictly loosens C8. |
| **C9** | $\|r\|_2^2 \le d^2$ | **NO** | None | UAV horizontal coverage radius. Independent of $T$. |

**Key Finding:** Every single constraint in the base paper that involves $T$ imposes a **lower bound** ($T \ge \cdot$). Not a single constraint imposes an upper bound.

---

### E. Algorithm 1 Audit

In Section 4 of Li et al. (2024), the alternating optimization algorithm is structured as follows:
1. **Subproblem 1 ($\Theta$):** Solved for fixed $(P_c, T, p, b, f, r)$. Phase shifts $\theta_n$ are updated via direct link alignment.
2. **Subproblem 2 ($(P_c, T)$):** Solved for fixed $(\Theta, p, b, f, r)$. The paper reformulates $(P_c, T)$ via $E = P_c T$ into Eq. (23):
   $$\min_{E, T} E \quad \text{s.t.} \quad T \ge \max_{k \in \mathcal{K}} \left(\frac{R C_k D_k}{f_k} + t_k^u\right), \quad E \ge \max_{k \in \mathcal{K}} \frac{e_k^l + p_k t_k^u}{\lambda |h_k|^2}, \quad E \le P_c^{\max} T.$$
   - **Is $T$ explicitly optimized?** Yes, as a decision variable in CVX.
   - **Does (23) contain a hidden upper bound?** No.
   - **What does CVX do?** Because $E$ is minimized and $T$ does not enter the objective, CVX returns $E^* = \max_k \frac{e_k^l + p_k t_k^u}{\lambda |h_k|^2}$ and any feasible $T^* \ge \max(T_{\mathrm{lat}}, E^*/P_c^{\max})$.
3. **Subproblem 3 ($(p_k, b_k, f_k)$):** 
   - Uses the updated $T$ to set $f_k^* = \min\{\max\{f_k^{\min}, \frac{R C_k D_k}{T - t_k^u}\}, f_k^{\max}\}$ (Eq. 25).
   - Updates $p_k^*$ (Eq. 26) and $b_k^*$ (Eq. 29).
4. **Subproblem 4 ($r$):** Updates UAV position $r$ via SCA slacks.
5. **Initialization:** The paper does not specify an initial numerical value for $T$; in practice, algorithms initialize $T$ from initial resources $T^{(0)} = \max_k(t_k^{l(0)} + t_k^{u(0)})$.
   > **Audit Note:** An initial state value $T^{(0)}$ is merely a starting iterate; it is **never** a mathematical constraint bound.

---

### F. Freeze_V2 Cross-Check (Paper vs. Code)

We cross-checked the authoritative codebase `final codebase/Freeze_V2`:

| Component | Base Paper Formulation | Freeze_V2 Code Implementation | Code File & Lines | Match Status | Classification |
|:---|:---|:---|:---|:---:|:---|
| **$T$ Parameter** | Not in Table 1 | Not in `init_params.m` | `init_params.m:1-65` | **MATCH** | Source Truth |
| **$T_{\max}$ Parameter** | None | None | `init_params.m:1-65` | **MATCH** | Source Truth |
| **SP2 Solution Method** | Proposes CVX for Eq. (23) | Analytical closed form: `T = T_delay`, `E = E_min`, `Pc = Pc_max` | `optimize_power_time.m:18-58` | **MATCH** (Analytical Reduction) | Valid Closed-Form Equivalent |
| **$T$ Selection in SP2** | Any $T \ge \max(T_{\mathrm{lat}}, E/P_c^{\max})$ | Sets $T = T_{\mathrm{delay}} = \max_k(t_k^l + t_k^u)$ | `optimize_power_time.m:53` | **MATCH** | Active Boundary Selection |
| **$P_c$ Selection in SP2** | Any $P_c = E/T \le P_c^{\max}$ | Sets $P_c = P_c^{\max}$ (`t0 = E_min/Pc_max`) | `optimize_power_time.m:40-44` | **MATCH** | Maximum Power Convention |
| **Stage 3 Epigraph $\tau$** | Epigraph of $e_{\mathrm{UAV}} = P_c T$ | `tau` represents $E_{\mathrm{WPT}} = P_c T$ (energy) | `compute_energy_demand.m:1-11`, `evaluate_constraint_vector.m:138-141` | **MATCH** | Correct Variable Identification |
| **Stage 3 Latency C1** | Constraint $t_k^l + t_k^u \le T$ | Excluded from $g(x)$; $f_k \equiv f_{\min}$ fixed | `evaluate_constraint_vector.m:1-16` | **DISCREPANCY** | **IMPLEMENTATION-ONLY REDUCTION** |

#### Explanation of Stage 3 Implementation Reduction:
In `final codebase/stage3_implementation`, the developers set $f_k \equiv f_{\min}$ in `compute_energy_demand.m` and omitted the latency constraint $\frac{R C_k D_k}{f_k} + t_k^u \le T$ from $g(x)$. 
- *Why did they do this?* Because without an upper bound $T_{\max}$, any latency demand $t_k^l + t_k^u$ can be accommodated simply by defining $T = \max_k (t_k^l + t_k^u)$ after the energy $\tau$ is minimized, and setting $f_k = f_{\min}$ minimizes the computing energy floor $E_{k,\mathrm{comp}}^{\min}$. 
- *Consequence:* This confirms that Stage 3 recognized that $T$ was completely unconstrained from above.

---

### G. Exact $T$-Projection Mathematics

We now formally derive the feasible-set projection of $T$ for all structural cases.

#### Case A: No Finite Upper Bound Exists (The True Base-Paper Model)
Let the optimization vector be partitioned into $x_{\mathrm{core}} = (E, r, v, p, b, f)$ and $T$. The constraints in $\mathcal{P}_0$ involving $T$ are:
$$T \ge T_{\mathrm{lat}}(x_{\mathrm{core}}) \triangleq \max_{k \in \mathcal{K}} \left\{ \frac{R C_k D_k}{f_k} + \frac{D}{R_k(r, v, p_k, b_k)} \right\},$$
$$T \ge T_{\mathrm{power}}(E) \triangleq \frac{E}{P_c^{\max}}.$$
The admissible interval for $T$ given $x_{\mathrm{core}}$ is:
$$\mathcal{T}(x_{\mathrm{core}}) = \left[ \max\left\{ T_{\mathrm{lat}}(x_{\mathrm{core}}), \; \frac{E}{P_c^{\max}} \right\}, \; \infty \right).$$

1. **Existence of Feasible $T$ (Projection onto $x_{\mathrm{core}}$):**
   Since $\mathcal{T}(x_{\mathrm{core}})$ is the intersection of two closed rays $[a, \infty) \cap [b, \infty) = [\max(a,b), \infty)$, it is **non-empty for every $x_{\mathrm{core}}$ with $E \ge 0, f_k > 0, R_k > 0$**.
   Therefore, the projection condition:
   $$\exists T \in \mathcal{T}(x_{\mathrm{core}}) \iff \text{True (Identically Satisfied)}.$$
2. **Elimination vs. Optimal Value:**
   - **Variable elimination from the constraint set:** Because the objective is $\min E$ (independent of $T$) and harvested energy $\lambda E |h_k|^2$ is independent of $T$, $T$ does **not** restrict the choice of $x_{\mathrm{core}}$. $T$ is completely eliminated from the reduced optimization problem $\mathcal{P}_1$!
   - **Recovery of Optimal $T$:** While any $T \in \mathcal{T}(x_{\mathrm{core}}^*)$ is optimal with respect to energy $E^*$, the physical task duration of the network is minimized by selecting the lower boundary point:
     $$T^* = \max\left\{ T_{\mathrm{lat}}(x_{\mathrm{core}}^*), \; \frac{E^*}{P_c^{\max}} \right\}.$$
     The optimal UAV transmit power is then uniquely recovered as:
     $$P_c^* = \frac{E^*}{T^*} \in [0, P_c^{\max}].$$

#### Case B: A Finite Deadline $T_{\max}$ Exists (Hypothetical Extension)
If an explicit upper bound $T \le T_{\max}$ is enforced, the admissible set becomes:
$$\mathcal{T}(x_{\mathrm{core}}) = \left[ \max\left\{ T_{\mathrm{lat}}(x_{\mathrm{core}}), \; \frac{E}{P_c^{\max}} \right\}, \; T_{\max} \right].$$
In this case, $\mathcal{T}(x_{\mathrm{core}}) \neq \emptyset$ if and only if:
$$T_{\mathrm{lat}}(x_{\mathrm{core}}) \le T_{\max} \quad \text{and} \quad E \le P_c^{\max} T_{\max}.$$
Here, $T$ is still eliminated from the search space, but leaves behind **two explicit inequality constraints** on $x_{\mathrm{core}}$:
$$\frac{R C_k D_k}{f_k} + \frac{D}{R_k} \le T_{\max}, \quad \forall k \in \mathcal{K}, \qquad \text{and} \qquad E \le P_c^{\max} T_{\max}.$$

#### Case C: $T = T_0$ is Fixed
If $T = T_0$ is a fixed constant parameter, $T$ is not an optimization variable. Then $P_c = E / T_0$ with $0 \le E \le P_c^{\max} T_0$, and user latency must satisfy $t_k^l + t_k^u \le T_0$.

---

### H. Constant-Energy Scaling Analysis

Does the model contain a "degeneracy" where $E \to 0$ as $T \to \infty$?
**NO. This claim is mathematically false.**

#### Proof:
1. Consider the hyperbola $P_c(T) = E / T$ for fixed $E > 0$.
2. As $T \to \infty$, $P_c(T) \to 0$, but their product $P_c(T) \cdot T \equiv E$ remains strictly constant.
3. In constraint C2, the harvested energy is:
   $$e_k = \lambda T P_c(T) |h_k|^2 = \lambda E |h_k|^2.$$
   This harvested energy is **identically constant** for all $T > 0$.
4. Can $E$ be chosen arbitrarily small (e.g., $E \to 0$)?
   Look at the user energy demand (LHS of C2):
   $$e_k^{\mathrm{demand}} = R \frac{\tau_k}{2} C_k D_k f_k^2 + \frac{p_k D}{R_k(r, v, p_k, b_k)}.$$
   - Since $f_k \ge f_k^{\min} = 0.1\text{ GHz}$, computing energy has a strict positive floor:
     $$e_k^l \ge R \frac{\tau_k}{2} C_k D_k (f_k^{\min})^2 = 10 \times (10^{-28}) \times 30 \times 400 \times (10^9 \times 0.1)^2 = 1.2 \times 10^{-7}\text{ J} > 0.$$
   - Uplink transmission of $D = 80\text{ kbits}$ over finite bandwidth $B \le 20\text{ MHz}$ requires strictly positive communication energy $e_k^u > 0$.
   - By energy causality (C2):
     $$E \ge \max_{k \in \mathcal{K}} \frac{e_k^l + e_k^u}{\lambda |h_k(r,v)|^2} \ge \frac{1.2 \times 10^{-7}\text{ J}}{\lambda \max_{r,v} |h_k(r,v)|^2} > 0.$$
5. **Conclusion:**
   The objective $E$ is **strictly bounded away from zero** by physical energy causality. The hyperbola $P_c = E/T$ represents a physical time-power exchange: the UAV can deliver the required Joules $E$ at high power over a short duration ($P_c = P_c^{\max}, T = E/P_c^{\max}$), or at lower power over a longer duration ($P_c < P_c^{\max}, T > E/P_c^{\max}$). The energy demand is invariant to this trade-off.

---

### I. Modeling Consequences for the New Secure Research Branch

1. **Option 1 (Exact Base-Paper Fidelity — RECOMMENDED FOR STAGE 1/2):**
   - Retain the exact base-paper model without an artificial $T_{\max}$.
   - $T$ is mathematically eliminated from the primal search space.
   - The reduced problem $\mathcal{P}_1$ optimizes $(E_{\mathrm{WPT}}, r, v, p, b, f)$.
   - Once solved, $T^*$ is recovered as $T^* = \max(T_{\mathrm{lat}}, E_{\mathrm{WPT}}/P_c^{\max})$ and $P_c^* = E_{\mathrm{WPT}}/T^*$.
   - **Advantage:** 100% faithful to Li et al. (2024); introduces zero ungrounded parameters; perfectly defensible against reviewers.
2. **Option 2 (Explicit FL Round Deadline $T_{\max}$ — OPTIONAL EXTENSION):**
   - Introduce an explicit maximum FL latency deadline $T_{\max}$ (e.g., $T_{\max} = 5\text{ s}$ or $10\text{ s}$) based on UAV battery limits.
   - **Consequence:** Adds explicit constraints $t_k^l + t_k^u \le T_{\max}$ and $E \le P_c^{\max} T_{\max}$.
   - **Reviewer Impact:** Must be clearly declared as a *new modeling extension* beyond Li et al. (2024).

---

### J. Formal Decision Tree

### Finding 1 — Original source contains finite $T_{\max}$
$$\boxed{\textbf{NO}}$$
*Evidence:* Exhaustive search of all equations (1)–(36), constraints C1–C9 in Eq. (18), Table 1, and Section 5 in Li et al. (2024) reveals zero occurrences of $T_{\max}$ or any finite upper bound on mission duration.

### Finding 2 — Original source fixes $T = T_0$
$$\boxed{\textbf{NO}}$$
*Evidence:* $T$ is explicitly listed as a primal optimization variable in Eq. (18) and Subproblem 2 (Eq. 22–23) of Li et al. (2024).

### Finding 3 — $T$ is genuinely unbounded above in the mathematical model
$$\boxed{\textbf{YES}}$$
*Evidence:* All constraints in Eq. (18) involving $T$ (C1, C2, C8) impose lower bounds ($T \ge \cdot$). The feasible interval for $T$ is $[T_{\min}, \infty)$.

### Finding 4 — $T$ can be eliminated exactly
$$\boxed{\textbf{YES}}$$
*Evidence:* In variables $(E, T)$ where $E = P_c T$, the objective is $\min E$ and constraints are independent of $T$ except for the lower bound $T \ge \max(T_{\mathrm{lat}}, E/P_c^{\max})$. Feasible-set projection eliminates $T$ completely from the core optimization, with exact recovery via $T^* = \max(T_{\mathrm{lat}}, E^*/P_c^{\max})$.

### Finding 5 — $E = P_c T$ reformulation is exact
$$\boxed{\textbf{YES}}$$
*Evidence:* For all $T > 0, P_c \ge 0$, the transformation $E = P_c T, P_c = E/T$ is an exact bijective mapping. This exact substitution is explicitly performed by Li et al. (2024) in Eq. (23).

### Finding 6 — A new finite FL deadline is required
$$\boxed{\textbf{MODELING DECISION}}$$
*Evidence:* The base model is mathematically closed and non-degenerate without $T_{\max}$. Adding $T \le T_{\max}$ is a justifiable physical extension for FL round deadlines, but is NOT required by the base mathematics.

---

### K. Stage 2A-1 Status

$$\boxed{\textbf{GREEN — CLOSED}}$$

The base paper and Freeze_V2 source materials have been exhaustively audited. The status of $T$ is 100% resolved with formal mathematical proofs.

---

### L. Stage 2B Authorization

$$\boxed{\textbf{AUTHORIZED}}$$

With the exact status of $T$ verified, Stage 2B (Detailed Mathematical Derivations & Analytical Subproblems) is formally authorized to proceed under **Option 1 (Exact Base-Paper Model with $T$ Eliminated via Projection)**.
