# STAGE 1: MATHEMATICAL REDUCTION & BCD/SCA/MM ARCHITECTURE
## Secure IRS-Assisted UAV Wireless-Powered Federated Learning

---

### 1. Purpose of Stage 1

This stage initiates a **deliberate architectural reset** for the UAV–IRS secure wireless-powered federated learning project.

The previous monolithic Riemannian augmented-Lagrangian framework (Freeze_V2 / Security_V2 / Stage 10) encountered severe, intrinsic numerical ill-conditioning at high penalty parameter values ($\rho \sim 10^6$), which caused inner step sizes to collapse to machine precision across all tested inner solvers (Riemannian Armijo SD, Spectral SD, L-BFGS, Riemannian Trust-Region, and preconditioned directions). 

The goal of this new branch is to return to the core physical and mathematical problem:
1. **Reconstruct** the exact base paper ("IRS-assisted UAV Wireless Powered Communication Network for Sustainable Federated Learning", *Physical Communication*, 2024).
2. **Incorporate** the exact robust physical-layer secrecy constraint under imperfect eavesdropper CSI without heuristic approximations.
3. **Perform exact variable and constraint reductions** based on mathematical optimality conditions (eliminating redundant variables with formal proofs).
4. **Formulate the reduced problem $\mathcal{P}_1$**.
5. **Derive the simplest defensible block structure** (BCD / SCA / MM) guided by the mathematical structure of each block rather than arbitrary choices.
6. **Establish a rigorous convergence roadmap** to pre-emptively address reviewer criticisms regarding surrogate monotonicity and limit-point stationarity before writing any MATLAB code.

---

### 2. Stage Structure

```
Stage 1/
├── README.md                           <- Stage overview, scope, and governance
├── DECISIONS.md                        <- Dated log of formal frozen architectural decisions
├── RESEARCH_ROADMAP.md                 <- Multi-stage research roadmap from reduction to validation
├── STAGE_1_DECISION.md                 <- Final Stage 1 audit report and gate decision
├── SOURCE_MATERIAL/                    <- Base paper text and primary reference materials
│   ├── base_paper_text.txt
│   ├── base_paper_sec2_3.txt
│   └── base_paper_sec4.txt
├── BASE_PAPER_RECONSTRUCTION/          <- Equation-by-equation reconstruction of Li et al. (2024)
│   └── base_problem.md
├── MATHEMATICAL_REDUCTION/             <- Exact reductions, proofs, and problem formulation
│   ├── P0_secure.md                    <- Full formulation P0 with exact robust secrecy
│   ├── variable_inventory.md           <- Comprehensive KEEP/ELIMINATE/FIX/DERIVED table
│   ├── elimination_proofs.md           <- Rigorous mathematical proofs for t_k^u, T, E_WPT, f_k
│   ├── WPT_energy_reduction.md         <- Detailed analysis of (P_c, T) -> E_WPT coupling
│   ├── P1_reduced.md                   <- Final minimal reduced problem P1
│   └── secrecy_block_mapping.md        <- Mapping of robust secrecy constraint into BCD blocks
├── LITERATURE/                         <- Structured matrix of recent relevant literature
│   └── literature_matrix.md
├── AUDITS/                             <- Proof strategies and reviewer traceability
│   └── convergence_blueprint.md        <- Monotonicity, compactness, and stationarity proof blueprint
└── LOGS/                               <- Stage activity logs and verification traces
```

---

### 3. Absolute Governance Rules

1. **Zero modifications** to the existing production code (`final codebase/stage3_implementation` is 100% frozen).
2. **Mathematics before algorithms**: Never select an optimization algorithm (BCD, SCA, MM, CVX) before completing the mathematical reduction.
3. **Exact secrecy integrity**: The robust secrecy constraint must remain exact at the problem-formulation level. No artificial noise, no heuristics, no heuristic penalty relaxations.
4. **No premature code**: No MATLAB implementation until Stage 1 is audited and formally closed.
