# STAGE 1: BASE-PAPER RECONSTRUCTION
## Equation-by-Equation Reconstruction and Audit of Li et al. (Physical Communication, 2024)

**Reference Paper:**  
Ruijie Li, Guoping Zhang, Yun Chen, "IRS-assisted UAV wireless powered communication network for sustainable federated learning", *Physical Communication*, vol. 67, 102504, 2024.

---

### 1. Geometric and Channel Model Equations

#### Equation (1)
- **Mathematical Expression:**
  $$d_{UA,k} = \sqrt{\|r_k - r\|^2 + H_A^2}$$
- **Physical Meaning:** Euclidean 3D distance between ground user $U_k$ (at horizontal coordinate $r_k = (x_k, y_k)$) and UAV (at horizontal coordinate $r = (x, y)$ and fixed altitude $H_A$).
- **Variables Involved:** UAV horizontal position $r \in \mathbb{R}^2$.
- **Parameters Involved:** User position $r_k \in \mathbb{R}^2$, UAV altitude $H_A > 0$.
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **NO** (secrecy adds eavesdropper channel, but legitimate user distance formula is unchanged).
- **Simplification / Elimination:** Remains as the fundamental geometric distance coupling UAV position $r$ to user channels.

#### Equation (2)
- **Mathematical Expression:**
  $$d_{UI,k} = \sqrt{\|r_k\|^2 + H_I^2}$$
- **Physical Meaning:** Euclidean 3D distance between ground user $U_k$ and the IRS (fixed on a building at horizontal coordinate $(0,0)$ and height $H_I$).
- **Variables Involved:** None (static geometry).
- **Parameters Involved:** User position $r_k$, IRS height $H_I$.
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **NO**.
- **Simplification / Elimination:** Pure constant parameter for each user $k$.

#### Equation (3)
- **Mathematical Expression:**
  $$d_{IA} = \sqrt{\|r\|^2 + (H_A - H_I)^2}$$
- **Physical Meaning:** Euclidean 3D distance between the IRS (at $(0,0,H_I)$) and the UAV (at $(x,y,H_A)$).
- **Variables Involved:** UAV horizontal position $r \in \mathbb{R}^2$.
- **Parameters Involved:** UAV altitude $H_A$, IRS height $H_I$.
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **NO**.
- **Simplification / Elimination:** Fundamental distance coupling UAV position $r$ to the IRS-UAV link.

#### Equation (4)
- **Mathematical Expression:**
  $$h_{UA,k} = \sqrt{\frac{\beta_0}{(d_{UA,k})^{\alpha_1}}} \widetilde{h}_{UA,k}$$
- **Physical Meaning:** Direct link channel coefficient between user $U_k$ and UAV, modeled with large-scale path loss exponent $\alpha_1$ and small-scale fading $\widetilde{h}_{UA,k}$.
- **Variables Involved:** $r$ (via $d_{UA,k}$).
- **Parameters Involved:** Reference gain $\beta_0$, path loss exponent $\alpha_1$, small-scale fading $\widetilde{h}_{UA,k}$.
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **NO**.
- **Simplification / Elimination:** Retained directly.

#### Equation (5)
- **Mathematical Expression:**
  $$h_{UI,k} = \sqrt{\frac{\beta_0}{(d_{UI,k})^{\alpha_2}}} \widetilde{h}_{UI,k} \in \mathbb{C}^N$$
- **Physical Meaning:** Channel vector between user $U_k$ and the $N$-element IRS with path loss exponent $\alpha_2$ and small-scale fading vector $\widetilde{h}_{UI,k}$.
- **Variables Involved:** None (static link).
- **Parameters Involved:** $\beta_0, d_{UI,k}, \alpha_2, \widetilde{h}_{UI,k}$.
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **NO**.
- **Simplification / Elimination:** Constant complex vector for each user $k$.

#### Equation (6)
- **Mathematical Expression:**
  $$h_{IA} = \sqrt{\frac{\beta_0}{(d_{IA})^2}} \widetilde{h}_{IA} \in \mathbb{C}^{1 \times N}$$
- **Physical Meaning:** Channel vector between IRS and UAV (assumed LoS-dominant with path loss exponent 2).
- **Variables Involved:** $r$ (via $d_{IA}$).
- **Parameters Involved:** $\beta_0, d_{IA}, \widetilde{h}_{IA}$.
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **NO**.
- **Simplification / Elimination:** Retained directly.

#### Equation (7)
- **Mathematical Expression:**
  $$h_k(r, \Theta) = h_{IA}(r) \Theta h_{UI,k} + h_{UA,k}(r) = h_{IA}(r) \operatorname{diag}(h_{UI,k}) v + h_{UA,k}(r)$$
  where $\Theta = \operatorname{diag}(e^{j\theta_1}, \dots, e^{j\theta_N})$ and $v = [e^{j\theta_1}, \dots, e^{j\theta_N}]^T \in \mathbb{T}^N$.
- **Physical Meaning:** Effective composite uplink channel coefficient for user $U_k$, combining the direct and IRS-reflected links.
- **Variables Involved:** UAV position $r$, IRS phase vector $v \in \mathbb{T}^N$.
- **Parameters Involved:** Channel parameters from (1)-(6).
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **YES** (In the new formulation, legitimate rate depends on $|h_k(r,v)|^2$, while eavesdropper interception depends on $|g_{e,k}(v)|^{\mathrm{wc}}$).
- **Simplification / Elimination:** Bilinear in $v$ and spatial channel vectors; standard cascaded channel representation $\Phi_k(r) v + h_{UA,k}(r)$ where $\Phi_k(r) = h_{IA}(r) \operatorname{diag}(h_{UI,k})$.

---

### 2. WPT and Energy Harvesting Model

#### Equation (8)
- **Mathematical Expression:**
  $$e_{\mathrm{UAV}} = P_c T$$
- **Physical Meaning:** Total energy emitted by the UAV during dedicated wireless power transfer over mission duration $T$.
- **Variables Involved:** UAV WPT power $P_c$, total mission duration $T$.
- **Parameters Involved:** None.
- **Part of New Formulation?** **YES (as Objective)**.
- **Modified by Robust Secrecy?** **NO**.
- **Simplification / Elimination:** Can be transformed into a single energy variable $E_{\mathrm{WPT}} = P_c T$ subject to $E_{\mathrm{WPT}} \le P_c^{\max} T$ (detailed in Section 9).

#### Equation (9)
- **Mathematical Expression:**
  $$e_k = \lambda T P_c |h_k|^2 = \lambda E_{\mathrm{WPT}} |h_k|^2$$
- **Physical Meaning:** RF energy harvested by user $U_k$ from the UAV transmission over duration $T$, where $\lambda \in (0,1]$ is the linear energy harvesting rectification efficiency.
- **Variables Involved:** $P_c, T$ (or $E_{\mathrm{WPT}}$), $r, v$ (via $h_k$).
- **Parameters Involved:** Energy harvesting conversion efficiency $\lambda$.
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **NO**.
- **Simplification / Elimination:** Depends on $(P_c, T)$ strictly through their product $E_{\mathrm{WPT}} = P_c T$.

---

### 3. Local Computation Model (Federated Learning)

#### Equation (10)
- **Mathematical Expression:**
  $$t_k^l = \frac{R C_k D_k}{f_k}$$
- **Physical Meaning:** Local computation latency for user $U_k$ to perform $R$ local SGD iterations over $D_k$ data samples, each requiring $C_k$ CPU cycles, given CPU clock frequency $f_k$.
- **Variables Involved:** User CPU frequency $f_k$.
- **Parameters Involved:** Local iterations $R$, CPU cycles per sample $C_k$, local dataset size $D_k$.
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **NO**.
- **Simplification / Elimination:** Strictly monotonic decreasing in $f_k$.

#### Equation (11)
- **Mathematical Expression:**
  $$e_k^l = R \frac{\tau_k}{2} C_k D_k f_k^2$$
- **Physical Meaning:** Energy consumed by user $U_k$ for local computation, where $\tau_k$ is the effective chip capacitance coefficient.
- **Variables Involved:** User CPU frequency $f_k$.
- **Parameters Involved:** $R, \tau_k, C_k, D_k$.
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **NO**.
- **Simplification / Elimination:** Strictly monotonic increasing in $f_k$.

---

### 4. Communication and Uplink Transmission Model

#### Equation (12)
- **Mathematical Expression:**
  $$y = \sum_{k=1}^K \sqrt{p_k} h_k s_k + z, \quad z \sim \mathcal{CN}(0, \sigma^2)$$
- **Physical Meaning:** Superimposed uplink signal received at the UAV from all $K$ users under parallel transmission.
- **Variables Involved:** User transmit powers $p_k$.
- **Parameters Involved:** Noise variance $\sigma^2 = N_0 B$.
- **Part of New Formulation?** **YES (Underlying physical signal model)**.
- **Modified by Robust Secrecy?** **YES** (Eavesdropper also overhears this signal).
- **Simplification / Elimination:** Under orthogonal frequency allocation (FDMA) with bandwidth $b_k$, each user occupies an orthogonal sub-band.

#### Equation (13)
- **Mathematical Expression:**
  $$R_k = b_k \log_2\left(1 + \frac{p_k |h_k|^2}{N_0 b_k}\right)$$
- **Physical Meaning:** Achievable uplink transmission rate (bits/sec) of user $U_k$ over allocated bandwidth $b_k$ with noise spectral density $N_0$.
- **Variables Involved:** Bandwidth $b_k$, power $p_k$, channel $h_k(r,v)$.
- **Parameters Involved:** Noise power spectral density $N_0$.
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **YES**. In robust secrecy, user $k$ must sustain an information secrecy rate:
  $$R_{\mathrm{sec},k} = \left[ b_k \log_2\left(1 + \frac{p_k |h_k|^2}{N_0 b_k}\right) - b_k \log_2\left(1 + \frac{p_k |g_{e,k}|^{\mathrm{wc}2}}{N_0 b_k}\right) \right]^+ \ge R_{s,k}.$$
- **Simplification / Elimination:** Essential capacity function.

#### Equation (14)
- **Mathematical Expression:**
  $$t_k^u R_k \ge D$$
- **Physical Meaning:** Transmission delay constraint: user $U_k$ must successfully upload the model update of size $D$ bits within uplink time $t_k^u$.
- **Variables Involved:** Uplink time $t_k^u$, rate $R_k$ (via $b_k, p_k, r, v$).
- **Parameters Involved:** Model update size $D$ (bits).
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **YES** (If transmission is confidential, upload requires $t_k^u R_{\mathrm{sec},k} \ge D$, or $R_{\mathrm{sec},k} \ge R_{s,k}$ with $t_k^u = D / R_k$).
- **Simplification / Elimination:** Can be satisfied with exact equality at an optimum ($t_k^u = D / R_k$).

#### Equation (15)
- **Mathematical Expression:**
  $$e_k^u = p_k t_k^u$$
- **Physical Meaning:** Energy expended by user $U_k$ for uplink model transmission.
- **Variables Involved:** Transmit power $p_k$, uplink time $t_k^u$.
- **Parameters Involved:** None.
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **NO**.
- **Simplification / Elimination:** When $t_k^u = D/R_k$, $e_k^u = \frac{p_k D}{R_k}$.

#### Equation (16)
- **Mathematical Expression:**
  $$t_k^l + t_k^u = \frac{R C_k D_k}{f_k} + t_k^u \le T, \quad \forall k \in \mathcal{K}$$
- **Physical Meaning:** Total task latency constraint: computation plus upload time of each user must not exceed the UAV mission duration $T$.
- **Variables Involved:** $f_k, t_k^u, T$.
- **Parameters Involved:** $R, C_k, D_k$.
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **NO**.
- **Simplification / Elimination:** Couples CPU allocation $f_k$, communication rate $R_k$, and mission duration $T$.

#### Equation (17)
- **Mathematical Expression:**
  $$e_k^l + e_k^u = R \frac{\tau_k}{2} C_k D_k f_k^2 + p_k t_k^u \le e_k = \lambda T P_c |h_k|^2, \quad \forall k \in \mathcal{K}$$
- **Physical Meaning:** Energy causality constraint: total energy consumed by user $U_k$ for local training and uplink transmission cannot exceed the energy harvested from the UAV.
- **Variables Involved:** $f_k, p_k, t_k^u, P_c, T$ (or $E_{\mathrm{WPT}}$), $r, v$.
- **Parameters Involved:** $R, \tau_k, C_k, D_k, \lambda$.
- **Part of New Formulation?** **YES**.
- **Modified by Robust Secrecy?** **NO**.
- **Simplification / Elimination:** Rewritten as $R \frac{\tau_k}{2} C_k D_k f_k^2 + p_k t_k^u \le \lambda E_{\mathrm{WPT}} |h_k|^2$.

---

### 5. Base Paper Optimization Problem Formulation (Equation 18)

#### Equation (18)
- **Mathematical Expression:**
  $$\min_{P_c, T, \Theta, r, p_k, b_k, f_k} P_c T$$
  subject to:
  $$\begin{aligned}
  C1: \quad & \frac{R C_k D_k}{f_k} + t_k^u \le T, && \forall k \in \mathcal{K} \\
  C2: \quad & R \frac{\tau_k}{2} C_k D_k f_k^2 + p_k t_k^u \le \lambda T P_c |h_k|^2, && \forall k \in \mathcal{K} \\
  C3: \quad & t_k^u b_k \log_2\left(1 + \frac{p_k |h_k|^2}{N_0 b_k}\right) \ge D, && \forall k \in \mathcal{K} \\
  C4: \quad & 0 \le p_k \le p_{\max}, && \forall k \in \mathcal{K} \\
  C5: \quad & \sum_{k=1}^K b_k \le B, \quad b_k \ge 0, && \forall k \in \mathcal{K} \\
  C6: \quad & f_k^{\min} \le f_k \le f_k^{\max}, && \forall k \in \mathcal{K} \\
  C7: \quad & 0 \le \theta_n \le 2\pi, && \forall n \in \mathcal{N} \\
  C8: \quad & 0 \le P_c \le P_c^{\max} \\
  C9: \quad & \|r\|_2^2 \le d^2
  \end{aligned}$$
- **Physical Meaning:** Joint minimization of UAV WPT energy consumption while guaranteeing FL convergence, energy causality, delay, and hardware limits.
- **Variables Involved:** $P_c, T, \Theta, r, \{p_k\}, \{b_k\}, \{f_k\}$, and implicitly $\{t_k^u\}$.
- **Parameters Involved:** $R, C_k, D_k, \tau_k, \lambda, D, p_{\max}, B, f_k^{\min}, f_k^{\max}, P_c^{\max}, d, H_A, H_I, \beta_0, \alpha_1, \alpha_2, N_0$.
- **Part of New Formulation?** **Serves as Base Problem $\mathcal{P}_{\mathrm{base}}$**.
- **Modified by Robust Secrecy?** **YES — MUST ADD EXACT ROBUST SECRECY CONSTRAINT**.
- **Simplification / Elimination:**
  1. $t_k^u$ can be eliminated by substituting its exact active lower bound $D / R_k$.
  2. $(P_c, T)$ can be condensed into $E_{\mathrm{WPT}} = P_c T$.
  3. $f_k$ can be evaluated analytically or conditionally optimized.

---

### 6. Audit of the Base Paper's Solution Method (Equations 19 to 36)

The base paper solves (18) using an alternating 4-subproblem heuristic:
1. **Sub-problem 1 (Phase Shift $\Theta$, Eqs 19–21):**
   - The authors write $\theta_{k,n}^* = \arg(h_{UA,k}) - \arg(h_{IA,n}) - \arg(h_{UI,k,n})$.
   - **Critical Mathematical Flaw in Base Paper:** For $K > 1$ users, $\theta_{k,n}^*$ depends on $k$! One single IRS phase configuration $\Theta$ cannot simultaneously align phases for all $K$ independent users. Thus, Eq. (21) is a heuristic that does not optimize the actual multi-user sum or bottleneck. In our new formulation, $v \in \mathbb{T}^N$ must be optimized systematically via SCA/MM across all $K$ users and the eavesdropper.
2. **Sub-problem 2 ($P_c, T$, Eqs 22–23):**
   - Substitutes $E = P_c T$. Solves LP/convex problem in $(E, T)$ via CVX. Valid reduction!
3. **Sub-problem 3 ($p_k, b_k, f_k$, Eqs 24–29):**
   - Assumes $C1$ active $\implies f_k^* = \min\{\max\{f_k^{\min}, \frac{R C_k D_k}{T - t_k^u}\}, f_k^{\max}\}$.
   - Assumes $C3$ active $\implies p_k^* = \frac{N_0 b_k}{|h_k|^2} (2^{\frac{D}{t_k^u b_k}} - 1)$.
   - Proves convexity of $p_k^*$ in $b_k$ (Lemma 1).
4. **Sub-problem 4 (UAV position $r$, Eqs 30–36):**
   - Introduces slack variables $\kappa \ge d_{IA}$ and $\mu_k \ge d_{UA,k}$, then applies first-order Taylor expansion (SCA) to obtain a convex subproblem in CVX.
