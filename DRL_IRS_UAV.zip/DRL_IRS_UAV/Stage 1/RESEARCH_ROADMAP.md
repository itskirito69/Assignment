# STAGE 1: RESEARCH ROADMAP
## Secure IRS-Assisted UAV Wireless-Powered Federated Learning

---

### Multi-Stage Research Program

```mermaid
flowchart TD
    subgraph Stage1 [Stage 1: Mathematical Reduction & Architecture Design]
        S1A[1A: Base Paper Reconstruction] --> S1B[1B: Robust Secrecy Insertion]
        S1B --> S1C[1C: Variable Inventory & Exact Eliminations]
        S1C --> S1D[1D: Minimal Reduced Problem P1]
        S1D --> S1E[1E: Block Structure & Mathematical Classification]
        S1E --> S1F[1F: SCA/MM Surrogate Design & Secrecy Mapping]
        S1F --> S1G[1G: Convergence Proof Blueprint]
    end

    subgraph Stage2 [Stage 2: Mathematical Derivations & Analytical Subproblems]
        S2A[2A: Subproblem Convexity & Invariant Proofs] --> S2B[2B: Closed-Form Derivations]
        S2B --> S2C[2C: Rigorous SCA Minorizers/Majorizers]
        S2C --> S2D[2D: Complete Algorithm Specification]
    end

    subgraph Stage3 [Stage 3: Verified MATLAB Implementation]
        S3A[3A: Clean Modular Solver Implementation] --> S3B[3B: Subproblem Analytic Gradient & Invariant Unit Tests]
        S3B --> S3C[3C: CVX / Manopt Independent Cross-Check]
        S3C --> S3D[3D: Monotonicity & Stationarity Numerical Certification]
    end

    subgraph Stage4 [Stage 4: Comprehensive Numerical Validation & Benchmarks]
        S4A[4A: Secrecy vs Energy Trade-off Curves] --> S4B[4B: Imperfect CSI Sensitivity Campaign]
        S4B --> S4C[4C: Benchmark Comparisons]
        S4C --> S4D[4D: Reviewer 2 & Reviewer 3 Rebuttal Artifacts]
    end

    Stage1 --> Stage2
    Stage2 --> Stage3
    Stage3 --> Stage4
```

---

### Detailed Stage Gate Requirements

| Stage | Focus Area | Essential Deliverables | Gate Condition to Advance |
|:---:|:---|:---|:---|
| **Stage 1** | Mathematical Reduction & BCD Architecture | Exact reconstruction of Li et al. (2024); exact secrecy inclusion; formal proofs for $t_k^u, T, E_{\mathrm{WPT}}, f_k$; minimal reduced problem $\mathcal{P}_1$; block classification; convergence proof blueprint. | Formal sign-off on 16 checklist items; zero unproven eliminations; no code written. |
| **Stage 2** | Detailed Subproblem Analytics | Explicit analytic derivation of each BCD block; proof of surrogate tangency and minorization; feasibility preservation proofs; formal convergence theorem statement. | All surrogates verified analytically tangent with zero heuristic slack. |
| **Stage 3** | Verified Clean Codebase | New clean MATLAB solver in isolated directory; unit tests on all subproblems; bitwise reproducibility checks; monotonic objective verification. | Zero code modifications to old codebase; monotonic descent numerically certified. |
| **Stage 4** | Numerical Simulation Campaign | Full Monte Carlo simulations across CSI uncertainty radii $\epsilon_{IE}, \epsilon_{UE}$, IRS element counts $N$, user counts $K$, and Eve distances $d_E$; baseline comparisons. | Publication-quality figures; rigorous Reviewer 2/3 responses backed by empirical data. |
