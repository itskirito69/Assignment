# STAGE 1: CONVERGENCE PROOF BLUEPRINT
## Theoretical Strategy to Guarantee Monotonicity, Compactness, and Limit-Point Stationarity

---

### 1. Motivation and Previous Reviewer Objections

In previous iterations of this research, reviewers raised two fundamental theoretical objections regarding alternating optimization:

> **Reviewer Objection 1:**  
> *"The surrogate update does not guarantee monotonic decrease of the original/global objective across alternating iterations when constraints are non-convex."*

> **Reviewer Objection 2:**  
> *"The outer alternating algorithm is not shown to converge to a stationary point of the original optimization problem, only to solutions of ad-hoc approximate subproblems."*

This document outlines the **8-step mathematical blueprint** to be formally proven before implementing any MATLAB solver, guaranteeing that the BCD/SCA/MM architecture is theoretically sound.

---

### 2. The 8-Step Convergence Strategy

```mermaid
flowchart TD
    S1[Step 1: Exact Equivalence of Eliminations] --> S2[Step 2: Surrogate Minorization & Tangency]
    S2 --> S3[Step 3: Monotonic Global Objective Non-Increase]
    S3 --> S4[Step 4: Strict Lower Bound on Objective]
    S4 --> S5[Step 5: Compactness of Feasible Level Sets]
    S5 --> S6[Step 6: Existence of Limit Points / Accumulation Points]
    S6 --> S7[Step 7: Blockwise Coordinate Stationarity]
    S7 --> S8[Step 8: Mapping Blockwise Stationarity to KKT of P1]
```

---

#### Step 1: Exact Equivalence of Every Variable Elimination
- **Requirement:** Formally establish that $\min \mathcal{P}_0 = \min \mathcal{P}_1$ and that the mapping between primal feasible sets is bijective on the optimal solution set.
- **Status in Stage 1:** **PROVEN.**
  - Theorem 1 establishes exact elimination of $t_k^u = D/R_k$ by proving strict constraint boundary attainment.
  - Theorem 2 establishes condensation of $(P_c, T) \to E_{\mathrm{WPT}} = P_c T$.
  - Theorem 3 establishes the closed-form boundary for $f_k^*(T)$.
  - Theorem 4 establishes the exact closed-form power lower bound $p_k \ge \max(p_k^{\mathrm{sec}}, p_k^{\mathrm{comm}})$.

---

#### Step 2: Surrogate Validity, Tangency, and Inner Approximation
For each non-convex block solved via SCA or MM (Block 1: UAV position $r$; Block 2: IRS phase $v$):
1. **Majorization / Minorization Property:**
   Let $g(x)$ be a constraint function $g(x) \le 0$. A surrogate $\widetilde{g}(x; x^{(i)})$ is an upper bounding surrogate (conservative inner approximation) if:
   $$\widetilde{g}(x; x^{(i)}) \ge g(x), \quad \forall x.$$
   Consequently, satisfying the surrogate constraint $\widetilde{g}(x; x^{(i)}) \le 0$ strictly guarantees that the true constraint $g(x) \le 0$ is satisfied:
   $$\mathcal{X}_{\mathrm{inner}}^{(i)} \triangleq \{x : \widetilde{g}(x; x^{(i)}) \le 0\} \subseteq \mathcal{X} \triangleq \{x : g(x) \le 0\}.$$
2. **First-Order Tangency:**
   At the expansion point $x = x^{(i)}$:
   $$\widetilde{g}(x^{(i)}; x^{(i)}) = g(x^{(i)}) \quad \text{and} \quad \nabla_x \widetilde{g}(x^{(i)}; x^{(i)}) = \nabla g(x^{(i)}).$$
3. **Guarantee:** Because $x^{(i)}$ was feasible for the previous iteration, it remains feasible for the current surrogate subproblem:
   $$x^{(i)} \in \mathcal{X}_{\mathrm{inner}}^{(i)}.$$

---

#### Step 3: Monotonic Sequence of Original Objective Values
Let the objective be $F(x) = E_{\mathrm{WPT}}$.
In each BCD cycle $i \to i+1$:
1. **Position Update ($r^{(i+1)}$):** Solves $\min_{r \in \mathcal{R}^{(i)}} E_{\mathrm{WPT}}(r, v^{(i)}, \text{res}^{(i)})$.
   Since $r^{(i)}$ is feasible in $\mathcal{R}^{(i)}$, the optimal update satisfies:
   $$E_{\mathrm{WPT}}(r^{(i+1)}, v^{(i)}, \text{res}^{(i)}) \le E_{\mathrm{WPT}}(r^{(i)}, v^{(i)}, \text{res}^{(i)}).$$
2. **Phase Update ($v^{(i+1)}$):** Solves $\min_{v \in \mathcal{V}^{(i)}} E_{\mathrm{WPT}}(r^{(i+1)}, v, \text{res}^{(i)})$.
   By identical logic:
   $$E_{\mathrm{WPT}}(r^{(i+1)}, v^{(i+1)}, \text{res}^{(i)}) \le E_{\mathrm{WPT}}(r^{(i+1)}, v^{(i)}, \text{res}^{(i)}).$$
3. **Resource Update ($\text{res}^{(i+1)}$):**
   $$E_{\mathrm{WPT}}(r^{(i+1)}, v^{(i+1)}, \text{res}^{(i+1)}) \le E_{\mathrm{WPT}}(r^{(i+1)}, v^{(i+1)}, \text{res}^{(i)}).$$
Summing across all blocks in cycle $i$:
$$E_{\mathrm{WPT}}^{(i+1)} \le E_{\mathrm{WPT}}^{(i)}.$$
**Conclusion:** The sequence $\{E_{\mathrm{WPT}}^{(i)}\}$ is **strictly non-increasing** across outer BCD iterations.

---

#### Step 4: Strict Lower Bounding
- The objective $E_{\mathrm{WPT}}$ represents total radiated RF energy.
- Physically: $E_{\mathrm{WPT}} \ge 0$.
- Mathematically, from constraint C2:
  $$E_{\mathrm{WPT}} \ge \max_{k \in \mathcal{K}} \frac{e_k^l + e_k^u}{\lambda |h_k|^2} \ge \max_{k \in \mathcal{K}} \frac{R \frac{\tau_k}{2} C_k D_k (f_k^{\min})^2}{\lambda \max_{r,v} |h_k(r,v)|^2} > 0.$$
- Since the sequence $\{E_{\mathrm{WPT}}^{(i)}\}$ is monotonic non-increasing and bounded below by a strictly positive physical threshold $E_{\min} > 0$, by the Monotone Convergence Theorem:
  $$\lim_{i \to \infty} E_{\mathrm{WPT}}^{(i)} = E^* \quad \text{exists and is finite.}$$

---

#### Step 5: Compactness of Iterate Domain
The optimization domain $\mathcal{D} = \mathcal{D}_r \times \mathcal{D}_v \times \mathcal{D}_p \times \mathcal{D}_b \times \mathcal{D}_f \times \mathcal{D}_E \times \mathcal{D}_T$ is compact:
1. $r \in \{r : \|r\|_2 \le d\} \subset \mathbb{R}^2$ is closed and bounded.
2. $v \in \mathbb{T}^N = \{v \in \mathbb{C}^N : |v_n| = 1\}$ is a compact torus.
3. $p_k \in [0, p_{\max}]$ is a closed bounded interval.
4. $b_k \in [0, B]$ with $\sum_k b_k \le B$ is a compact simplex.
5. $f_k \in [f_k^{\min}, f_k^{\max}]$ is a closed bounded interval.
6. $E_{\mathrm{WPT}} \in [E_{\min}, E_{\mathrm{WPT}}^{(0)}]$ is bounded by the initial feasible energy.
7. $T \in [T_{\min}, T_{\max}]$ is bounded by the minimum latency and maximum flight window.
By the Bolzano–Weierstrass Theorem, the sequence of iterates $\{x^{(i)}\}$ has at least one convergent subsequence with a limit point $x^* \in \mathcal{D}$.

---

#### Step 6: Feasibility of Accumulation Points
Since all constraint functions and their conservative surrogates are continuous, and since each surrogate satisfies $\widetilde{g}(x^{(i+1)}; x^{(i)}) \le 0 \implies g(x^{(i+1)}) \le 0$:
Taking limits along the convergent subsequence:
$$g(x^*) = \lim_{j \to \infty} g(x^{(i_j)}) \le 0.$$
Every limit point $x^*$ is **strictly feasible** for the original problem $\mathcal{P}_1$ (and therefore $\mathcal{P}_0$).

---

#### Step 7: Blockwise Coordinate Stationarity
For each convexified subproblem $\min_{x_j \in \mathcal{X}_j(x_{-j}^*)} \widetilde{F}(x_j; x^*)$, the necessary and sufficient first-order optimality condition is:
$$\langle \nabla_{x_j} \widetilde{F}(x_j^*; x^*), x_j - x_j^* \rangle \ge 0, \quad \forall x_j \in \mathcal{X}_j(x_{-j}^*).$$
By the first-order tangency of the surrogates established in Step 2:
$$\nabla_{x_j} \widetilde{F}(x_j^*; x^*) = \nabla_{x_j} F(x^*),$$
and the tangent cones to the surrogate feasible set and the original feasible set coincide at $x^*$. Thus:
$$\langle \nabla_{x_j} F(x^*), x_j - x_j^* \rangle \ge 0, \quad \forall x_j \in \mathcal{X}_j(x_{-j}^*), \quad \forall j \in \{1, \dots, B\}.$$

---

#### Step 8: Mapping to KKT Stationarity of $\mathcal{P}_1$
Following the classical results of Razaviyayn, Sanjabi, and Luo (*SIAM Journal on Optimization*, 2013, Theorem 2.3 for Successive Upper-bound Minimization / BCD):
When each block subproblem is solved to its unique global optimum or stationary point under regular constraints satisfying the Mangasarian–Fromovitz Constraint Qualification (MFCQ):
> **Every accumulation point $x^*$ of the proposed BCD/SCA/MM algorithm is a KKT stationary point of the original reduced problem $\mathcal{P}_1$.**

This completely resolves Reviewer Objection 1 (monotonicity is guaranteed by Step 3) and Reviewer Objection 2 (stationarity of the original problem is guaranteed by Steps 7 and 8).
