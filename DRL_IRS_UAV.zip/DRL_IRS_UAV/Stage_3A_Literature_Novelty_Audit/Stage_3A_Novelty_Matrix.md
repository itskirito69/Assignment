# Stage 3A — Novelty Matrix

*Extracted from Stage_3A_Literature_Audit.md, PART II*

| Feature | Base (A3/B4) | Paper 2 (B3) | Paper 3 (F2) | Paper 4 (G1) | F1 | H2 | I1 | **OURS** |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| UAV | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ | ✅ | ✅ |
| IRS/RIS | ✅ | ✅ (STAR) | ✅ | ❌ | ✅ | ✅ | ❌ | ✅ |
| FL (as application) | ✅ | ✅ (AirFL) | ❌ (FL trains DRL) | ✅ | ✅ | ❌ | ✅ | ✅ |
| Wireless Power (WPCN) | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| DRL control | ❌ | ✅ (SAC+DDQN) | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ |
| FL-aware state/reward | ❌ | ❌ (client count) | ❌ | ❌ | ❌ | ❌ | ✅ (loss) | ✅ (loss+trust) |
| PLS (any) | ❌ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | ✅ |
| Imperfect Eve CSI | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ (partial) | ❌ | ✅ |
| Robust worst-case secrecy | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ (reward) | ❌ | ✅ (hard constraint) |
| Byzantine FL | ❌ | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ | ✅ |
| Trust/reputation | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| Cross-layer FL↔wireless | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | partial | ✅ |
| Hard secrecy constraint | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ (micro-layer) |
| Model-based micro-layer | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |

