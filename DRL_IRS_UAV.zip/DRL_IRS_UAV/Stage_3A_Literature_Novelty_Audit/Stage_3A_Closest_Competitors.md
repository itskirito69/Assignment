# Stage 3A — 5 Closest Competitors

*Extracted from Stage_3A_Literature_Audit.md, PART III*

## Competitor 1: Base Paper (Li et al., Physical Communication, 2024)

**System:** UAV + IRS + WPCN + FL.
**Method:** BCD/SCA/AO static optimization.
**Missing:** DRL, security, imperfect CSI, Byzantine, sequential control, cross-layer coupling.
**Minimum difference from ours:** 6 components (DRL, PLS, imperfect CSI, robust secrecy, Byzantine, cross-layer).

## Competitor 2: STAR-RIS AirFL with DRL (Wu et al., 2024)

**System:** STAR-RIS + UAV + AirFL + DRL (SAC+DDQN).
**Method:** Dual-network hierarchical DRL; maximize client participation under aggregation error.
**Missing:** WPCN, security, imperfect CSI, robust secrecy, Byzantine, trust, FL-progress-aware state, model-based micro-layer, hard physical constraints.
**Minimum difference from ours:** 8 components. This paper is the closest DRL+IRS+UAV+FL competitor but is missing ALL security and Byzantine dimensions.

## Competitor 3: Byzantine AirFL with UAV (Fan et al., 2024)

**System:** UAV + AirFL + Byzantine attacks.
**Method:** Robust aggregation + power control; convergence analysis.
**Missing:** IRS, WPCN, DRL, PLS, imperfect CSI, trust-based scheduling, cross-layer FL-wireless coupling.
**Minimum difference from ours:** 7 components.

## Competitor 4: IRS-assisted PLS for FL (TVT, 2024)

**System:** IRS + FL + PLS (secrecy rate).
**Method:** AO/SCA for IRS phase + beamforming.
**Missing:** UAV, WPCN, DRL, imperfect CSI, robust secrecy, Byzantine, trust, cross-layer, hard secrecy.
**Minimum difference from ours:** 8 components.

## Competitor 5: DRL Robust Secure Beamforming with Imperfect CSI (TVT, 2024)

**System:** IRS + PLS + imperfect CSI + DRL.
**Method:** DDPG/SAC; security as reward penalty.
**Missing:** UAV, WPCN, FL, Byzantine, trust, FL-aware state, hard secrecy constraint, model-based micro-layer.
**Minimum difference from ours:** 7 components. Critically: security is a reward penalty, not a hard constraint.

