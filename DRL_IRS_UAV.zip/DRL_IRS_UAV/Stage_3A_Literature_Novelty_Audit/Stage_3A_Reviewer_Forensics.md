# Stage 3A — Reviewer Forensics

*Extracted from Stage_3A_Literature_Audit.md, PART X*

## Previous Reviewer Vulnerabilities vs. Current Formulation

| Previous Reviewer Concern | Does DRL Eliminate It? | Does DRL Merely Relocate It? | What Must Be Done? |
|---|---|---|---|
| Outer-loop AO monotonicity | ✅ Eliminated (no AO outer loop) | — | DRL replaces AO; no monotonicity claim needed |
| Stationarity of original optimization | ✅ Eliminated (no stationarity claim) | — | We claim "trained policy," not "stationary point" |
| True secrecy constraint enforcement | ✅ Preserved | — | Hard C9 in micro-layer; same as Stage 1 |
| Solver convergence | ⚠️ Partially relocated | Yes: from "BCD convergence" to "DRL training convergence" | We make NO solver convergence claim; micro-layer is a numerical search |
| Feasibility | ✅ Improved | — | Three-outcome distinction (success/structural infeasibility/solver failure) |
| Stochastic policy training | — | Yes: new vulnerability | Must report: training curves, multiple seeds, hyperparameter sensitivity |
| Reproducibility | — | Yes: new vulnerability | Must provide: code, seeds, training logs, hyperparameters |
| Hyperparameter sensitivity | — | Yes: new vulnerability | Must run sensitivity analysis on $\delta_{\max}$, $\gamma$, learning rates |
| Random seed dependence | — | Yes: new vulnerability | Must report: mean ± std over ≥5 seeds |

## Net Assessment

The DRL direction genuinely eliminates the AO convergence vulnerabilities (Reviewer 2/3 primary concerns) but introduces new empirical vulnerabilities. These are **standard** in the DRL literature and manageable through proper experimental methodology.

