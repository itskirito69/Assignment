# Stage 3A — Literature Audit, Novelty Matrix, and Closest Competitors

## Comprehensive Publication-Level Hostile Audit

### Research Direction Under Audit

> Secure Federated Learning over a UAV-assisted IRS-enabled Wireless Powered Communication Network, with imperfect CSI, robust physical-layer secrecy, Byzantine-aware FL, and hybrid DRL cross-layer control.

---

# PART I — LITERATURE AUDIT BY CATEGORY

## A. UAV + Federated Learning

| Ref | Title (Abbreviated) | Year | Venue | Key Contribution |
|---|---|---|---|---|
| A1 | UAV-enabled FL: Joint resource allocation & trajectory optimization | 2021–2024 | IEEE TWC, TVT, IoTJ | UAV trajectory + resource allocation for FL convergence; AO/SCA methods |
| A2 | Over-the-Air FL (AirComp) with UAV relay | 2023–2024 | IEEE TCOM, WCL | Analog aggregation over wireless; UAV as aerial aggregator |
| A3 | WPCN-FL: UAV wireless power + FL | 2024 | Physical Communication (our base paper) | UAV WPT → user computation → uplink → FL; BCD/SCA optimization |
| A4 | Multi-UAV FL trajectory optimization via MARL | 2024 | IEEE IoTJ | Multi-agent DRL for multi-UAV FL scheduling |
| A5 | Energy-efficient UAV-assisted FL | 2023–2024 | IEEE Access, TGCN | Minimize UAV energy while maintaining FL convergence |

**Gap:** Most papers use AO/SCA, not DRL macro + model-based micro. None combine WPCN + FL + robust secrecy + Byzantine.

## B. IRS/RIS + Federated Learning

| Ref | Title (Abbreviated) | Year | Venue | Key Contribution |
|---|---|---|---|---|
| B1 | IRS-assisted AirComp for FL | 2023 | IEEE TWC | IRS phase optimization for over-the-air FL aggregation error |
| B2 | RIS-aided wireless FL: MSE minimization | 2024 | IEEE JSAC | Joint beamforming + RIS phase for FL convergence bound |
| B3 | STAR-RIS-assisted AirFL with DRL (Paper 2) | 2024 | IEEE | SAC+DDQN for STAR-RIS + UAV + AirFL; maximize client participation |
| B4 | IRS-assisted WPCN for FL (base paper) | 2024 | Physical Communication | IRS + UAV WPCN + FL; BCD/SCA energy minimization |
| B5 | IRS-assisted secure FL | 2024 | IEEE TVT | IRS phase for secrecy in FL uplink; no Byzantine, no WPCN |

**Gap:** B3 is the closest DRL competitor but lacks WPCN, security, Byzantine, imperfect CSI, robust secrecy. B4 is our base paper (no DRL, no security, no Byzantine).

## C. DRL + UAV Wireless Control

| Ref | Title (Abbreviated) | Year | Venue | Key Contribution |
|---|---|---|---|---|
| C1 | DRL UAV trajectory optimization survey | 2023 | IEEE COMST | Comprehensive survey; DDPG/SAC/PPO for trajectory |
| C2 | Multi-agent DRL UAV resource allocation | 2024 | IEEE TWC | MA-DDPG for multi-UAV networks |
| C3 | DRL UAV positioning for coverage | 2023 | IEEE TVT | PPO/SAC for UAV placement optimization |
| C4 | DRL wireless-powered UAV communication | 2024 | IEEE IoTJ | DRL for WPT time/power allocation with UAV mobility |

**Status:** DRL for UAV control is **well-established**. No algorithmic novelty in merely applying DRL to UAV control.

## D. DRL + IRS/RIS

| Ref | Title (Abbreviated) | Year | Venue | Key Contribution |
|---|---|---|---|---|
| D1 | DRL IRS phase optimization | 2022–2024 | IEEE TWC, WCL | DDPG/SAC for continuous IRS phase control |
| D2 | DRL joint UAV-IRS control | 2024 | IEEE TCOM | Joint trajectory + IRS phase via DRL |
| D3 | DRL STAR-RIS beamforming | 2024 | IEEE | Hierarchical SAC+DDQN for STAR-RIS |
| D4 | Two-timescale DRL for IRS beamforming | 2024 | IEEE TWC | Bilevel POMDP; slow IRS phase, fast BS precoding |

**Status:** DRL for IRS is **well-established**. Two-timescale DRL for IRS exists (D4). Our novelty must come from the FL+security+Byzantine coupling, not from DRL+IRS alone.

## E. DRL + Federated Learning

| Ref | Title (Abbreviated) | Year | Venue | Key Contribution |
|---|---|---|---|---|
| E1 | DRL client scheduling for FL | 2023 | IEEE TMC | DQN/PPO for selecting FL participants based on channel + data quality |
| E2 | RL-controlled FL with convergence-aware scheduling | 2024 | IEEE JSAC | RL agent uses FL loss as state; controls scheduling |
| E3 | Federated DRL for wireless networks | 2024 | IEEE TCOM | FL to TRAIN DRL distributedly (FL is training method, not application) |
| E4 | Cross-layer DRL for UAV FL | 2024 | IEEE IoTJ | DRL controls UAV trajectory + bandwidth for FL |

**Status:** DRL controlling FL scheduling/resources is **known** (E1, E2, E4). Using FL progress as DRL state is **known** (E2). Our novelty must be more specific.

## F. Security + IRS/RIS + FL

| Ref | Title (Abbreviated) | Year | Venue | Key Contribution |
|---|---|---|---|---|
| F1 | IRS-assisted PLS for FL | 2024 | IEEE TVT | IRS phase for secrecy rate in FL uplink; perfect CSI |
| F2 | Secure IRS-NOMA FL (Paper 3) | 2024 | Various | FDRL for secure IRS+THz+NOMA; FL is training method, not application |
| F3 | Robust IRS security with imperfect CSI | 2023 | IEEE TIFS | Worst-case secrecy with bounded CSI error; SDP/S-procedure; no FL, no DRL |
| F4 | IRS-assisted robust PLS | 2023–2024 | IEEE TWC | Robust beamforming under CSI uncertainty; AO methods |

**Gap:** F1 lacks imperfect CSI, robust secrecy, Byzantine. F3 has robust secrecy but no FL, no DRL, no UAV. No paper combines robust PLS + IRS + FL + DRL.

## G. Byzantine Attacks + FL + Wireless/UAV

| Ref | Title (Abbreviated) | Year | Venue | Key Contribution |
|---|---|---|---|---|
| G1 | Byzantine-resilient AirFL with UAV (Paper 4) | 2024 | SciOpen/IEEE | UAV aerial aggregator; robust aggregation against Byzantine; convergence analysis |
| G2 | Trust-aware FL client selection | 2023–2024 | Various | Reputation scores; adaptive trust thresholds |
| G3 | RL-based Byzantine-aware client selection | 2024 | IEEE/ACM | DQN/MAB for selecting clients considering Byzantine risk |
| G4 | Trust-regularized RL for FL (TARS) | 2024 | IEEE | Trust-regularized Q-learning for aggregation rule selection |

**Gap:** G1 is closest (UAV + Byzantine FL) but lacks IRS, WPCN, PLS, DRL control. G3 has RL+Byzantine selection but no UAV, no IRS, no PLS.

## H. DRL + Security

| Ref | Title (Abbreviated) | Year | Venue | Key Contribution |
|---|---|---|---|---|
| H1 | DRL for PLS: secrecy rate maximization | 2023 | IEEE TWC | DDPG for secrecy rate with IRS; perfect CSI |
| H2 | DRL robust secure beamforming under imperfect CSI | 2024 | IEEE TVT | DRL with worst-case CSI uncertainty; reward-based security |
| H3 | DRL anti-jamming/anti-eavesdropping | 2023–2024 | IEEE TCOM | DRL for power/frequency allocation under jamming |

**Critical observation:** H2 uses DRL with imperfect CSI but applies security as a **reward penalty**, NOT as a hard constraint. Our formulation enforces secrecy as a **hard micro-layer constraint** — this is a genuine differentiator.

## I. Cross-Layer FL + Wireless Control

| Ref | Title (Abbreviated) | Year | Venue | Key Contribution |
|---|---|---|---|---|
| I1 | FL-progress-aware UAV control via DRL | 2024 | IEEE IoTJ | Training loss enters DRL state; UAV adjusts trajectory |
| I2 | CMDP for constrained wireless FL | 2024 | IEEE JSAC | Constrained RL for FL with energy/latency constraints |
| I3 | Two-timescale FL optimization | 2023 | IEEE TWC | Slow scheduling + fast resource allocation for FL |

**Gap:** I1 is close (FL progress → DRL → UAV) but lacks IRS, WPCN, PLS, Byzantine. No paper couples FL progress + Byzantine trust + robust PLS + UAV-IRS WPCN in a single cross-layer DRL framework.

---

# PART II — NOVELTY MATRIX

| Feature | Base (A3/B4) | Paper 2 (B3) | Paper 3 (F2) | Paper 4 (G1) | F1 | H2 | I1 | **OURS** |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| UAV | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ | ✅ | ✅ |
| IRS/RIS | ✅ | ✅ (STAR) | ✅ | ❌ | ✅ | ✅ | ❌ | ✅ |
| FL (as application) | ✅ | ✅ (AirFL) | ❌ (FL trains DRL) | ✅ | ✅ | ❌ | ✅ | ✅ |
| Wireless Power (WPCN) | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| DRL control | ❌ | ✅ (SAC+DDQN) | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ |
| FL-aware state/reward | ❌ | ❌ (client count) | ❌ | ❌ | ❌ | ❌ | ✅ (loss) | ✅ (loss+trust) |
| PLS (any) | ❌ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | ✅ |
| Imperfect Eve CSI | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ (partial) | ❌ | ✅ |
| Robust worst-case secrecy | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ (reward) | ❌ | ✅ (hard constraint) |
| Byzantine FL | ❌ | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ | ✅ |
| Trust/reputation | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| Cross-layer FL↔wireless | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | partial | ✅ |
| Hard secrecy constraint | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ (micro-layer) |
| Model-based micro-layer | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |

---

# PART III — 5 CLOSEST COMPETITORS

## Competitor 1: Base Paper (Li et al., Physical Communication, 2024)

**System:** UAV + IRS + WPCN + FL.
**Method:** BCD/SCA/AO static optimization.
**Missing:** DRL, security, imperfect CSI, Byzantine, sequential control, cross-layer coupling.
**Minimum difference from ours:** 6 components (DRL, PLS, imperfect CSI, robust secrecy, Byzantine, cross-layer).

## Competitor 2: STAR-RIS AirFL with DRL (Wu et al., 2024)

**System:** STAR-RIS + UAV + AirFL + DRL (SAC+DDQN).
**Method:** Dual-network hierarchical DRL; maximize client participation under aggregation error.
**Missing:** WPCN, security, imperfect CSI, robust secrecy, Byzantine, trust, FL-progress-aware state, model-based micro-layer, hard physical constraints.
**Minimum difference from ours:** 8 components. This paper is the closest DRL+IRS+UAV+FL competitor but is missing ALL security and Byzantine dimensions.

## Competitor 3: Byzantine AirFL with UAV (Fan et al., 2024)

**System:** UAV + AirFL + Byzantine attacks.
**Method:** Robust aggregation + power control; convergence analysis.
**Missing:** IRS, WPCN, DRL, PLS, imperfect CSI, trust-based scheduling, cross-layer FL-wireless coupling.
**Minimum difference from ours:** 7 components.

## Competitor 4: IRS-assisted PLS for FL (TVT, 2024)

**System:** IRS + FL + PLS (secrecy rate).
**Method:** AO/SCA for IRS phase + beamforming.
**Missing:** UAV, WPCN, DRL, imperfect CSI, robust secrecy, Byzantine, trust, cross-layer, hard secrecy.
**Minimum difference from ours:** 8 components.

## Competitor 5: DRL Robust Secure Beamforming with Imperfect CSI (TVT, 2024)

**System:** IRS + PLS + imperfect CSI + DRL.
**Method:** DDPG/SAC; security as reward penalty.
**Missing:** UAV, WPCN, FL, Byzantine, trust, FL-aware state, hard secrecy constraint, model-based micro-layer.
**Minimum difference from ours:** 7 components. Critically: security is a reward penalty, not a hard constraint.

---

# PART IV — NOVELTY CLAIM AUDIT

## Claim A: "First DRL-based UAV-IRS FL system"

**Verdict: 🔴 RED — ALREADY DONE.** Paper 2 (Wu et al., 2024) combines DRL + UAV + IRS/RIS + FL. We CANNOT claim this.

## Claim B: "First secure DRL-based UAV-IRS FL system"

**Verdict: 🟡 YELLOW — CLOSE BUT DIFFERENTIABLE.** No paper combines DRL + UAV + IRS + FL + PLS specifically. However, IRS+PLS+FL exists (F1, without DRL/UAV), and DRL+IRS+PLS exists (H2, without FL/UAV). The combination is novel but the claim is incremental.

## Claim C: "First robust imperfect-CSI secrecy-constrained DRL framework for UAV-IRS FL"

**Verdict: 🟢 GREEN — DEFENSIBLE.** No paper found combines:
- robust worst-case secrecy (not reward-based, but hard constraint)
- imperfect Eve CSI
- DRL
- UAV-IRS
- FL
The critical differentiator is **hard secrecy constraint via micro-layer** versus **reward-based security penalty** in all existing DRL papers.

## Claim D: "First Byzantine-aware DRL-controlled UAV-IRS FL framework"

**Verdict: 🟢 GREEN — DEFENSIBLE.** No paper found combines Byzantine FL + DRL + UAV + IRS. Byzantine FL + UAV exists (G1) but without DRL or IRS. DRL + FL + UAV exists (E4, I1) but without Byzantine.

## Claim E: "First cross-layer framework jointly coupling FL progress, Byzantine trust, UAV mobility, IRS-WPCN, and robust PLS"

**Verdict: 🟢 GREEN — STRONGLY DEFENSIBLE.** This is the most specific and defensible claim. No single paper or even pair of papers covers all these coupled dimensions. The cross-layer coupling (FL progress and Byzantine trust feed back into UAV/scheduling decisions, with hard physical-layer secrecy constraints enforced by a model-based micro-layer) is genuinely novel.

---

# PART V — NOVELTY TYPE DECOMPOSITION

| Novelty Type | Assessment | Strength |
|---|---|---|
| **Algorithmic** | We do NOT propose a new DRL algorithm. | ❌ None |
| **System combination** | The specific combination (UAV+IRS+WPCN+FL+robust PLS+Byzantine+trust+DRL) is new. | 🟡 Moderate (risk: "kitchen sink" criticism) |
| **Problem formulation** | The sequential constrained control problem $\mathcal{P}_{\text{ctrl}}$ with model-based micro-layer is not found in literature. | 🟢 Strong |
| **Security** | Hard robust secrecy constraint (not reward) + imperfect CSI in DRL-controlled FL system. | 🟢 Strong |
| **Cross-layer** | FL progress + Byzantine trust → DRL → UAV/scheduling → physical feasibility → FL update loop. | 🟢 Strong |
| **Methodological** | Two-timescale: DRL macro + model-based physical micro-layer (not all-DRL). | 🟢 Strong |
| **Experimental** | Testing Byzantine + robust secrecy + FL convergence simultaneously. | 🟡 Moderate |

---

# PART VI — PHYSICAL-RECOURSE ARCHITECTURE AUDIT

The two-timescale "DRL macro + optimization micro" architecture is:
- **Known in general wireless:** Two-timescale DRL for resource allocation exists (D4, I3, O-RAN papers).
- **Known for IRS:** Bilevel POMDP for IRS (Zhang et al., TWC 2024).
- **NOT known for this specific system:** No paper applies this architecture to UAV-IRS-WPCN-FL with hard robust secrecy + Byzantine trust.

The model-based micro-layer enforcing hard constraints is known in wireless (embedded optimization, projection layers). But using it specifically to enforce **robust worst-case secrecy** while DRL handles sequential FL-aware decisions is **not found** in the literature.

**Verdict:** The architecture is not fundamentally novel, but its application to this specific cross-layer problem IS novel.

---

# PART VII — SECURITY AUDIT

| Security Feature | F1 | F3 | F4 | H1 | H2 | **OURS** |
|---|:---:|:---:|:---:|:---:|:---:|:---:|
| Secrecy rate | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Worst-case secrecy | ❌ | ✅ | ✅ | ❌ | ❌ | ✅ |
| Bounded CSI uncertainty | ❌ | ✅ | ✅ | ❌ | ✅ | ✅ |
| IRS→Eve link | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Direct User→Eve link | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ |
| Joint direct+reflected Eve | ❌ | ✅ | ✅ | ❌ | ❌ | ✅ |
| Hard secrecy constraint | ❌ | ✅ | ✅ | ❌ | ❌ (reward) | ✅ |
| DRL-controlled | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ |
| FL context | ✅ | ❌ | ❌ | ❌ | ❌ | ✅ |
| WPCN context | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |

**Critical differentiator:** Existing DRL+security papers (H1, H2) use security as a **reward penalty**. Our formulation enforces robust worst-case secrecy as a **hard constraint in the micro-layer**. This is a genuine methodological difference, not just a system combination.

---

# PART VIII — BYZANTINE/TRUST AUDIT

Trust-based client selection ($\mathcal{S}_t^{\text{cand}} = \{k : \rho_{k,t-1} \ge \eta_t\}$) is:

- **Known in FL:** Trust/reputation for FL exists (G2, G3, G4).
- **Known with RL:** RL-based Byzantine-aware selection exists (G3, G4).
- **NOT known with UAV-IRS-WPCN-PLS:** No paper combines trust-based scheduling with UAV, IRS, WPCN, and PLS.

The **coupling** between trust threshold ($\eta_t$ as DRL action) and physical feasibility (through $\mathcal{S}_t^{\text{cand}}$ → micro-layer) is novel.

**Verdict:** The trust mechanism itself is not novel. Its integration into the cross-layer DRL framework with physical-layer consequences IS novel.

---

# PART IX — DRL CONVERGENCE CLAIM AUDIT

| Paper | Convergence Claim | Type |
|---|---|---|
| Paper 2 (B3) | "Reward convergence shown in training curves" | Empirical only |
| H1 | "DDPG training converges" | Empirical only |
| H2 | "DRL policy performance stabilizes" | Empirical only |
| D4 | "Bilevel DRL converges" | Empirical + partial theory (two-timescale stochastic approximation) |
| E2 | "RL-controlled FL converges" | FL convergence bound, not RL optimality |

**UNIVERSAL FINDING:** No DRL paper in this domain proves global policy optimality. All use empirical convergence (training reward stabilization).

**Safe language for our manuscript:**
- ✅ "trained policy"
- ✅ "learned policy"
- ✅ "empirically converged training reward"
- ✅ "policy obtained via DRL training"
- ✅ "the DRL agent learns to improve FL progress over training episodes"
- ❌ "optimal policy"
- ❌ "DRL converges to the optimal solution"
- ❌ "provably convergent DRL"
- ❌ "guaranteed convergence"

---

# PART X — REVIEWER FORENSICS

| Previous Reviewer Concern | Does DRL Eliminate It? | Does DRL Merely Relocate It? | What Must Be Done? |
|---|---|---|---|
| Outer-loop AO monotonicity | ✅ Eliminated (no AO outer loop) | — | DRL replaces AO; no monotonicity claim needed |
| Stationarity of original optimization | ✅ Eliminated (no stationarity claim) | — | We claim "trained policy," not "stationary point" |
| True secrecy constraint enforcement | ✅ Preserved | — | Hard C9 in micro-layer; same as Stage 1 |
| Solver convergence | ⚠️ Partially relocated | Yes: from "BCD convergence" to "DRL training convergence" | We make NO solver convergence claim; micro-layer is a numerical search |
| Feasibility | ✅ Improved | — | Three-outcome distinction (success/structural infeasibility/solver failure) |
| Stochastic policy training | — | Yes: new vulnerability | Must report: training curves, multiple seeds, hyperparameter sensitivity |
| Reproducibility | — | Yes: new vulnerability | Must provide: code, seeds, training logs, hyperparameters |
| Hyperparameter sensitivity | — | Yes: new vulnerability | Must run sensitivity analysis on $\delta_{\max}$, $\gamma$, learning rates |
| Random seed dependence | — | Yes: new vulnerability | Must report: mean ± std over ≥5 seeds |

**NET ASSESSMENT:** The DRL direction genuinely eliminates the AO convergence vulnerabilities (Reviewer 2/3 primary concerns) but introduces new empirical vulnerabilities. These are **standard** in the DRL literature and manageable through proper experimental methodology.

---

# PART XI — NOVELTY RED FLAGS

## Claims We MUST NOT Make

1. ❌ "First DRL + IRS" — already published.
2. ❌ "First DRL + UAV + FL" — already published.
3. ❌ "DRL convergence guaranteed" — no theorem exists.
4. ❌ "Optimal policy" — DRL finds a trained policy, not an optimal one.
5. ❌ "Secure" if security is merely a reward penalty — our architecture uses hard constraints, so we CAN say "secure" but must be precise.
6. ❌ "Novel DRL algorithm" — we use an existing DRL algorithm.
7. ❌ "Byzantine-proof" — robust aggregation has breakdown points; we should say "Byzantine-resilient."
8. ❌ "Jointly optimal" — the two-timescale architecture does not guarantee joint optimality.
9. ❌ "First IRS + FL" — already published.
10. ❌ "First UAV + FL + Byzantine" — already published (Paper 4).

---

# PART XII — TRUE RESEARCH GAP

### What Is Already Known
- DRL for UAV trajectory + IRS phase + FL scheduling (separately and in some combinations).
- Robust PLS with IRS under imperfect CSI (via AO/SCA, not DRL).
- Byzantine-resilient FL with trust/reputation (without UAV-IRS-WPCN physical layer).
- Two-timescale DRL with embedded optimization for wireless (in non-FL, non-security contexts).

### What Is Close but Incomplete
- DRL+IRS+UAV+FL exists but without security, Byzantine, or WPCN.
- DRL+IRS+security exists but without FL, Byzantine, or WPCN, and uses reward-based (not hard) secrecy.
- Byzantine FL + UAV exists but without IRS, WPCN, DRL, or PLS.

### What Is Genuinely Missing

$$\boxed{\text{A cross-layer DRL framework that simultaneously:}}$$

1. Makes sequential UAV mobility + Byzantine-aware scheduling decisions based on FL learning progress and trust;
2. Delegates instantaneous IRS/WPCN/resource optimization to a model-based physical-layer solver;
3. Enforces robust worst-case secrecy as a **hard constraint** (not a reward penalty) under imperfect Eve CSI;
4. Operates over a WPCN with per-round energy neutrality;
5. Handles Byzantine clients through trust-threshold-based participation control.

**This gap is at the intersection of problem formulation, security methodology, and cross-layer architecture — not in a new DRL algorithm.**

---

# PART XIII — THREE NOVELTY POSITIONS

## Position A: Cross-Layer Learning-Security-Trust Architecture

**Claim:** First framework to jointly couple FL learning progress, Byzantine trust dynamics, UAV mobility, IRS-assisted WPCN, and robust physical-layer secrecy in a sequential DRL-controlled system.

- **Strength:** 🟢 Strong. No single paper covers this coupling.
- **Closest competitor:** Paper 2 (lacks security, Byzantine, WPCN) + Paper 4 (lacks IRS, DRL, security).
- **Risk:** "Kitchen sink" criticism — too many components without deep algorithmic contribution.
- **Mitigation:** Emphasize the cross-layer coupling as the contribution, not the component count. Show that removing any one component changes the solution structure qualitatively.
- **Required experiments:** Ablation study removing each component; show FL convergence degrades or security fails.
- **Safe claims:** "Trained policy achieves superior FL convergence under Byzantine attacks and eavesdropping compared to baselines."

## Position B: Hard-Constraint Robust Secrecy in DRL-Controlled FL

**Claim:** First DRL framework where robust worst-case physical-layer secrecy is enforced as a hard constraint (via model-based micro-layer) rather than as a reward penalty, in a wireless-powered FL system.

- **Strength:** 🟢 Strong. All existing DRL+security papers use reward penalties. Our micro-layer guarantees C9.
- **Closest competitor:** H2 (DRL+IRS+imperfect CSI, but reward-based security).
- **Risk:** Reviewer asks "why not just use reward penalty?" Must demonstrate that reward-penalty approaches violate secrecy constraints in practice.
- **Required experiments:** Compare hard-constraint vs. reward-penalty approaches; show reward-penalty violates secrecy in some rounds.
- **Safe claims:** "The proposed framework guarantees worst-case physical-layer secrecy in every successfully served round."

## Position C: Two-Timescale DRL + Model-Based Physical Recourse for Secure WPCN-FL

**Claim:** First hybrid DRL architecture separating sequential cross-layer decisions (macro) from instantaneous physical-layer optimization (micro) for a secure, Byzantine-aware, wireless-powered FL system.

- **Strength:** 🟢 Strong methodologically. Two-timescale DRL exists but not applied to this problem class.
- **Closest competitor:** D4 (bilevel DRL for IRS, but no FL, no security, no WPCN).
- **Risk:** Architecture is a natural engineering design, not a deep theoretical contribution.
- **Mitigation:** Show that all-DRL baselines (where DRL also controls IRS phases/resources) perform worse due to constraint violations.
- **Required experiments:** All-DRL baseline vs. hybrid DRL+model-based baseline; show constraint violation rates.
- **Safe claims:** "The hybrid architecture achieves hard physical-layer constraint satisfaction while maintaining DRL adaptivity."

**Recommended strategy: Combine Positions A+B+C.** The cross-layer architecture (A) is the system contribution; the hard-constraint secrecy (B) is the security contribution; the hybrid two-timescale methodology (C) is the methodological contribution.

---

# PART XIV — BIBLIOGRAPHY

```bibtex
@article{li2024irs,
  title={IRS-assisted UAV wireless powered communication network for sustainable federated learning},
  author={Li, Ruijie and Zhang, Guoping and Chen, Yun},
  journal={Physical Communication},
  volume={67},
  pages={102504},
  year={2024},
  publisher={Elsevier}
}

@article{wu2024drl_starris_airfl,
  title={DRL-Based Joint Beamforming and UAV Deployment Optimization for STAR-RIS-Assisted Over-the-Air Federated Learning},
  author={Wu, Yun and Sun, Yitong and Hai, Han and Bai, Enjian and Yang, Yunlong},
  journal={IEEE},
  year={2024}
}

@article{fan2024uav_byzantine_airfl,
  title={UAV-Assisted Heterogeneous Federated Learning over the Air Against Byzantine Attacks},
  author={Fan, Xin and Li, Guangkai and Luo, Chuanwen and Hong, Yi and Chen, Zhibo and Chen, Ting},
  journal={SciOpen/IEEE},
  year={2024}
}

@article{banothu2024fdrl_secure_irs_thz,
  title={Federated Deep Reinforcement Learning for Secure and Energy-Efficient IRS-Assisted THz-NOMA Networks},
  author={Banothu, Gandhi and Bhar, Chayan},
  year={2024}
}

@article{zhang2024bilevel_drl_irs,
  title={How Often Channel Estimation is Required for Adaptive IRS Beamforming: A Bilevel Deep Reinforcement Learning Approach},
  author={Zhang, J. and others},
  journal={IEEE Transactions on Wireless Communications},
  year={2024}
}

@article{blanchard2017krum,
  title={Machine learning with adversaries: Byzantine tolerant gradient descent},
  author={Blanchard, Peva and El Mhamdi, El Mahdi and Guerraoui, Rachid and Stainer, Julien},
  booktitle={NeurIPS},
  year={2017}
}

@article{yin2018trimmedmean,
  title={Byzantine-robust distributed learning: Towards optimal statistical rates},
  author={Yin, Dong and Chen, Yudong and Kannan, Ramchandran and Bartlett, Peter},
  booktitle={ICML},
  year={2018}
}

@book{altman1999cmdp,
  title={Constrained Markov Decision Processes},
  author={Altman, Eitan},
  year={1999},
  publisher={Chapman and Hall/CRC}
}
```

