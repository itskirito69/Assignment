# Stage 3A — Novelty Gap Analysis

*Extracted from Stage_3A_Literature_Audit.md, PARTS XI–XIII*

---

# PART XI — NOVELTY RED FLAGS

## Claims We MUST NOT Make

1. ❌ "First DRL + IRS" — already published.
2. ❌ "First DRL + UAV + FL" — already published.
3. ❌ "DRL convergence guaranteed" — no theorem exists.
4. ❌ "Optimal policy" — DRL finds a trained policy, not an optimal one.
5. ❌ "Secure" if security is merely a reward penalty — our architecture uses hard constraints, so we CAN say "secure" but must be precise.
6. ❌ "Novel DRL algorithm" — we use an existing DRL algorithm.
7. ❌ "Byzantine-proof" — robust aggregation has breakdown points; we should say "Byzantine-resilient."
8. ❌ "Jointly optimal" — the two-timescale architecture does not guarantee joint optimality.
9. ❌ "First IRS + FL" — already published.
10. ❌ "First UAV + FL + Byzantine" — already published (Paper 4).

---

# PART XII — TRUE RESEARCH GAP

### What Is Already Known
- DRL for UAV trajectory + IRS phase + FL scheduling (separately and in some combinations).
- Robust PLS with IRS under imperfect CSI (via AO/SCA, not DRL).
- Byzantine-resilient FL with trust/reputation (without UAV-IRS-WPCN physical layer).
- Two-timescale DRL with embedded optimization for wireless (in non-FL, non-security contexts).

### What Is Close but Incomplete
- DRL+IRS+UAV+FL exists but without security, Byzantine, or WPCN.
- DRL+IRS+security exists but without FL, Byzantine, or WPCN, and uses reward-based (not hard) secrecy.
- Byzantine FL + UAV exists but without IRS, WPCN, DRL, or PLS.

### What Is Genuinely Missing

$$\boxed{\text{A cross-layer DRL framework that simultaneously:}}$$

1. Makes sequential UAV mobility + Byzantine-aware scheduling decisions based on FL learning progress and trust;
2. Delegates instantaneous IRS/WPCN/resource optimization to a model-based physical-layer solver;
3. Enforces robust worst-case secrecy as a **hard constraint** (not a reward penalty) under imperfect Eve CSI;
4. Operates over a WPCN with per-round energy neutrality;
5. Handles Byzantine clients through trust-threshold-based participation control.

**This gap is at the intersection of problem formulation, security methodology, and cross-layer architecture — not in a new DRL algorithm.**

---

# PART XIII — THREE NOVELTY POSITIONS

## Position A: Cross-Layer Learning-Security-Trust Architecture

**Claim:** First framework to jointly couple FL learning progress, Byzantine trust dynamics, UAV mobility, IRS-assisted WPCN, and robust physical-layer secrecy in a sequential DRL-controlled system.

- **Strength:** 🟢 Strong. No single paper covers this coupling.
- **Closest competitor:** Paper 2 (lacks security, Byzantine, WPCN) + Paper 4 (lacks IRS, DRL, security).
- **Risk:** "Kitchen sink" criticism — too many components without deep algorithmic contribution.
- **Mitigation:** Emphasize the cross-layer coupling as the contribution, not the component count. Show that removing any one component changes the solution structure qualitatively.
- **Required experiments:** Ablation study removing each component; show FL convergence degrades or security fails.
- **Safe claims:** "Trained policy achieves superior FL convergence under Byzantine attacks and eavesdropping compared to baselines."

## Position B: Hard-Constraint Robust Secrecy in DRL-Controlled FL

**Claim:** First DRL framework where robust worst-case physical-layer secrecy is enforced as a hard constraint (via model-based micro-layer) rather than as a reward penalty, in a wireless-powered FL system.

- **Strength:** 🟢 Strong. All existing DRL+security papers use reward penalties. Our micro-layer guarantees C9.
- **Closest competitor:** H2 (DRL+IRS+imperfect CSI, but reward-based security).
- **Risk:** Reviewer asks "why not just use reward penalty?" Must demonstrate that reward-penalty approaches violate secrecy constraints in practice.
- **Required experiments:** Compare hard-constraint vs. reward-penalty approaches; show reward-penalty violates secrecy in some rounds.
- **Safe claims:** "The proposed framework guarantees worst-case physical-layer secrecy in every successfully served round."

## Position C: Two-Timescale DRL + Model-Based Physical Recourse for Secure WPCN-FL

**Claim:** First hybrid DRL architecture separating sequential cross-layer decisions (macro) from instantaneous physical-layer optimization (micro) for a secure, Byzantine-aware, wireless-powered FL system.

- **Strength:** 🟢 Strong methodologically. Two-timescale DRL exists but not applied to this problem class.
- **Closest competitor:** D4 (bilevel DRL for IRS, but no FL, no security, no WPCN).
- **Risk:** Architecture is a natural engineering design, not a deep theoretical contribution.
- **Mitigation:** Show that all-DRL baselines (where DRL also controls IRS phases/resources) perform worse due to constraint violations.
- **Required experiments:** All-DRL baseline vs. hybrid DRL+model-based baseline; show constraint violation rates.
- **Safe claims:** "The hybrid architecture achieves hard physical-layer constraint satisfaction while maintaining DRL adaptivity."

**Recommended strategy: Combine Positions A+B+C.** The cross-layer architecture (A) is the system contribution; the hard-constraint secrecy (B) is the security contribution; the hybrid two-timescale methodology (C) is the methodological contribution.

