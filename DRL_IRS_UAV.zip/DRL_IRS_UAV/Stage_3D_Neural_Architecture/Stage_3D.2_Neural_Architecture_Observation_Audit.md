# Stage 3D.2 — Neural Network Architecture & Observation Interface Audit

## Representation Engineering, Information Flow, and Neural Architecture Class Specification for the SAC Macro-Controller

---

# EXECUTIVE SUMMARY

This report audits and freezes the **observation representation, information flow, and neural network architecture class** for the primary Soft Actor-Critic (SAC) macro-controller governing:
$$a_t = (\Delta x_t, \Delta y_t, \eta_t) \in \mathcal{A} = [-\delta_{\max}, \delta_{\max}]^2 \times [0, 1]$$

In accordance with the Stage 3D roadmap:
1. We preserve the frozen Stage 2D Markov state $X_t^-$ and observation mapping $o_t = \psi(X_t^-)$.
2. We perform a component-by-component hostile audit of the 7 observation dimensions.
3. We establish the exact mathematical structure of the FL model summary $\phi(w_{t-1})$, eliminating future information leakage while providing temporal momentum.
4. We resolve the client representation trade-off: in a fixed-geometry wireless deployment where user indices correspond to physical spatial coordinates $r_k$, ordered concatenation is mathematically justified and sample-efficient, while permutation-invariant set-encoding is evaluated.
5. We resolve the POMDP temporal memory challenge: because the state already contains natural history accumulators ($E_{\text{rem},t-1}$, $n_{\text{out},t-1}$) and exponential moving average filters ($\{\rho_{k,t-1}\}$), an **MLP with Feature-Augmented Temporal Differences** is selected as the primary architecture class. Finite-history frame stacking is designated as the secondary ablation baseline, while recurrent architectures (LSTM/GRU) are rejected due to replay buffer staleness and sample inefficiency.
6. Hyperparameters (layer counts, neuron counts, learning rates) remain strictly deferred to Stage 3D.4.

---

# SECTION A — INHERITED FROZEN STATE AND OBSERVATION

From Stage 2D, Stage 3B.1, and Stage 3D.1, the mathematical baseline is:

1. **Pre-Action Markov State $X_t^-$:**
   $$X_t^- = \bigl(r_{t-1},\; w_{t-1},\; \{\rho_{k,t-1}\}_{k=1}^K,\; \bar{h}_{t-1},\; n_{\text{out},t-1},\; E_{\text{rem},t-1},\; t\bigr)$$
   - $r_{t-1} \in \mathbb{R}^2$: horizontal UAV position at the end of round $t-1$.
   - $w_{t-1} \in \mathbb{R}^d$: global FL model parameter vector.
   - $\{\rho_{k,t-1}\}_{k=1}^K \in [0, 1]^K$: per-client reputation/trust scores.
   - $\bar{h}_{t-1} \in \mathbb{R}_+^K$: effective legitimate channel gains from round $t-1$.
   - $n_{\text{out},t-1} \in \{0, \dots, T_{\max}\}$: cumulative service failure / outage count.
   - $E_{\text{rem},t-1} \in [0, E_{\text{budget}}]$: remaining WPT energy budget ($E_{\text{rem},t-1} = E_{\text{budget}} - E_{\text{cum},t-1}$).
   - $t \in \{1, \dots, T_{\max}\}$: current round index.

2. **Raw Operational Observation $o_t$:**
   $$o_t = \psi(X_t^-) = \bigl(r_{t-1},\; \phi(w_{t-1}),\; \{\rho_{k,t-1}\}_{k=1}^K,\; \bar{h}_{t-1},\; n_{\text{out},t-1},\; E_{\text{rem},t-1},\; t\bigr)$$
   where $\psi$ applies the lossy compression $w_{t-1} \mapsto \phi(w_{t-1}) \in \mathbb{R}^{d_\phi}$ ($d_\phi \ll d$).

3. **Macro Action $a_t$:**
   $$a_t = (\Delta x_t, \Delta y_t, \eta_t) \in [-\delta_{\max}, \delta_{\max}]^2 \times [0, 1]$$

---

# SECTION B — COMPONENT-BY-COMPONENT OBSERVATION SUFFICIENCY AUDIT

We subject every constituent of $o_t$ to hostile scrutiny across 7 fundamental criteria:
1. Why is it required?
2. What control-relevant information does it contain?
3. Is it observable at decision time $t$?
4. Is it redundant?
5. Does it leak future information?
6. Does removing it create state aliasing?
7. How does it scale with $K$?

---

### 1. UAV Position ($r_{t-1} \in \mathbb{R}^2$)
- **Requirement:** Core kinematic state variable.
- **Control Information:** Determines the spatial origin for displacement $(\Delta x_t, \Delta y_t)$. Directly governs distance to legitimate users $d_{UA,k}(r_t)$, distance to IRS $d_{IA}(r_t)$, and distance to Eve $d_{UE}(r_t)$, establishing large-scale path loss.
- **Observability:** Exactly known via onboard GPS/INS at round start $t$.
- **Redundancy:** Non-redundant. No other variable encodes UAV coordinates.
- **Future Leakage:** 🟢 Zero. Determined at round $t-1$.
- **State Aliasing:** Severe aliasing if removed (the policy cannot know if moving $+10\text{ m}$ stays in coverage or flies out of bounds).
- **Scalability:** $\mathcal{O}(1)$ (fixed 2D vector).

---

### 2. FL Model Summary ($\phi(w_{t-1}) \in \mathbb{R}^{d_\phi}$)
- **Requirement:** Informs the controller of the global learning status.
- **Control Information:** Encodes loss level, convergence progress, and model update trajectory. Informs whether aggressive training is still yielding gains or whether the model is saturated/poisoned.
- **Observability:** Evaluated on the server after round $t-1$ aggregation.
- **Redundancy:** Non-redundant.
- **Future Leakage:** 🟢 Zero. Evaluated strictly on $w_{t-1}$.
- **State Aliasing:** Without model feedback, the policy cannot distinguish whether an aggressive action successfully improved the FL model or caused training divergence.
- **Scalability:** $\mathcal{O}(d_\phi)$ (fixed compact dimension, invariant to $K$ and model size $d$).

---

### 3. Client Reputation Scores ($\{\rho_{k,t-1}\}_{k=1}^K \in [0, 1]^K$)
- **Requirement:** Direct input for Byzantine-aware client admission.
- **Control Information:** Each $\rho_{k,t-1}$ is an exponential moving average of past verification diagnostics:
  $$\rho_{k,t-1} = \beta_\rho \rho_{k,t-2} + (1 - \beta_\rho) \sigma_{k,t-1}$$
  Indicates the statistical trustworthiness of client $k$. Directly dictates the effect of choosing threshold $\eta_t$, as $\mathcal{S}_t^{\text{cand}} = \{k : \rho_{k,t-1} \ge \eta_t\}$.
- **Observability:** Computed at the UAV server during round $t-1$ aggregation diagnostics.
- **Redundancy:** Non-redundant.
- **Future Leakage:** 🟢 Zero. Incorporates diagnostics strictly up to round $t-1$.
- **State Aliasing:** If removed, the policy has zero visibility into client trustworthiness and cannot set an informed $\eta_t$.
- **Scalability:** $\mathcal{O}(K)$ (scales linearly with number of clients).

---

### 4. Legitimate Channel Summary ($\bar{h}_{t-1} \in \mathbb{R}_+^K$)
- **Requirement:** Historical channel quality indicator.
- **Control Information:** Stores the composite channel gains $|h_k(r_{t-1}, v_{t-1}; \xi_{t-1})|^2$ from the previous round (or carried forward on outage).
- **Observability:** Recorded at the end of round $t-1$ if feasible.
- **Redundancy:** Under pure i.i.d. block fading, the small-scale fading component of $\xi_t$ is independent of $\xi_{t-1}$. However, $\bar{h}_{t-1}$ provides an empirical proxy for the combined path loss and IRS reflective alignment achieved at $r_{t-1}$.
- **Future Leakage:** 🟢 Zero. Fading realization $\xi_t$ for round $t$ is NOT leaked.
- **State Aliasing:** Minor aliasing if removed under i.i.d. fading; significant aliasing if temporal fading correlation exists.
- **Scalability:** $\mathcal{O}(K)$ (linear with $K$).

---

### 5. Cumulative Outage Count ($n_{\text{out},t-1} \in \mathbb{N}$)
- **Requirement:** Tracking progress against the long-term outage constraint $G_2(\pi) \le \epsilon_{\text{out}}$.
- **Control Information:** $n_{\text{out},t-1} = \sum_{\tau=1}^{t-1} (1 - \text{feas}_\tau)$. Together with current round index $t$, it defines the observed historical outage frequency $n_{\text{out},t-1} / (t - 1)$ and remaining allowed outages:
  $$n_{\text{out}}^{\text{allowed}}(t) = \lfloor T_{\max} \epsilon_{\text{out}} \rfloor - n_{\text{out},t-1}$$
- **Observability:** Exact integer counter on server.
- **Redundancy:** Non-redundant.
- **Future Leakage:** 🟢 Zero.
- **State Aliasing:** Severe constraint aliasing if removed: without it, a policy cannot adjust its risk posture when it has exhausted its allowed outage budget.
- **Scalability:** $\mathcal{O}(1)$ (scalar integer).

---

### 6. Remaining WPT Energy Budget ($E_{\text{rem},t-1} \in \mathbb{R}_+$)
- **Requirement:** Tracking progress against the long-term energy budget $G_1(\pi) \le E_{\text{budget}}$.
- **Control Information:** $E_{\text{rem},t-1} = E_{\text{budget}} - \sum_{\tau=1}^{t-1} E_{\text{WPT},\tau} \mathbb{1}[\text{feas}_\tau = 1]$. Informs the agent how much WPT energy remains over the remaining $T_{\max} - t + 1$ rounds.
- **Observability:** Exact cumulative subtraction from UAV battery records.
- **Redundancy:** Non-redundant.
- **Future Leakage:** 🟢 Zero.
- **State Aliasing:** Severe budget-blindness if removed (proven in Stage 3B/3B.1).
- **Scalability:** $\mathcal{O}(1)$ (scalar float).

---

### 7. Current Round Index ($t \in \{1, \dots, T_{\max}\}$)
- **Requirement:** Temporal clock for finite-horizon non-stationary control.
- **Control Information:** Informs the policy of remaining rounds $T_{\max} - t + 1$. Essential for finite-horizon budget allocation (e.g., spending remaining energy aggressively near $t \to T_{\max}$).
- **Observability:** System clock.
- **Redundancy:** Non-redundant.
- **Future Leakage:** 🟢 Zero.
- **State Aliasing:** Severe aliasing: stationary policies cannot adapt to finite-horizon depletion without time.
- **Scalability:** $\mathcal{O}(1)$ (scalar integer).

---

# SECTION C — FL MODEL SUMMARY SPECIFICATION ($\phi(w_{t-1})$)

The raw global FL model $w_{t-1} \in \mathbb{R}^d$ ($d \sim 10^4 - 10^7$) cannot be fed into a reinforcement learning critic/actor without causing catastrophic parameter explosion and training instability.

### 1. Audit of Candidate Summary Features

| Candidate Feature | Description | Observability & Timing | Future Leakage? | Control Relevance | Recommendation |
|---|---|:---:|:---:|---|:---:|
| **Global Validation Loss $\mathcal{L}(w_{t-1})$** | Loss on server proxy validation set | Evaluated at round $t-1$ | 🟢 None | Indicates absolute global convergence level. | **MANDATORY** |
| **Loss Velocity $\Delta \mathcal{L}_{t-1} = \mathcal{L}(w_{t-2}) - \mathcal{L}(w_{t-1})$** | 1-step historical loss drop | Known at round $t-1$ | 🟢 None | Measures instantaneous convergence momentum / degradation. | **MANDATORY** |
| **Model Update Norm $\|\Delta w_{t-1}\|_2$** | $\|w_{t-1} - w_{t-2}\|_2$ | Computed after aggregation | 🟢 None | Measures step magnitude; detects gradient explosion or freeze. | **MANDATORY** |
| **Global Gradient Norm $\|\nabla \mathcal{L}(w_{t-1})\|_2$** | Norm of gradient on server data | Requires backward pass | 🟢 None | Redundant with $\|\Delta w_{t-1}\|_2$; adds server compute. | *EXCLUDED* |
| **Validation Accuracy $\text{Acc}(w_{t-1})$** | Top-1 accuracy percentage | Evaluated on validation set | 🟢 None | Discontinuous step changes; less informative than loss. | *OPTIONAL AUX* |
| **Candidate Client Losses $\{\mathcal{L}_k(w_{t-1})\}$** | Local losses reported by clients | Requires uplink communication | ❌ Leakage/Cost | Unreliable: Byzantine clients report fake low losses. | **PROHIBITED** |

### 2. Frozen Mathematical Specification of $\phi(w_{t-1})$
We define the FL model representation vector as a compact 3-dimensional tuple:
$$\boxed{\phi(w_{t-1}) = \begin{bmatrix} \mathcal{L}(w_{t-1}) \\ \Delta \mathcal{L}_{t-1} \\ \|\Delta w_{t-1}\|_2 \end{bmatrix} \in \mathbb{R}^3}$$
with $\Delta \mathcal{L}_{t-1} = \mathcal{L}(w_{t-2}) - \mathcal{L}(w_{t-1})$ and $\|\Delta w_{t-1}\|_2 = \|w_{t-1} - w_{t-2}\|_2$ (initialized to zero for $t=1$).
- **Scientific Justification:** This triplet provides the three canonical quantities of optimization trajectory tracking: **position** ($\mathcal{L}$), **velocity** ($\Delta \mathcal{L}$), and **displacement magnitude** ($\|\Delta w\|_2$). It is computationally trivial, resistant to raw Byzantine spoofing (evaluated on server validation data), and strictly causal.

---

# SECTION D — CLIENT-LEVEL REPRESENTATION & PERMUTATION INVARIANCE

The observation contains $K$ client reputations $\{\rho_{k,t-1}\}_{k=1}^K$ and $K$ channel gains $\bar{h}_{t-1}$. How should they be structured for the neural network?

### 1. The Physics of User Heterogeneity
In the base paper and frozen physical model:
- Each user $k \in \{1, \dots, K\}$ resides at a **fixed, distinct physical ground coordinate** $r_k = (x_k, y_k)$.
- IRS is at a fixed location $r_I = (0, 0, H_I)$.
- Eavesdropper is at a fixed location $r_E = (x_E, y_E)$.
- User $k$ has fixed computing attributes (dataset size $D_k$, CPU cycles per bit $C_k$, max frequency $f_k^{\max}$).

**Critical Scientific Deduction:**
Because user indices correspond to fixed spatial coordinates in the physical environment, **the system is NOT permutation invariant under arbitrary relabeling of client indices**. 
- Permuting $\rho_1$ and $\rho_2$ without swapping physical coordinates $r_1$ and $r_2$ corresponds to a completely different physical scenario (e.g., swapping whether the trusted user is close to the IRS or far away).
- User $k$ always refers to the user at location $r_k$.

### 2. Architecture Class Comparison for Client Inputs

| Architecture Option | Representation | Advantages | Disadvantages | Suitability for This System |
|---|---|---|---|:---:|
| **Option A: Direct Ordered Concatenation** | Flat vector: $[\rho_1, \dots, \rho_K, \bar{h}_1, \dots, \bar{h}_K] \in \mathbb{R}^{2K}$ | Preserves fixed spatial identity; maximum sample efficiency; zero overhead; trivial implementation. | Input dimension scales with $K$; fixed $K$ required per trained model. | **STRONG (Primary)** |
| **Option B: Summary Statistics (Mean, Min, Max, Std)** | Aggregates: $[\text{mean}(\rho), \min(\rho), \dots]$ | Dimension independent of $K$. | Destroys spatial correlation: cannot learn which *specific* geographical user is trustworthy. | **REJECTED (Information Loss)** |
| **Option C: Permutation-Invariant Set Encoder (DeepSets / Attention)** | Encodes $z_k = (\rho_k, \bar{h}_k, r_k)$ via MLP $\to$ Pooling $\to$ Dense | Generalizes to arbitrary $K$. | Requires explicit input of $r_k$; significantly higher sample complexity; training instability in DRL. | **SECONDARY (Ablation Baseline)** |

### 3. Client Representation Decision:
- **Primary Framework:** **Direct Ordered Concatenation (Option A)**. For the fixed network topology of $K$ clients, ordered concatenation preserves the spatial-reputation coupling with minimal parameters.
- **Secondary Ablation:** **Set-Based Feature Encoding (Option C)**, retained strictly as an ablation baseline to evaluate whether set-pooling offers generalization benefits across varying user counts.

---

# SECTION E — POMDP / TEMPORAL MEMORY AUDIT

In Stage 3D.1, the observation process $(o_t)$ was classified as a POMDP due to the lossy compression of $w_{t-1}$. We audit the three temporal conditioning paradigms:

### 1. Paradigms Evaluated

```text
Option A: Memoryless MLP
o_t ──► [ Dense Layers ] ──► a_t
- Assumption: o_t contains sufficient instantaneous Markovian information.

Option B: Finite-History Frame Stacking (H frames)
[o_{t-2}, o_{t-1}, o_t] ──► [ Dense Layers ] ──► a_t
- Assumption: Past H frames capture higher-order temporal dynamics.

Option C: Recurrent SAC (LSTM / GRU)
o_t ──► [ RNN Cell ] ──► [ Dense Layers ] ──► a_t
          ▲       │
          └── s_{t-1}
- Assumption: Infinite-horizon latent memory required to track hidden states.
```

### 2. Comprehensive Trade-off Analysis

| Evaluation Criterion | Option A: Memoryless MLP (with $\Delta \mathcal{L}$) | Option B: Frame Stacking ($H=3$) | Option C: Recurrent SAC (LSTM/GRU) |
|---|:---:|:---:|:---:|
| **Handling Partial Observability** | **Strong:** $\phi(w_{t-1})$ includes velocity $\Delta \mathcal{L}$ and norm; $\{\rho_{k}\}$ has EMA memory; $E_{\text{rem}}, n_{\text{out}}$ are exact accumulators. | **Strong:** Explicitly tracks $H$ consecutive observations. | **Theoretical:** Infinite latent memory, but in practice suffers from vanishing gradients. |
| **Replay Buffer Compatibility** | **Optimal:** Standard transition tuples $(o_t, a_t, r_t, o_{t+1})$. Independent sample drawing. | **Optimal:** Replay stores trajectories or frame indices; minimal overhead. | **Poor:** Requires storing full sequential episodes; hidden states become stale as weights update. |
| **Sample Efficiency** | **High:** Off-policy updates with small batches. | **High:** Similar to standard off-policy SAC. | **Low:** Recurrent off-policy training requires burn-in periods and multi-step sequences. |
| **Training Stability & Variance** | **High:** Standard feedforward backpropagation. | **High:** Standard feedforward backpropagation. | **Low:** Recurrent backpropagation through time (BPTT) introduces high gradient variance. |
| **Implementation Complexity** | **Low:** Standard PyTorch/TensorFlow SAC implementation. | **Low:** Concatenate $H$ observations along feature dimension. | **High:** Custom sequence replay buffers, hidden-state tracking. |
| **Scientific Defensibility** | **High:** Justified by state accumulators and explicit velocity features. | **High:** Standard empirical POMDP technique (Mnih et al., 2015). | **Vulnerable:** Reviewers frequently challenge stale hidden states in off-policy RNNs. |

### 3. Architectural Verdict on Temporal Memory:
- **Primary Choice:** **Option A (Memoryless MLP with Feature-Augmented Temporal Differences)**. Because $o_t$ already incorporates:
  1. $\Delta \mathcal{L}_{t-1}$ (instantaneous FL velocity),
  2. $\|\Delta w_{t-1}\|_2$ (displacement magnitude),
  3. $\{\rho_{k,t-1}\}$ (exponential moving average of past Byzantine behavior),
  4. $E_{\text{rem},t-1}$ (exact energy integral),
  5. $n_{\text{out},t-1}$ (exact outage integral),
  the observation $o_t$ has **zero zeroth-order state aliasing**. An MLP operating on this augmented feature vector is theoretically sound and avoids the well-documented failure modes of recurrent off-policy DRL.
- **Secondary Baseline:** **Option B (Frame Stacking with $H=3$)**, retained to test whether higher-order temporal correlations provide additional empirical gains.
- **Option C (Recurrent SAC) is formally REJECTED.**

---

# SECTION F — ACTOR AND CRITIC INTERFACE SPECIFICATION

### 1. Dimension Analysis of $o_t$
Let $K$ be the number of clients:
- $r_{t-1} \in \mathbb{R}^2$ ($2$ floats)
- $\phi(w_{t-1}) \in \mathbb{R}^3$ ($3$ floats: $\mathcal{L}, \Delta \mathcal{L}, \|\Delta w\|$)
- $\{\rho_{k,t-1}\}_{k=1}^K \in \mathbb{R}^K$ ($K$ floats)
- $\bar{h}_{t-1} \in \mathbb{R}^K$ ($K$ floats)
- $n_{\text{out},t-1} \in \mathbb{R}$ ($1$ float)
- $E_{\text{rem},t-1} \in \mathbb{R}$ ($1$ float)
- $t \in \mathbb{R}$ ($1$ float)

$$\boxed{\dim(o_t) = 2 + 3 + K + K + 1 + 1 + 1 = 2K + 8}$$
For example, with $K = 10$ clients (as in the base paper), $\dim(o_t) = 2(10) + 8 = 28$ scalars.

### 2. Actor Network Interface
- **Input:** $o_t \in \mathbb{R}^{2K+8}$
- **Output:** Latent Gaussian distribution parameters:
  $$\mu_\phi(o_t) \in \mathbb{R}^3, \quad \log \sigma_\phi(o_t) \in \mathbb{R}^3$$
  followed by reparameterization $u_t = \mu_\phi(o_t) + \exp(\log \sigma_\phi(o_t)) \odot \epsilon_t$ and squashing:
  $$a_t = g(u_t) = \begin{bmatrix} \delta_{\max} \tanh(u_{x,t}) \\ \delta_{\max} \tanh(u_{y,t}) \\ \frac{1}{2}(\tanh(u_{\eta,t}) + 1) \end{bmatrix} \in [-\delta_{\max}, \delta_{\max}]^2 \times [0, 1]$$

### 3. Critic Networks Interface (Twin Critics $Q_{\theta_1}, Q_{\theta_2}$)
- **Input:** Concatenation of observation and action:
  $$(o_t, a_t) \in \mathbb{R}^{(2K+8) + 3} = \mathbb{R}^{2K+11}$$
- **Output:** Scalar action-value estimate:
  $$Q_{\theta_j}(o_t, a_t) \in \mathbb{R}, \quad \forall j \in \{1, 2\}$$

### 4. Actor-Critic Information Symmetry
Actor and critics receive the **identical observation vector $o_t$**. No asymmetric information or privileged micro-layer data is passed to the critics, preventing value estimation bias and critic-actor distribution mismatch.

---

# SECTION G — OBSERVATION NORMALIZATION STRATEGY CLASS

Different observation components operate on radically different physical scales:
- UAV coordinates: $r \in [-d, d]$ ($\sim \pm 100\text{ m}$)
- Channel gains: $\bar{h} \sim 10^{-6} - 10^{-2}$
- Reputations: $\rho \in [0, 1]$
- Energy: $E_{\text{rem}} \in [0, E_{\text{budget}}]$ ($\sim 100 - 1000\text{ J}$)
- Outages: $n_{\text{out}} \in [0, T_{\max}]$ ($\sim 0 - 50$)
- Round index: $t \in [1, T_{\max}]$ ($\sim 1 - 100$)

Unnormalized inputs cause severe neural gradient vanishing or explosion.

### 1. Normalization Strategy Class Selection:
We mandate **Physical Bounded Normalization (Fixed Linear Scaling to $[-1, 1]$ or $[0, 1]$)** based strictly on known domain bounds:

$$\begin{aligned}
\tilde{r}_{t-1} &= \frac{r_{t-1}}{d} &\in [-1, 1]^2 \\
\tilde{\phi}(w_{t-1}) &= \begin{bmatrix} \text{clip}(\mathcal{L} / \mathcal{L}_0, 0, 5) \\ \text{clip}(\Delta \mathcal{L} / \mathcal{L}_0, -1, 1) \\ \text{clip}(\|\Delta w\| / W_{\max}, 0, 1) \end{bmatrix} &\in [-1, 5] \times [-1, 1] \times [0, 1] \\
\tilde{\rho}_{k,t-1} &= \rho_{k,t-1} &\in [0, 1] \\
\tilde{h}_{k,t-1} &= \text{clip}\left(\frac{\log_{10}(\bar{h}_{k,t-1}) - h_{\min}^{\text{dB}}}{h_{\max}^{\text{dB}} - h_{\min}^{\text{dB}}},\; 0,\; 1\right) &\in [0, 1] \quad (\text{Log-spectral scaling}) \\
\tilde{n}_{\text{out},t-1} &= \frac{n_{\text{out},t-1}}{T_{\max}} &\in [0, 1] \\
\tilde{E}_{\text{rem},t-1} &= \frac{E_{\text{rem},t-1}}{E_{\text{budget}}} &\in [0, 1] \\
\tilde{t} &= \frac{t - 1}{T_{\max} - 1} &\in [0, 1]
\end{aligned}$$

### 2. Zero Future Information Leakage Guarantee:
Because this normalization relies strictly on **fixed physical constants** ($d, E_{\text{budget}}, T_{\max}, \mathcal{L}_0$) known a priori, it requires **zero online running statistics and zero batch-dependent lookahead**. Future information leakage through normalization is mathematically impossible.

---

# SECTION H — HOSTILE REVIEWER AUDIT

The table below catalogs a hostile scrutiny across 14 potential representation and architecture failure modes:

| # | Potential Failure Mode | Severity | Status | Audit Defense |
|---|---|:---:|:---:|---|
| **1** | **Insufficient observation for Markov control** | High | 🟢 **NO ISSUE** | State vector covers position, FL convergence, Byzantine trust, channels, energy budget, and time clock. |
| **2** | **Hidden future information in observation** | Critical | 🟢 **NO ISSUE** | All components in $o_t$ are indexed $t-1$ or $t$ (clock). Fading $\xi_t$ and adversary $\omega_t$ are strictly absent. |
| **3** | **Reward / State leakage in $\phi(w_{t-1})$** | High | 🟢 **NO ISSUE** | $\phi(w_{t-1})$ contains past loss $\mathcal{L}(w_{t-1})$ and past step velocity $\Delta \mathcal{L}_{t-1}$. Current step reward $R_t$ depends on $w_t$, which is not in $o_t$. |
| **4** | **Client-index confusion under fixed topology** | Medium | 🟢 **NO ISSUE** | Explicitly audited. User $k$ has fixed ground coordinates $r_k$; ordered concatenation preserves this physical geometry. |
| **5** | **Poor scalability with client count $K$** | Medium | 🟢 **NO ISSUE** | Input dimension $2K+8$ scales linearly. For typical FL deployments ($K = 10 - 30$), input size $\le 68$ floats, well within standard MLP capacity. |
| **6** | **Unnecessary RNN complexity & replay staleness** | High | 🟢 **NO ISSUE** | Recurrent architectures formally rejected. Feedforward MLP chosen to maintain off-policy replay efficiency. |
| **7** | **Inadequate temporal velocity in observation** | High | 🟢 **NO ISSUE** | Explicitly resolved by including loss velocity $\Delta \mathcal{L}_{t-1}$ and displacement $\|\Delta w_{t-1}\|_2$ in $\phi(w_{t-1})$. |
| **8** | **Mismatch between actor and critic inputs** | Medium | 🟢 **NO ISSUE** | Perfect symmetry: both receive the exact same observation vector $o_t$. |
| **9** | **Inconsistent feature availability across rounds** | Medium | 🟢 **NO ISSUE** | At $t=1$, difference features ($\Delta \mathcal{L}_0, \|\Delta w_0\|_2$) are cleanly initialized to 0; all other variables have known initial values. |
| **10** | **Future leakage through normalization statistics** | High | 🟢 **NO ISSUE** | Normalization uses fixed physical domain constants ($d, E_{\text{budget}}, T_{\max}$), with zero online running mean/variance leakage. |
| **11** | **Over-engineered neural architecture** | Medium | 🟢 **NO ISSUE** | Standard feedforward MLP prioritized over complex graph/transformer models for sample efficiency. |
| **12** | **Unjustified claim of architectural superiority** | Medium | 🟢 **NO ISSUE** | No claim of theoretical superiority; justified strictly by problem requirements and sample efficiency under expensive physical recourse. |
| **13** | **Accidental inclusion of micro-layer variables** | Critical | 🟢 **NO ISSUE** | Zero micro-layer decision variables ($v_t, E_{\mathrm{WPT},t}, p_{k,t}, b_{k,t}, f_{k,t}$) enter the macro actor or critic. |
| **14** | **Assumptions implying convergence proofs** | High | 🟢 **NO ISSUE** | Neural networks are treated as empirical function approximators; no convergence guarantees are asserted. |

---

# SECTION I — FINAL ARCHITECTURAL DECISIONS

$$\boxed{\begin{aligned}
\textbf{A. Final Observation:} & \quad o_t^{\text{final}} = \bigl(\tilde{r}_{t-1},\; \tilde{\phi}(w_{t-1}),\; \{\rho_{k,t-1}\}_{k=1}^K,\; \tilde{h}_{t-1},\; \tilde{n}_{\text{out},t-1},\; \tilde{E}_{\text{rem},t-1},\; \tilde{t}\bigr) \in \mathbb{R}^{2K+8} \\
\textbf{B. Actor Input:} & \quad o_t^{\text{final}} \in \mathbb{R}^{2K+8} \\
\textbf{C. Critic Input:} & \quad (o_t^{\text{final}}, a_t) \in \mathbb{R}^{2K+11} \\
\textbf{D. Client Representation:} & \quad \text{Direct Ordered Spatial Concatenation (Option A)} \\
\textbf{E. Temporal Memory:} & \quad \text{Feature-Augmented Instantaneous Representation (Option A)} \\
\textbf{F. Primary Architecture Class:} & \quad \textbf{Deep Feedforward Multi-Layer Perceptron (MLP)} \\
\textbf{G. Secondary Ablation Class:} & \quad \textbf{Finite-History Frame Stacking ($H=3$)} \text{ and } \textbf{Set-Based Feature Encoder}
\end{aligned}}$$

---

# SECTION J — DEFERRED DECISIONS (CARRIED TO STAGE 3D.4)

The following parameters are **strictly deferred** to Stage 3D.4 (Numerical Hyperparameter & Training Protocol Specification):
1. Number of hidden layers (e.g., 2 vs. 3).
2. Number of hidden units per layer (e.g., 128 vs. 256).
3. Activation function choices (e.g., ReLU vs. ELU vs. Swish).
4. Learning rates ($\alpha_\theta, \alpha_\phi, \alpha_\mu, \tau_Q$).
5. Experience replay buffer capacity ($N_{\text{buffer}}$) and mini-batch size ($B$).
6. Target entropy value $\bar{\mathcal{H}}$.
7. Optimizer choices (e.g., Adam with specific $\beta_1, \beta_2$).
8. Exploration warm-up step count.

---

# SECTION K — FINAL GATE VERDICT

$$\boxed{\Huge\textbf{GREEN — STAGE 3D.2 PASSED}}$$

### Formal Gate Statement:

> **Stage 3D.2 is closed. The observation interface, FL model representation, client representation, and primary MLP architecture class are mathematically specified, internally consistent with Stage 2D/3D.1, and rigorously protected against future information leakage. The project is cleared to proceed to Stage 3D.3 — Training Reward Formulation & Primal-Dual Mechanism Audit.**

