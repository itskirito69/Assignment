# Stage 3B — Reward Audit and Pathological Incentive Analysis

## Hostile Mathematical Audit of the Cross-Layer Objective Function

---

# 1. THE REWARD FUNCTION UNDER AUDIT

The frozen Stage 2D formulation specifies the primary per-step DRL reward as:

$$R_t = \begin{cases} \mathcal{L}(w_{t-1}) - \mathcal{L}(w_t), & \text{if } \text{feas}_t = 1 \\ 0, & \text{if } \text{feas}_t = 0 \end{cases}$$

with the cumulative objective:

$$\max_\pi \; J(\pi) = \mathbb{E}_\pi\left[\sum_{t=1}^{T_{\max}} \gamma^{t-1} R_t\right]$$

subject to:

$$G_1(\pi) = \mathbb{E}_\pi\left[\sum_{t=1}^{T_{\max}} E_{\text{WPT},t} \cdot \mathbb{1}[\text{feas}_t = 1]\right] \le E_{\text{budget}}$$

$$G_2(\pi) = \mathbb{E}_\pi\left[\frac{1}{T_{\max}} \sum_{t=1}^{T_{\max}} (1 - \text{feas}_t)\right] \le \epsilon_{\text{out}}$$

---

# 2. AUDIT OF PATHOLOGICAL INCENTIVES

---

### Pathology 1: The "Outage Preference" Pathology (CRITICAL BUG)

#### Mathematical Mechanism
Suppose at round $t$, the candidate set $\mathcal{S}_t^{\text{cand}}$ contains Byzantine adversaries whose attacks bypass robust aggregation, or simply suppose local SGD mini-batch noise causes a minor loss oscillation:
$$\mathcal{L}(w_t) > \mathcal{L}(w_{t-1}) \quad \Longrightarrow \quad \Delta \mathcal{L}_t = \mathcal{L}(w_{t-1}) - \mathcal{L}(w_t) < 0$$

- If the round is **physically successful** ($\text{feas}_t = 1$):
  $$R_t = \Delta \mathcal{L}_t < 0$$
- If the system experiences a **service failure / outage** ($\text{feas}_t = 0$):
  $$R_t = 0$$

#### The Perverse Consequence
$$\boxed{R_t(\text{feas}_t = 0) = 0 \;>\; R_t(\text{feas}_t = 1) = \Delta \mathcal{L}_t}$$

When facing Byzantine attacks or noisy FL updates, **the policy earns a strictly higher reward by intentionally failing to serve users than by successfully serving them.**

The DRL agent can exploit this by:
1. Setting the displacement $(\Delta x_t, \Delta y_t)$ to fly away from legitimate users into an unfavorable channel location.
2. Adjusting $\eta_t$ to an extreme threshold where $|\mathcal{S}_t^{\text{cand}}| < S_{\min}$ or where the micro-layer fails.

While constraint $G_2(\pi) \le \epsilon_{\text{out}}$ caps the total fraction of outages, **within that allowed budget $\epsilon_{\text{out}}$, the agent will strategically allocate outages to escape rounds with high Byzantine risk or noisy gradients.**

---

### Pathology 2: The "Cherry-Picking / Shrinking Participation" Pathology

#### Mathematical Mechanism
In non-IID Federated Learning, serving a large cohort of heterogeneous users introduces gradient conflict: the aggregate loss reduction $\mathcal{L}(w_{t-1}) - \mathcal{L}(w_t)$ on the global distribution is often smaller in early rounds than the localized loss drop achieved by training on a small, homogeneous cluster of easy clients.
- Setting $\eta_t \approx 1$ filters out all but the $1$ or $2$ highest-reputation clients.
- Physically, serving $2$ clients requires vastly lower WPT energy $E_{\text{WPT}}$ and dramatically reduces the risk of secrecy ($C9$) or time ($C1$) violations.
- Short-term FL progress on those $2$ clients appears high.

#### The Perverse Consequence
The policy is incentivized to minimize participant diversity to maximize physical feasibility and short-term loss drop, inducing severe **client drift** and catastrophic forgetting of excluded clients' data distributions.

*Mitigation in Stage 2D:* The formulation includes the requirement $|\mathcal{S}_t^{\text{cand}}| \ge S_{\min}$. However, if $S_{\min}$ is set too low (e.g., $S_{\min} = 2$ when $K = 20$), this pathology remains active.

---

### Pathology 3: Non-Stationary Reward Scale and Temporal Vanishing Gradients

#### Mathematical Mechanism
In typical deep neural network training:
- **Rounds $t = 1 \dots 10$:** Initial random weights yield rapid loss drops: $\Delta \mathcal{L}_t \sim 0.5 - 2.0$.
- **Rounds $t = 50 \dots 100$:** Near convergence, updates yield minute improvements: $\Delta \mathcal{L}_t \sim 10^{-4} - 10^{-3}$, often dominated by stochastic evaluation noise.

With discount factor $\gamma \in [0.95, 0.99]$:
$$\sum_{t=1}^{T_{\max}} \gamma^{t-1} R_t \approx \sum_{t=1}^{15} \gamma^{t-1} R_t$$
The policy gradient $\nabla_\theta J(\pi_\theta)$ is almost entirely dominated by the first $15\%$ of the FL rounds. The DRL controller receives virtually zero learning signal in late rounds, precisely when delicate UAV positioning and tight Byzantine filtering are necessary to prevent late-stage model corruption.

---

### Pathology 4: Energy Neglect in Unconstrained Reward Space

The reward $R_t$ contains **no energy cost term**.
- Energy is solely governed by $G_1(\pi) \le E_{\text{budget}}$.
- In standard Lagrangian or primal-dual DRL, if the budget $E_{\text{budget}}$ is loose, the agent will burn maximum power ($P_c^{\max}$) without any incentive for conservation.
- This is mathematically consistent with constrained optimization (an unbinding constraint has zero shadow price), but must be recognized: the policy will never naturally conserve energy below $E_{\text{budget}}$.

---

### Pathology 5: Secrecy Reward Independence

Is the agent incentivized to violate secrecy?
- **No.** The physical-layer secrecy condition ($C9$) is a hard constraint inside the micro-layer feasible set $\mathcal{Y}_t$.
- If $C9$ cannot be satisfied under Eve's channel uncertainty radius $\Delta_{E,k,t}$, the micro-layer outputs $\text{feas}_t = 0$.
- The agent has no mechanism to "trade off" secrecy violations for higher reward, because the micro-layer acts as an absolute barrier. Secrecy cannot be compromised by reward hacking.

---

# 3. MATHEMATICAL REMEDIES AND REWARD SHAPING (FOR STAGE 3C IMPLEMENTATION)

To eliminate the identified pathologies during the upcoming algorithm design stage without altering the frozen Stage 2D control problem structure, the operational reward function in the DRL simulator must incorporate:

### Remedy 1: Service Failure Penalty ($\lambda_{\text{out}}$)
To eliminate the Outage Preference Pathology, assign a strictly negative penalty to service failures:
$$R_t^{\text{shaped}} = \begin{cases} \mathcal{L}(w_{t-1}) - \mathcal{L}(w_t), & \text{if } \text{feas}_t = 1 \\ -\lambda_{\text{out}}, & \text{if } \text{feas}_t = 0 \end{cases}$$
where $\lambda_{\text{out}} > \max_{\omega, \zeta} |\Delta \mathcal{L}_t^{\text{poisoned}}|$. This guarantees that an outage is always strictly worse than attempting service, preventing strategic outages.

### Remedy 2: Participation-Aware Regularization
To combat cherry-picking, augment the reward with a modest client coverage bonus or scale the loss reduction by effective participation:
$$R_t^{\text{shaped}} = \left(\frac{|\mathcal{S}_t^{\text{cand}}|}{K}\right)^\kappa \bigl(\mathcal{L}(w_{t-1}) - \mathcal{L}(w_t)\bigr) - \lambda_{\text{out}}(1 - \text{feas}_t)$$
with $\kappa \in [0.5, 1.0]$.

### Remedy 3: Reward Normalization / Relative Loss Reduction
To resolve the temporal scale collapse:
$$R_t = \frac{\mathcal{L}(w_{t-1}) - \mathcal{L}(w_t)}{\mathcal{L}(w_0) + \epsilon}$$
or use running standard deviation normalization across training episodes.

---

# 4. CONCLUSION

The abstract objective $\mathcal{P}_{\text{ctrl}}$ in Stage 2D is theoretically legitimate, but the raw step reward $R_t = \Delta \mathcal{L}_t \cdot \mathbb{1}[\text{feas}_t=1]$ has a **mathematically demonstrable flaw** (the Outage Preference Pathology). 

This requires an operational service failure penalty ($\lambda_{\text{out}}$) when instantiating the environment in Stage 3C.

