# Stage 3B — Final Gate Report

## DRL Formulation Audit Verdict and Transition to Stage 3C

---

# 1. FINAL AUDIT VERDICT

$$\boxed{\Large\textbf{YELLOW — FORMULATION IS USABLE WITH SPECIFIC OPERATIONAL BRIDGES}}$$

---

### Verdict Rationale

The frozen Stage 2D control problem formulation $\mathcal{P}_{\text{ctrl}}$ is **conceptually sound, mathematically defensible, and structurally ready** for algorithm evaluation. It successfully isolates physical-layer feasibility from sequential cross-layer control and introduces no causal or information leaks.

However, a strict hostile DRL review reveals **three operational pathologies** that must be resolved in the DRL simulator/algorithm interface before training in Stage 3C/3D:

1. **State Completeness Gap (Energy Budget Awareness):**  
   The state $X_t^-$ tracks the outage count $n_{\text{out},t-1}$ for constraint $G_2$, but omits cumulative energy consumption $E_{\text{cum},t-1}$. In a finite-horizon budget-constrained problem ($G_1(\pi) \le E_{\text{budget}}$), the agent cannot make budget-optimal decisions without observing remaining energy.
2. **Reward Pathology (Outage Preference Bug):**  
   Under Byzantine poisoning or noisy SGD, successful rounds can yield negative loss improvements ($\Delta \mathcal{L}_t < 0$). Because service failures yield $R_t = 0$, the agent receives a higher reward for failing than for training under attack ($0 > \Delta \mathcal{L}_t$). An operational service failure penalty ($\lambda_{\text{out}}$) is mathematically mandatory.
3. **Observation POMDP Aliasing:**  
   Compressing $w_{t-1}$ to a static scalar loss $\mathcal{L}(w_{t-1})$ obscures training trajectory momentum. The observation representation must provide temporal loss differences ($\Delta \mathcal{L}_{t-1}$) or leverage frame stacking / recurrent policy networks.

**Stage 2D does NOT need to be reopened**, because these items represent standard DRL state/reward implementation specifications rather than changes to the physical network model or security constraints.

---

# 2. AUDIT SCORECARD ACROSS THE 7 PILLARS

| # | Audit Dimension | Status | Key Hostile Finding | Operational Requirement for Stage 3C |
|---|---|:---:|---|---|
| **1** | **State & Observation** | 🟡 YELLOW | $E_{\text{cum},t-1}$ omitted; budget-blindness for $G_1$. Static loss compression causes POMDP aliasing. | Include $E_{\text{cum},t-1}$ in operational state. Augment $\phi(w_{t-1})$ with loss momentum/differences. |
| **2** | **Action Adequacy** | 🟢 GREEN | $a_t = (\Delta x_t, \Delta y_t, \eta_t)$ provides clean, continuous control authority over position and trust admission. | Maintain continuous compact action space $[-\delta_{\max}, \delta_{\max}]^2 \times [0, 1]$. |
| **3** | **Reward Audit** | 🟡 YELLOW | Outage preference bug: $R_t(\text{fail}) = 0 > R_t(\text{poisoned}) < 0$. Vanishing gradients in late rounds. | Incorporate failure penalty $-\lambda_{\text{out}}$ and relative reward scaling. |
| **4** | **Trust / Byzantine Mechanism** | 🟢 GREEN | Continuous threshold $\eta_t$ cleanly segments candidates based on historical reputation without combinatorial action space. | Enforce minimum cohort size $S_{\min}$ to prevent single-client cherry-picking. |
| **5** | **Physical-Layer Recourse** | 🟢 GREEN | Micro-layer acts as an environmental transition/recourse operator, not a competing bilevel agent. | Treat micro-layer as environment physics engine; no bilevel policy gradients needed. |
| **6** | **Transition Model** | 🟢 GREEN | Pushforward transition $P(\cdot \mid X_t^-, a_t)$ is causal, Markovian, and mathematically closed. | Preserve sequence: action $\to$ realization $\to$ recourse $\to$ FL update. |
| **7** | **Long-Term Constraints** | 🟢 GREEN | Constraints $G_1(\pi) \le E_{\text{budget}}$ and $G_2(\pi) \le \epsilon_{\text{out}}$ conform to canonical CMDP structure. | Direct match for Lagrangian primal-dual, CPO, or projection methods. |

---

# 3. TRANSITION TO STAGE 3C

### Can Stage 3C Begin?

$$\boxed{\textbf{YES — STAGE 3C CANDIDATE ALGORITHM COMPARISON MAY BEGIN}}$$

### Prerequisites Carried into Stage 3C

When evaluating candidate DRL algorithms (e.g., PPO-Lagrangian, SAC-Lagrangian, CPO, RCPO, TD3-Primal-Dual):

1. **Algorithm Family Requirement:**  
   The candidate algorithm MUST natively handle **continuous action spaces** ($\mathcal{A} \subset \mathbb{R}^3$) and **long-term expectation constraints** (CMDP).
2. **Environment Interface Specification:**  
   The simulated environment must expose:
   $$o_t^{\text{operational}} = \bigl(r_{t-1},\; \phi(w_{t-1}),\; \{\rho_{k,t-1}\},\; \bar{h}_{t-1},\; n_{\text{out},t-1},\; E_{\text{cum},t-1},\; t\bigr)$$
   with shaped reward $R_t^{\text{shaped}} = \Delta \mathcal{L}_t \cdot \mathbb{1}[\text{feas}_t = 1] - \lambda_{\text{out}} \cdot \mathbb{1}[\text{feas}_t = 0]$.
3. **No Optimization Claims:**  
   The algorithm comparison must evaluate empirical sample efficiency, constraint violation rates during training, and asymptotic policy stability — avoiding claims of guaranteed global optimality.

---

# 4. DELIVERABLES CREATED

| File | Location | Content |
|---|---|---|
| **Technical Formulation Audit** | `DRL_IRS_UAV/Stage_3B_DRL_Formulation_Audit/Stage_3B_DRL_Formulation_Audit.md` | Audit of State, Observation, Action Adequacy, Byzantine Mechanism, Recourse, Transition, and Constraints. |
| **Reward Audit** | `DRL_IRS_UAV/Stage_3B_DRL_Formulation_Audit/Stage_3B_Reward_Audit.md` | Deep dive into Pathological Incentives (Outage Preference, Cherry-picking, Scale Collapse) and Shaping Remedies. |
| **Final Gate Report** | `DRL_IRS_UAV/Stage_3B_DRL_Formulation_Audit/Stage_3B_Final_Gate.md` | Scorecards, YELLOW verdict, operational prerequisites, and greenlight for Stage 3C. |

