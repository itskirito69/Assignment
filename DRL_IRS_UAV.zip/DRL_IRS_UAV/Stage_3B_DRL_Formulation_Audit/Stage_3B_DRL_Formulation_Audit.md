# Stage 3B — DRL Formulation Audit

## Comprehensive Technical and Mathematical Audit of the Stage 2D Formulation Prior to Algorithm Selection

---

### Executive Context

This audit evaluates the frozen **Stage 2D cross-layer control formulation** ($\mathcal{P}_{\text{ctrl}}$) from the perspective of modern Deep Reinforcement Learning (DRL), Constrained MDP (CMDP) theory, and stochastic control. 

The objective is to expose hidden mathematical gaps, information structure deficiencies, action authority limits, and transition dynamics before selecting a DRL algorithm family in Stage 3C.

---

# 1. STATE AND OBSERVATION AUDIT

### 1.1 Mathematical Definitions Under Review

- **Pre-Action State:**
  $$X_t^- = \bigl(r_{t-1},\; w_{t-1},\; \{\rho_{k,t-1}\}_{k=1}^K,\; \bar{h}_{t-1},\; n_{\text{out},t-1},\; t\bigr)$$
- **DRL Observation:**
  $$o_t = \psi(X_t^-) = \bigl(r_{t-1},\; \phi(w_{t-1}),\; \{\rho_{k,t-1}\}_{k=1}^K,\; \bar{h}_{t-1},\; n_{\text{out},t-1},\; t\bigr)$$

---

### 1.2 State Sufficiency Analysis ($X_t^-$)

Under the modeling assumptions validated in Stage 2D:
1. Small-scale channel fading $\xi_t \sim P_\xi(\cdot)$ is i.i.d. block fading.
2. Byzantine manipulation follows $\omega_t \sim P_B(\cdot \mid X_t^-, a_t)$.
3. FL local updates follow conditional SGD distributions given $(w_{t-1}, \mathcal{S}_t^{\text{cand}})$.

Under these assumptions, $X_t^-$ contains all physical and algorithmic historical state information needed to render the transition $X_{t+1}^- \sim P(\cdot \mid X_t^-, a_t)$ formally Markovian.

#### The Missing Cumulative Energy Gap (CRITICAL)
While $X_t^-$ includes $n_{\text{out},t-1} = \sum_{\tau=1}^{t-1} (1 - \text{feas}_\tau)$ to track long-term outage constraint satisfaction ($G_2(\pi) \le \epsilon_{\text{out}}$), **it omits the cumulative energy consumption**:
$$E_{\text{cum},t-1} = \sum_{\tau=1}^{t-1} E_{\text{WPT},\tau} \cdot \mathbb{1}[\text{feas}_\tau = 1]$$
- **Mathematical consequence:** The long-term constraint $G_1(\pi) \le E_{\text{budget}}$ imposes a hard budget across the finite horizon $T_{\max}$. An optimal policy for a finite-horizon budget-constrained control problem is **non-stationary with respect to state without budget awareness**: the policy must know the remaining energy budget $E_{\text{rem},t-1} = E_{\text{budget}} - E_{\text{cum},t-1}$ to modulate risk aversion (e.g., whether to fly aggressively or serve demanding users in later rounds).
- Without $E_{\text{cum},t-1}$ in the state, the agent is budget-blind, violating Markov sufficiency for the constrained objective.
- **Remedy:** $E_{\text{cum},t-1}$ must be formally tracked alongside $n_{\text{out},t-1}$ in the operational state.

---

### 1.3 Observation Usability and Partial Observability ($\phi(w_{t-1})$)

In $o_t$, the high-dimensional weight vector $w_{t-1} \in \mathbb{R}^d$ ($d \sim 10^4 - 10^7$) is mapped to a low-dimensional summary $\phi(w_{t-1}) \in \mathbb{R}^{d_\phi}$.
- **Usability:** Passing raw $w_{t-1}$ into a neural policy network would lead to catastrophic parameter explosion, overfitting, and severe sample inefficiency. Compression is necessary.
- **Information Loss & POMDP Nature:** Compressing $w_{t-1}$ into instantaneous loss $\mathcal{L}(w_{t-1})$ creates an intrinsic Partially Observable Markov Decision Process (POMDP). 
  - A scalar loss $\mathcal{L}(w_{t-1})$ cannot distinguish between a model that is steadily descending a steep valley versus a model oscillating inside a Byzantine-induced limit cycle.
  - **Memory Requirement:** A purely memoryless reactive policy $\pi(a_t \mid o_t)$ with 1D loss is susceptible to perceptual aliasing. However, $\phi(w_{t-1})$ can be structured to include temporal gradient features:
    $$\phi(w_{t-1}) = \bigl(\mathcal{L}(w_{t-1}),\; \mathcal{L}(w_{t-1}) - \mathcal{L}(w_{t-2}),\; \|\nabla \mathcal{L}(w_{t-1})\|\bigr)$$
    or the policy network can utilize recurrent layers (LSTM/GRU) or frame-stacking (history window of length $H \ge 3$). Full recurrent memory across the entire episode is unnecessary because $\{\rho_{k,t-1}\}$ already acts as an exponential-moving-average memory of client reliability.

---

### 1.4 Redundant State Variables ($\bar{h}_{t-1}$)

- $\bar{h}_{t-1} \in \mathbb{R}_+^K$ stores the effective legitimate channel gains from round $t-1$.
- **Hostile scrutiny:** Under pure i.i.d. block fading, the small-scale fading component of $\xi_t$ is statistically independent of $\xi_{t-1}$. The large-scale path loss is completely determined by $r_{t-1}$, which is already explicitly present in $o_t$.
- Therefore, in a strictly i.i.d. Rayleigh/Rician environment, $\bar{h}_{t-1}$ provides zero mutual information about $\xi_t$ beyond what is known from $r_{t-1}$.
- **Verdict:** While technically Markov-redundant under i.i.d. fading, $\bar{h}_{t-1}$ is harmless ($K$ scalar floats) and becomes valuable if the simulator incorporates temporal channel correlation (e.g., Gauss-Markov fading). It should be retained.

---

### 1.5 Future Information Leakage Check

- $r_{t-1}$: position at end of round $t-1$. (Past)
- $w_{t-1}$: aggregated weights from round $t-1$. (Past)
- $\rho_{k,t-1}$: trust scores updated at round $t-1$. (Past)
- $n_{\text{out},t-1}$: outage count up to round $t-1$. (Past)
- Instantaneous channel fading $\xi_t$, Eve CSI errors, and Byzantine realization $\omega_t$ are **strictly absent** from $X_t^-$ and $o_t$.
- **Verdict:** 🟢 **Zero future information leakage.** Information flow is causal and rigorous.

---

# 2. ACTION ADEQUACY AUDIT

### 2.1 Action Space Definition

$$a_t = (\Delta x_t, \Delta y_t, \eta_t) \in \mathcal{A} = [-\delta_{\max}, \delta_{\max}]^2 \times [0, 1]$$

---

### 2.2 Control Authority Breakdown

| Dimension | Controlled Via | Authority Mechanism | Sufficient? |
|---|---|---|:---:|
| **FL Progress** | $\eta_t$ and $(\Delta x_t, \Delta y_t)$ | Filters corrupted clients via trust threshold; positions UAV to maximize channel capacity for eligible clients. | ✅ Yes |
| **Energy Consumption** | $(\Delta x_t, \Delta y_t)$ and $\eta_t$ | Moving closer to IRS/clients reduces required $E_{\text{WPT}}$ and user uplink power; higher $\eta_t$ serves fewer users, reducing aggregate energy demand. | ✅ Yes |
| **Service Feasibility** | $(\Delta x_t, \Delta y_t)$ and $\eta_t$ | UAV position directly determines Line-of-Sight (LoS) path loss. Adjusting $\eta_t$ changes $|\mathcal{S}_t^{\text{cand}}|$, indirectly relieving micro-layer constraint congestion. | ✅ Yes |
| **Secrecy ($C9$)** | $(\Delta x_t, \Delta y_t)$ | UAV trajectory controls distance to legitimate users relative to the eavesdropper. | ✅ Yes |
| **Byzantine Participation** | $\eta_t \in [0, 1]$ | Sets the dynamic acceptance gate $\mathcal{S}_t^{\text{cand}} = \{k : \rho_{k,t-1} \ge \eta_t\}$. | ✅ Yes |

---

### 2.3 The Single-Scalar Threshold Dilemma

- **Hostile Challenge:** $\eta_t$ is a single scalar applied uniformly across all $K$ clients. Why not provide a full binary client scheduling vector $s_t \in \{0, 1\}^K$?
- **Defense:**
  1. Action space dimensionality: An action space of $\{0, 1\}^K$ creates $2^K$ combinatorial discrete actions (or $K$ Bernoulli probabilities). In hybrid continuous-discrete DRL, this introduces severe policy gradient variance and policy degradation.
  2. The separation of concerns is mathematically sound: DRL manages the *trust admission policy* ($\eta_t$), while the micro-layer enforces physical feasibility on all candidates meeting that trust standard.
  3. Clients with high reputation are admitted as candidates; if geographical dispersion makes serving all candidates physically impossible, the UAV must learn to position itself to cover the most critical cluster or adjust $\eta_t$ adaptively.
- **Verdict:** $a_t$ provides adequate control authority without introducing combinatorial explosion. No new action dimensions should be added.

---

# 3. PHYSICAL-LAYER RECOURSE AUDIT

### 3.1 Mapping Under Audit

$$(r_t, \xi_t, \mathcal{S}_t^{\text{cand}}) \;\longrightarrow\; \mathcal{Y}_t \;\longrightarrow\; (\text{feas}_t, y_t)$$

where:
$$y_t = \bigl(v_t, E_{\text{WPT},t}, T_t, \{p_{k,t}, b_{k,t}, f_{k,t}\}_{k \in \mathcal{S}_t^{\text{cand}}}\bigr)$$

---

### 3.2 Is This a Hidden Bilevel Optimization Problem?

In bilevel optimization / Stackelberg formulations:
- The upper-level agent optimizes $F(x, y)$ subject to $y \in \arg\min_{y'} f(x, y')$.
- If $f \ne F$, the two levels have conflicting objectives, requiring nested optimization, gradient unrolling, or value function approximations.

**In the Stage 2D Formulation:**
- The micro-layer does **not** have an independent, competing objective function.
- Stage 2D Correction 2 strictly defines the micro-layer as a **feasibility search / recourse operator**:
  $$\text{Find } y_t \in \mathcal{Y}(r_t, \xi_t, \mathcal{S}_t^{\text{cand}})$$
- If implemented to minimize instantaneous energy $E_{\text{WPT}}$, the micro-layer's goal is completely aligned with the upper-level constraint $G_1(\pi) \le E_{\text{budget}}$.
- In reinforcement learning terminology, the micro-layer is part of the **environment transition kernel and reward generator**, exactly analogous to a physics simulation engine in robotic locomotion (e.g., rigid-body contact solver).
- **Verdict:** 🟢 **Not a bilevel game.** The macro DRL treats the micro-layer as an internal transition mechanism with recourse. No bilevel policy learning is required.

---

# 4. TRANSITION MODEL AUDIT

### 4.1 Coherence of the Transition Kernel

$$X_{t+1}^- \sim P(\cdot \mid X_t^-, a_t)$$

The state transitions through the following exact sequence:
1. **Kinematics:** $r_t = \text{Proj}_{\|r\| \le d}(r_{t-1} + (\Delta x_t, \Delta y_t))$ — deterministic.
2. **Admission Filtering:** $\mathcal{S}_t^{\text{cand}} = \{k : \rho_{k,t-1} \ge \eta_t\}$ — deterministic.
3. **Environment Uncertainty Realization:** 
   $$\xi_t \sim P_\xi(\cdot), \quad \omega_t \sim P_B(\cdot \mid X_t^-, a_t)$$
4. **Micro-layer Recourse:** Computes $\text{feas}_t \in \{0, 1\}$ and $y_t$.
5. **Execution & Aggregation (Conditional on $\text{feas}_t = 1$):**
   - User computation & secure transmission executed.
   - Byzantine clients inject malicious updates $\Delta w_{k,t}$ for $k \in \mathcal{S}_t^{\text{cand}}$ where $\omega_{k,t} = 1$.
   - Server executes robust aggregation:
     $$w_t = w_{t-1} + \alpha_g \mathcal{G}\bigl(\{\Delta w_{k,t}\}_{k \in \mathcal{S}_t^{\text{cand}}}\bigr)$$
   - Reputation update:
     $$\rho_{k,t} = \beta_\rho \rho_{k,t-1} + (1 - \beta_\rho)\sigma_{k,t}$$
   - Channel metric update: $\bar{h}_{k,t} = |h_k(r_t, v_t; \xi_t)|^2$.
   - Outage metric update: $n_{\text{out},t} = n_{\text{out},t-1}$.
6. **Execution on Service Failure ($\text{feas}_t = 0$):**
   - Safe fallback: no transmission, no FL aggregation.
   - $w_t = w_{t-1}$.
   - $\rho_{k,t} = \rho_{k,t-1}$.
   - $\bar{h}_{k,t} = \bar{h}_{k,t-1}$.
   - $n_{\text{out},t} = n_{\text{out},t-1} + 1$.
7. **Time Step:** $t \leftarrow t + 1$.

- **Verdict:** 🟢 **Mathematically coherent and closed.** The transition is an exact pushforward measure over well-defined conditional distributions.

---

# 5. LONG-TERM CONSTRAINTS AUDIT

### 5.1 Formulation Compatibility

$$\mathcal{P}_{\text{ctrl}}: \quad \max_\pi \; J(\pi) \quad \text{s.t.} \quad G_1(\pi) \le E_{\text{budget}}, \quad G_2(\pi) \le \epsilon_{\text{out}}$$

- **Structure:** Both $G_1(\pi)$ and $G_2(\pi)$ are discounted or finite-horizon expected cumulative costs:
  $$G_1(\pi) = \mathbb{E}_\pi\left[\sum_{t=1}^{T_{\max}} c_{1,t}\right], \quad c_{1,t} = E_{\text{WPT},t} \cdot \mathbb{1}[\text{feas}_t = 1]$$
  $$G_2(\pi) = \mathbb{E}_\pi\left[\sum_{t=1}^{T_{\max}} c_{2,t}\right], \quad c_{2,t} = \frac{1}{T_{\max}}(1 - \text{feas}_t)$$
- **Theoretical Compatibility:** This aligns with the classical **Constrained Markov Decision Process (CMDP)** framework (Altman, 1999).
- **Algorithmic Compatibility:** Standard constrained DRL methodologies (Lagrangian primal-dual methods, Projection/CPO, penalty methods) can solve this structure without altering the state-transition dynamics.
- **Verdict:** 🟢 **Sound and compatible.**

---

# 6. SUMMARY OF IDENTIFIED WEAKNESSES

1. **State Omission:** $E_{\text{cum},t-1}$ is missing from $X_t^-$ and $o_t$, creating budget-blindness for constraint $G_1$.
2. **Observation Compression:** Memoryless policy on $\phi(w_{t-1})$ requires either temporal difference features $(\Delta \mathcal{L}_{t-1})$ or recurrent feature processing.
3. **Reward Pathologies:** Analyzed in depth in `Stage_3B_Reward_Audit.md`.

---

