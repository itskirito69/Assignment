# Stage 3C — DRL Algorithm Comparison & Selection Audit

## Comprehensive Technical and Hostile Audit of Candidate Reinforcement Learning Frameworks for Secure UAV–IRS–WPCN Federated Learning

---

# EXECUTIVE SUMMARY

This audit provides an adversarial, mathematically rigorous evaluation of candidate Deep Reinforcement Learning (DRL) algorithmic families for the frozen Stage 2D/3B.1 cross-layer control problem $\mathcal{P}_{\text{ctrl}}$.

We evaluate five major algorithmic paradigms:
1. **Deep Deterministic Policy Gradient (DDPG)** (Lillicrap et al., 2015)
2. **Twin Delayed DDPG (TD3)** (Fujimoto et al., 2018)
3. **Soft Actor-Critic (SAC)** (Haarnoja et al., 2018)
4. **Proximal Policy Optimization (PPO)** (Schulman et al., 2017)
5. **Constrained RL / CMDP Primal-Dual Frameworks** (PPO-Lagrangian, SAC-Lagrangian, CPO) (Altman, 1999; Achiam et al., 2017; Ray et al., 2019; Stooke et al., 2020)

We do **not** assume SAC is superior a priori. We evaluate every algorithm strictly against the 15 operational requirements imposed by the physical, security, and learning dynamics of the system.

---

# PART A — ALGORITHM-SELECTION REQUIREMENTS

The frozen problem imposes 15 mandatory operational requirements:

| # | Requirement | Mathematical / System Origin | Algorithmic Implication |
|---|---|---|---|
| **1** | **Continuous 2-D UAV Movement** | $\Delta x_t, \Delta y_t \in [-\delta_{\max}, \delta_{\max}]$ | Requires continuous action spaces. Eliminates discrete-only algorithms (DQN, Rainbow). |
| **2** | **Continuous Trust Threshold** | $\eta_t \in [0, 1]$ | Requires bounded continuous policy output (e.g., squashed Gaussian via $\tanh$ or Beta distribution). |
| **3** | **Stochastic Transitions** | $\xi_t \sim P_\xi$, $\omega_t \sim P_B$, SGD noise $\zeta_t^{\text{SGD}}$ | The policy must be robust to multimodal aleatoric noise; deterministic policies risk severe brittle over-specialization. |
| **4** | **Long-Horizon Sequential Control** | Finite horizon $T_{\max} \sim 50 - 100$ FL rounds | Requires credit assignment over multi-step episodes with non-stationary loss progress. |
| **5** | **Long-Term Constraints ($G_1, G_2$)** | $G_1(\pi) \le E_{\text{budget}}$, $G_2(\pi) \le \epsilon_{\text{out}}$ | Requires Constrained MDP (CMDP) mechanisms (e.g., adaptive Lagrangian dual variables). Unconstrained RL is invalid. |
| **6** | **Model-Based Physical Recourse** | $(r_t, \xi_t, \mathcal{S}_t^{\text{cand}}) \to \mathcal{Y}_t \to (\text{feas}_t, y_t)$ | Environment step requires running an iterative nonconvex solver (SCA/BCD). Each step is computationally expensive. |
| **7** | **Hard Robust Secrecy ($C9$)** | Worst-case imperfect Eve CSI bound $\Delta_{E,k,t}$ | Secrecy is enforced by the micro-layer feasible set $\mathcal{Y}_t$, NOT by reward penalties. DRL must learn to avoid actions that trigger secrecy outages. |
| **8** | **Delayed / Partial FL Feedback** | Global loss $\mathcal{L}(w_t)$ revealed only after aggregation | Policy faces partial observability; requires temporal tracking of loss momentum. |
| **9** | **Client Diversity vs. Trust Filtering** | $\mathcal{S}_t^{\text{cand}} = \{k : \rho_{k,t-1} \ge \eta_t\}$ | DRL must balance Byzantine risk filtering against client drift without collapsing to single-client cherry-picking. |
| **10** | **Formal Objective vs. Training Reward** | $\mathcal{P}_{\text{ctrl}}$ objective $\ne R_t^{\text{train}}$ | The algorithm must maintain stable policy gradients under shaped/calibrated training surrogates without distorting the formal goal. |
| **11** | **Sample Efficiency** | Physical solver evaluation per step | Replay-based sample reuse is advantageous when environment steps evaluate an iterative optimization solver. |
| **12** | **Stability Under Feasibility Discontinuities** | $\text{feas}_t \in \{0, 1\}$ step jumps in transition | Critic networks must tolerate non-smooth value transitions without catastrophic gradient explosion. |
| **13** | **Reproducibility & Seed Sensitivity** | Requirement for Elsevier journal rigor | Must yield low variance across $\ge 5$ random seeds. Deterministic policies (DDPG) fail this requirement. |
| **14** | **Simulation Data Reuse / Offline Compatibility** | Replay buffer storage of solver runs | Requires off-policy architecture allowing experience replay storage of $(o_t, a_t, r_t, o_{t+1}, c_{1,t}, c_{2,t})$. |
| **15** | **Constrained Control Mechanism** | Multi-constraint optimization | Must accommodate at least two long-term scalar constraints ($G_1, G_2$) simultaneously. |

---

# PART B — CANDIDATE DRL FAMILIES

We evaluate five representative algorithmic paradigms:

1. **DDPG (Deep Deterministic Policy Gradient):** Off-policy, deterministic actor-critic with replay buffer and Ornstein-Uhlenbeck / Gaussian exploration noise.
2. **TD3 (Twin Delayed DDPG):** Off-policy, deterministic actor-critic addressing DDPG's overestimation bias via clipped double Q-learning, delayed policy updates, and target policy smoothing.
3. **SAC (Soft Actor-Critic):** Off-policy, stochastic actor-critic based on the maximum entropy reinforcement learning framework with automatic entropy temperature adjustment.
4. **PPO (Proximal Policy Optimization):** On-policy, stochastic policy gradient using a clipped surrogate objective and Generalized Advantage Estimation (GAE).
5. **Constrained RL / CMDP Families:**
   - **PPO-Lagrangian:** On-policy PPO with adaptive dual variables for constraint penalties.
   - **SAC-Lagrangian:** Off-policy SAC combined with dual gradient ascent on Lagrange multipliers.
   - **CPO (Constrained Policy Optimization):** Trust-region method computing analytic second-order updates for constraints (Achiam et al., 2017).

---

# PART C — TECHNICAL AUDIT OF EACH ALGORITHM

---

### Criterion A: Action-Space Compatibility ($\mathcal{A} = [-\delta_{\max}, \delta_{\max}]^2 \times [0, 1]$)

- **DDPG / TD3:** Deterministic outputs with explicit clipping $\text{clip}(a_t, a_{\min}, a_{\max})$. While technically compatible, deterministic saturation at the boundaries ($0$ or $1$ for $\eta_t$) causes zero policy gradient through the saturation region, leading to frozen exploration.
- **SAC:** Uses squashed Gaussian policies with invertible $\tanh$ transformations:
  $$a_t = \text{diag}(\delta_{\max}, \delta_{\max}, 0.5) \cdot \tanh(\mu_\theta(o_t) + \sigma_\theta(o_t) \odot \epsilon) + (0, 0, 0.5)^T$$
  The Jacobian of the change of variables is tractably incorporated into the policy gradient. Perfectly suited for compact box constraints.
- **PPO:** Typically models independent Gaussian distributions with state-independent or state-dependent standard deviations, followed by clipping. Boundary clipping distorts the Gaussian likelihood ratio $r_t(\theta) = \frac{\pi_\theta(a_t|s_t)}{\pi_{\theta_{\text{old}}}(a_t|s_t)}$, leading to biased policy updates near $\eta_t \in \{0, 1\}$.
- **Constrained RL (SAC-Lagrangian / PPO-Lagrangian):** Inherits the base policy characteristics. SAC-Lagrangian handles compact continuous boundaries cleanly.

---

### Criterion B: Stochasticity (Fading, Byzantine, SGD, Recourse)

- **DDPG:** **Disadvantageous under stochasticity.** DDPG is designed primarily for deterministic transitions. The heavy aleatoric variance from Rayleigh/Rician fading $\xi_t$, state-adaptive Byzantine attacks $\omega_t$, and mini-batch SGD noise causes high Bellman error variance, destabilizing the single deterministic critic.
- **TD3:** Clipped double Q-learning mitigates overestimation bias, but deterministic execution struggles to integrate over multimodal channel fade distributions.
- **SAC:** **Well-suited.** Maximum entropy formulation optimizes both expected return and policy entropy:
  $$J(\pi) = \sum_t \mathbb{E}\left[R_t + \alpha \mathcal{H}(\pi(\cdot|o_t))\right]$$
  This encourages exploratory behavior across candidate actions in the presence of stochastic channel realizations.
- **PPO:** Stochastic policy natively integrates over environment noise, but on-policy sampling means past noisy trajectories cannot be reused, resulting in higher sample demands per gradient update.
- **Constrained RL:** SAC-Lagrangian inherits SAC's entropy-driven exploration; PPO-Lagrangian requires larger sample batches to stabilize dual variable updates.

---

### Criterion C: Constraint Handling ($G_1 \le E_{\text{budget}}, G_2 \le \epsilon_{\text{out}}$)

- **Standard DDPG / TD3 / SAC / PPO:** **None of these handle constraints natively.** 
  - Simply adding arbitrary fixed penalty weights ($R_t - \beta_1 E_{\text{WPT},t} - \beta_2 \mathbb{1}[\text{outage}]$) is **heuristically fragile**:
    - If $\beta_i$ is too small, the constraint is violated.
    - If $\beta_i$ is too large, the agent prioritizes zero energy/outage and stops learning FL progress entirely.
    - Fixed weights cannot adapt as the episode progresses or across differing budget levels.
- **CPO (Constrained Policy Optimization):** Formulates trust-region quadratic programs with linear constraint approximations. However:
  - CPO requires inverting Fisher Information Matrices (high computation).
  - When constraints are severely violated or infeasible during exploration, CPO's recovery step often fails, causing erratic policy collapse.
  - Strictly on-policy.
- **Lagrangian Primal-Dual Frameworks (SAC-Lagrangian / PPO-Lagrangian):**
  Transforms $\mathcal{P}_{\text{ctrl}}$ into a two-timescale min-max optimization:
  $$\min_{\mu_1 \ge 0, \mu_2 \ge 0} \max_\pi \; \mathcal{L}(\pi, \mu_1, \mu_2) = J(\pi) - \mu_1 \left(G_1(\pi) - E_{\text{budget}}\right) - \mu_2 \left(G_2(\pi) - \epsilon_{\text{out}}\right)$$
  - Dual variables $\mu_1, \mu_2$ are updated via subgradient descent on accumulated constraint violations:
    $$\mu_{1} \leftarrow \left[\mu_1 + \alpha_{\mu_1} \left(\sum_{t=1}^{T_{\max}} E_{\text{WPT},t} - E_{\text{budget}}\right)\right]_+$$
  - Directly maps to our finite-horizon formulation.

---

### Criterion D: Sparse / Negative Feasibility Feedback

When the micro-layer returns $\text{feas}_t = 0$ (outage), $R_t = 0$ (or $-\lambda_{\text{out}}$ in training).
- **DDPG / TD3:** Infeasible regions create flat cliff-faces in the Q-function. The deterministic policy gets trapped against infeasibility boundaries because $\nabla_a Q(s, a) \approx 0$ or points erratically.
- **SAC:** Entropy regularization maintains non-zero probability of escaping infeasible action regimes.
- **PPO:** The clipping mechanism limits catastrophic updates when an outage occurs, but learning is slow if feasible samples are rare in early training.
- **SAC-Lagrangian:** When outages occur, $\mu_2$ increases automatically, raising the effective penalty on actions that induce infeasibility without manual reward re-tuning.

---

### Criterion E: Computational Cost of Physical-Layer Recourse

Each environment step calls the numerical micro-layer solver:
- **On-Policy Algorithms (PPO, PPO-Lagrangian, CPO):**
  - Requires fresh trajectory rollouts for every policy update.
  - Because samples cannot be reused across iterations, on-policy training demands a substantially higher number of solver invocations.
  - **Verdict:** Less attractive when environment interaction involves an iterative numerical optimization solver.
- **Off-Policy Algorithms (DDPG, TD3, SAC, SAC-Lagrangian):**
  - Experience replay allows sample reuse across multiple policy updates.
  - **Verdict:** Well-suited for settings where environment interaction is computationally intensive.

---

### Criterion F: Delayed Learning Signal & Credit Assignment

FL model updates $w_t$ aggregate information across the cohort. The reward $R_t = \mathcal{L}(w_{t-1}) - \mathcal{L}(w_t)$ reflects the global progress resulting from the joint decision $(r_t, \eta_t)$ and subsequent physical transmission.
- **TD3 / DDPG:** 1-step TD bootstrapping with deterministic targets suffers from bias accumulation over long horizons ($T_{\max} \ge 50$).
- **PPO:** GAE($\lambda$) provides an excellent bias-variance trade-off for multi-step credit assignment, but at the cost of on-policy sample inefficiency.
- **SAC:** Soft Bellman equation with entropy term acts as a natural discount regularizer, preventing Q-values from collapsing under delayed sparse rewards.

---

### Criterion G: Exploration Dynamics

- **DDPG:** Relies on additive Ornstein-Uhlenbeck (OU) or Gaussian noise $a_t = \mu(s_t) + \mathcal{N}(0, \sigma^2)$. OU noise is state-independent and frequently pushes actions into infeasible boundaries.
- **TD3:** Adds target policy smoothing noise $\tilde{a} = \text{clip}(\pi(s') + \epsilon, a_{\min}, a_{\max})$ to prevent value peaks. Exploration is still heuristic Gaussian.
- **SAC:** Exploration is **intrinsic and adaptive**. When the policy is uncertain about whether a spatial region or trust threshold yields feasible, high-reward FL updates, it maximizes entropy by exploring broadly. As value certainty increases, entropy temperature $\alpha$ automatically scales down.

---

### Criterion H: Stability & Reproducibility (Seed Sensitivity)

- **DDPG:** Notoriously hyperparameter-sensitive and prone to divergence. Unsuitable for publication targeting top-tier Elsevier journals.
- **TD3:** Highly stable compared to DDPG, but sensitive to the chosen exploration noise schedule and reward scaling.
- **PPO:** Highly stable policy trajectory due to clipping, but high variance across seeds when rewards are sparse or constrained dual variables fluctuate.
- **SAC:** Consistently demonstrates superior reproducibility across continuous control benchmarks. Auto-tuning of $\alpha$ removes the most sensitive hyperparameter.
- **SAC-Lagrangian:** Requires careful two-timescale learning rate balancing ($\alpha_\theta, \alpha_\phi \gg \alpha_\mu$) to prevent dual oscillations. When properly damped, it is highly stable.

---

# PART D — THREE DISTINCT CONSTRAINT LAYERS

To ensure absolute mathematical rigor in the manuscript, the algorithm audit must clearly delineate the three distinct constraint layers:

```text
========================================================================================
LAYER 1: PHYSICAL HARD CONSTRAINTS (Micro-Layer)
Enforced deterministically by the optimization solver for every candidate solution y_t:
- WPCN Energy Causality (C2)
- UAV Flight / WPT Power Limits (C3)
- User Power & Bandwidth Limits (C4, C5)
- User CPU Computation Bounds (C1, C6)
- Unit-Modulus IRS Phase Shifts (C7)
- Robust Worst-Case Secrecy under Imperfect Eve CSI (C9)
-> GUARANTEE: In any round where feas_t = 1, physical secrecy and energy causality hold.
========================================================================================
                                       ↓
========================================================================================
LAYER 2: PER-ROUND FEASIBILITY & FALLBACK (Environment Transition)
- feas_t = 1: Solver finds feasible y_t satisfying Layer 1 -> Execute WPT, FL, aggregation.
- feas_t = 0: Structural infeasibility or solver failure -> Safe fallback (no RF, no FL).
-> GUARANTEE: Outages trigger zero RF transmission, preventing physical security breaches.
========================================================================================
                                       ↓
========================================================================================
LAYER 3: LONG-TERM POLICY CONSTRAINTS (Macro-Layer CMDP)
Enforced on the expected policy trajectory over horizon T_max:
- G_1(π) = E_π[∑ E_WPT,t · 1[feas_t = 1]] ≤ E_budget
- G_2(π) = E_π[1/T_max ∑ (1 - feas_t)] ≤ ε_out
-> GOAL OF DRL ALGORITHM: Learn policy π that satisfies Layer 3 constraints globally.
========================================================================================
```

### Critical Reviewer-Defense Rule:
> **Hard physical secrecy (Layer 1) does NOT imply policy constraint satisfaction (Layer 3).**  
> Layer 1 prevents instantaneous wiretapping. Layer 3 prevents the UAV from exhausting its battery prematurely ($G_1$) or dropping excessive rounds ($G_2$). The DRL algorithm is evaluated exclusively on its ability to satisfy Layer 3 while maximizing learning progress.

---

# PART E — AUDIT OF THE TRAINING-REWARD PROBLEM

In accordance with Stage 3B.1, the formal objective $J(\pi)$ is separated from the operational training reward $R_t^{\text{train}}$.

### 1. Reward Interaction with Candidate Algorithms

| Training Reward Component | DDPG / TD3 | PPO | SAC | SAC-Lagrangian |
|---|---|---|---|---|
| **Loss Difference $\Delta \mathcal{L}_t$** | Q-value scale shifts drastically as learning saturates. | GAE dampens variance, but gradient magnitude diminishes. | Entropy term $\alpha \mathcal{H}$ maintains gradient flow even when $\Delta \mathcal{L}_t \to 0$. | Entropy term maintains exploration; dual terms balance loss progress. |
| **Outage Penalty $-\lambda_{\text{out}}$** | Creates Q-value discontinuity; risk of policy freeze. | Policy clip prevents sudden collapse, but slows recovery. | Actor smoothly shifts distribution away from outage regions. | Additive penalty can be minimized because $\mu_2$ natively penalizes outages. |
| **Reward Normalization** | Sensitive to running statistics. | Standard practice; works well with PPO value baseline. | Highly beneficial; stabilizes temperature $\alpha$ tuning. | Crucial; keeps reward scale compatible with Lagrange multipliers. |
| **Adaptive Dual Terms $-\sum \mu_i c_{i,t}$** | Brittle; deterministic actor overreacts to changing $\mu$. | Stable, but slow dual convergence due to on-policy lag. | Stable; off-policy replay absorbs changing reward landscape if duals update slowly. | **Natural match.** Multipliers update at slow timescale. |

### 2. Operational Training Reward Design (Deferred to Stage 3D)
To prevent the "Outage Preference Pathology" (identified in Stage 3B) without asserting invalid dominance bounds (retracted in Stage 3B.1), candidate training reward designs for evaluation in Stage 3D include:
- Relative loss improvement or running standardization of observed loss improvements;
- Calibrated, bounded service failure penalties $-\bar{\lambda}_{\text{out}} \cdot \mathbb{1}[\text{feas}_t = 0]$;
- Reward clipping or scaling.
No specific formula is frozen in Stage 3C; the final mathematical structure of $R_t^{\text{train}}$ will be evaluated and fixed in Stage 3D.

---

# PART F — CLIENT DIVERSITY / BYZANTINE TRADEOFF

### The Quad-Tradeoff Mechanics

$$\text{Byzantine Trust Filtering } (\eta_t \uparrow) \quad \longleftrightarrow \quad \text{Physical Feasibility } (\text{feas}_t = 1) \quad \longleftrightarrow \quad \text{Client Diversity } (|\mathcal{S}_t^{\text{cand}}| \uparrow) \quad \longleftrightarrow \quad \text{Global FL Progress } (\Delta \mathcal{L}_t)$$

1. **If $\eta_t$ is too high ($\to 1$):**
   - The candidate set shrinks to $1-2$ highly trusted clients.
   - Micro-layer feasibility is extremely easy to satisfy (low $E_{\text{WPT}}$, minimal interference, easy secrecy).
   - *Failure Mode:* Severe client drift, model overfitting to a tiny data subset, failure of the global FL model on the broader distribution.
2. **If $\eta_t$ is too low ($\to 0$):**
   - The candidate set includes all clients, including Byzantine attackers.
   - Attackers corrupt the global model, driving $\Delta \mathcal{L}_t < 0$.
   - Concurrently, large $|\mathcal{S}_t^{\text{cand}}|$ over-congests the wireless channel, causing micro-layer infeasibility ($\text{feas}_t = 0$).

### Algorithmic Implication
The DRL policy must learn an **intermediate, state-adaptive $\eta_t$** that tracks the evolving reputation scores $\{\rho_{k,t-1}\}$.
- **DDPG/TD3:** Prone to premature concentration of $\eta_t$ to boundary extremes ($0.0$ or $1.0$) because deterministic exploration cannot smoothly balance the trade-off between drift and poisoning.
- **SAC / SAC-Lagrangian:** Maximum entropy promotes broader exploratory coverage across candidate actions, though it does not mathematically guarantee interior trust thresholds or adequate client diversity. Client diversity remains an open design issue for Stage 3D.

---

# PART G — LITERATURE VERIFICATION

| Study | Domain & Venue | Action Space | Algorithm | Constraint Handling | Physical Layer | Limitations Relevant to Our System |
|---|---|---|---|---|---|---|
| **Wu et al. (2024)** | STAR-RIS AirFL + UAV (IEEE) | Continuous 3D Trajectory + Phases | SAC + DDQN | Soft Penalty in Reward | All-DRL (no micro solver) | Security ignored; Byzantine ignored; WPCN ignored; all-DRL violates unit-modulus constraints. |
| **Zhang et al. (2024)** | Two-timescale IRS Beamforming (IEEE TWC) | Slow IRS + Fast Precoding | Bilevel DRL | Unconstrained | Model-based fast precoding | No FL; no security; no energy harvesting; heuristic two-timescale without CMDP bounds. |
| **Fan et al. (2024)** | UAV Byzantine AirFL (SciOpen/IEEE) | Power allocation | Convex AO | Instantaneous power bounds | Convex optimization | Static optimization; no IRS; no DRL; no WPCN; no secrecy. |
| **Wang et al. (2023)** | Safe RL for UAV Trajectory (IEEE TVT) | Continuous UAV velocity | PPO-Lagrangian | CMDP (Collision avoidance) | Kinematics only | On-policy inefficiency; no wireless physical layer; no FL. |
| **Li et al. (2024)** | RAN Slicing & Resource Allocation (MDPI/IEEE) | Bandwidth & Power | SAC-Lagrangian | CMDP (Latency & SLA bounds) | Wireless channel model | No UAV mobility; no IRS; no Byzantine; confirms SAC-Lagrangian sample efficiency over PPO. |
| **Banothu & Bhar (2024)** | Secure IRS THz-NOMA (IEEE) | Continuous Phase + Power | FDRL | Reward Penalty | DRL directly sets phases | Reward penalty allows secrecy violations; no FL application; no Byzantine. |

### Literature Audit Synthesis:
1. **PPO-Lagrangian** is widely used in robotic motion and simple UAV collision avoidance where physics simulators run in microseconds, but is rarely chosen for complex wireless networks where each step evaluates a multi-second optimization solver.
2. **SAC-Lagrangian** is the dominant, state-of-the-art framework in recent (2023–2024) literature for constrained wireless resource allocation due to its off-policy sample efficiency and entropy-driven stability.
3. **Reward-penalty approaches dominate naive literature**, but top-tier reviewers consistently penalize papers where security is treated as a soft penalty rather than an enforced constraint.

---

# PART H — REVIEWER-2 / REVIEWER-3 FORENSICS

### 1. Old Rejection Vulnerabilities vs. DRL Solutions

| Rejection Vulnerability (Previous Paper) | Status in Proposed Architecture | Defense Mechanism |
|---|---|---|
| **Reviewer 2: Monotonic decrease / convergence of outer AO loop** | ✅ **Completely Eliminated** | The outer AO loop is discarded entirely. Replaced by a sequential Markov decision process. No claim of monotonic outer-loop convergence is made. |
| **Reviewer 3: Surrogate secrecy objective instead of true secrecy** | ✅ **Completely Eliminated** | True robust secrecy ($C9$) with realization-dependent Eve error $\Delta_{E,k,t}$ is enforced directly inside the micro-layer feasible set $\mathcal{Y}_t$. |
| **Reviewer 3: Lack of stationarity / KKT proofs** | ✅ **Completely Eliminated** | The micro-layer is strictly defined as a numerical recourse search; no KKT or stationarity claim is asserted. |

### 2. New DRL Vulnerabilities & How to Preempt Them

Hostile DRL reviewers evaluate papers based on standard empirical pitfalls. We preempt them explicitly:

| Potential Reviewer Challenge | Prohibited / Unsafe Claim | Mandatory Safe Claim for Manuscript |
|---|---|---|
| *"Did your DRL converge to the optimal policy?"* | ❌ "The algorithm converges to the globally optimal cross-layer policy." | ✅ "The policy network achieves empirical training stability, and the learned policy consistently outperforms baseline heuristics across test seeds." |
| *"Is your policy guaranteed to satisfy long-term constraints?"* | ❌ "The Lagrangian framework guarantees zero constraint violations at every episode." | ✅ "Constraint satisfaction is evaluated empirically against the prescribed tolerances $\epsilon_{\text{out}}$ and $E_{\text{budget}}$." |
| *"Is your result an artifact of a single lucky seed?"* | ❌ Showing single-seed curves without error bands. | ✅ "All training and evaluation curves report mean and 95% confidence intervals across at least 5 independent random seeds." |

---

# PART I — QUANTITATIVE DECISION MATRIX

| Evaluation Criterion | Weight | DDPG | TD3 | PPO | SAC | SAC-Lagrangian |
|---|:---:|:---:|:---:|:---:|:---:|:---:|
| **Continuous Action ($\mathcal{A} \subset \mathbb{R}^3$)** | High | Moderate (clipping) | Moderate (clipping) | Moderate (clipping) | **Strong (squashed $\tanh$)** | **Strong (squashed $\tanh$)** |
| **Stochastic Environment Handling** | High | Weak (deterministic) | Moderate (double Q) | **Strong (stochastic)** | **Strong (max-entropy)** | **Strong (max-entropy)** |
| **Exploration Dynamics** | High | Weak (heuristic OU) | Moderate (Gaussian) | Moderate (on-policy) | **Strong (entropy-driven)** | **Strong (entropy-driven)** |
| **Sample Efficiency (Expensive Solver)** | Critical | Moderate (off-policy) | Moderate (off-policy) | Weak (on-policy: $\times 20$ samples) | **Strong (off-policy)** | **Strong (off-policy)** |
| **Constraint Handling ($G_1, G_2$)** | Critical | Weak (penalty only) | Weak (penalty only) | Weak (penalty only) | Weak (penalty only) | **Strong (primal-dual CMDP)** |
| **Simulation Runtime Viability** | Critical | Moderate | Moderate | **Less favorable (on-policy)** | **Favorable (off-policy)** | **Favorable (off-policy)** |
| **Reward Scale Sensitivity** | Medium | Weak (hyper-sensitive) | Moderate | Moderate (GAE) | **Strong (temperature $\alpha$)** | **Strong (calibrated $\mu$)** |
| **Critic Stability & Overestimation** | High | Weak (diverges) | **Strong (clipped Q)** | Moderate | **Strong (double Q)** | **Strong (double Q)** |
| **Reproducibility Across Seeds** | High | Weak | Moderate | **Strong** | **Strong** | **Strong** |
| **Delayed FL Credit Assignment** | Medium | Weak | Moderate | **Strong (GAE)** | Moderate (discounted) | Moderate (discounted) |
| **Client Diversity / Trust Tradeoff** | High | Weak (boundary collapse) | Moderate | Moderate | **Strong (entropy spread)** | **Strong (entropy spread)** |
| **Scientific Defensibility (Elsevier)** | High | Weak (outdated) | Moderate | Moderate | Moderate (unconstrained) | **Strong (canonical CMDP)** |

---

# PART J — ALGORITHM RECOMMENDATION

---

### 1. Primary Candidate: SAC-Lagrangian (Soft Actor-Critic with Adaptive Primal-Dual Updates)

**Justification:**
1. **CMDP Alignment:** Connects to $\mathcal{P}_{\text{ctrl}}$ by transforming $G_1(\pi) \le E_{\text{budget}}$ and $G_2(\pi) \le \epsilon_{\text{out}}$ into dual updates without fixed manual reward penalty engineering.
2. **Sample Efficiency:** Replay-based sample reuse is advantageous when environment transitions require evaluating an iterative micro-layer solver.
3. **Exploratory Behavior:** Maximum entropy regularization encourages broad stochastic exploration over continuous action regimes during training.
4. **Action Bounding:** Natural support for compact continuous action spaces $[-\delta_{\max}, \delta_{\max}]^2 \times [0, 1]$ via squashed Gaussian policies.

---

### 2. Secondary Candidate: PPO-Lagrangian (Proximal Policy Optimization with Lagrangian Relaxation)

**Scientific Utility:**
- Serves as the **primary on-policy baseline** in the manuscript.
- Evaluates whether on-policy policy gradient stability provides advantages that offset the higher sample requirements of on-policy sampling.

---

### 3. Rejected Candidates

- **DDPG:** Less suitable due to overestimation bias and deterministic exploration challenges in stochastic fading/Byzantine environments.
- **TD3 (Unconstrained):** Lacks an integrated CMDP mechanism for long-term policy constraints ($G_1, G_2$).
- **CPO (Constrained Policy Optimization):** High computational overhead from second-order matrix inversions, recovery-step sensitivities, and on-policy sample demands.

---

### 4. Candidate Auxiliary Mechanisms (Deferred to Stage 3D Evaluation)

The following numerical stabilization choices are identified for evaluation in Stage 3D:
1. **Learning Rate Relationships:** Evaluating relative step sizes between policy, critic, and dual variables ($\alpha_\mu$ vs. $\alpha_\theta, \alpha_\phi$) to ensure stable optimization.
2. **Replay Buffer Structure:** Evaluating whether individual cost terms $(c_{1,t}, c_{2,t})$ should be decoupled from $R_t^{\text{train}}$ in experience replay.
3. **Dual Stabilization / Projections:** Testing whether dual variables benefit from bounding or damping to prevent instability during early exploration.
4. **Reward Scaling & Normalization:** Evaluating running standard deviation or relative loss scaling to maintain compatible gradients.

---

# PART K — THE CRITICAL ARCHITECTURAL QUESTION

> **Are we actually selecting one DRL algorithm, or do the properties of the problem require a hybrid algorithmic stack?**

### Definitive Answer:

$$\boxed{\textbf{We are NOT selecting a single monolithic DRL algorithm.}}$$

Calling the proposed solution simply "SAC" is mathematically and scientifically inaccurate. The research architecture is a **Hybrid Four-Tier Algorithmic Stack**:

$$\begin{aligned}
\textbf{Tier 1 (Macro Controller):} & \quad \text{Soft Actor-Critic (SAC) with squashed Gaussian continuous policy} \\
\textbf{Tier 2 (Constraint Mechanism):} & \quad \text{Adaptive Primal-Dual Lagrangian Multipliers for } G_1(\pi) \text{ and } G_2(\pi) \\
\textbf{Tier 3 (Physical Recourse Engine):} & \quad \text{Non-convex Model-Based Solver enforcing } \widetilde{C1}\text{--}C9 \text{ (secrecy, WPCN)} \\
\textbf{Tier 4 (FL Training & Aggregation):} & \quad \text{Trust-threshold admission } \mathcal{S}_t^{\text{cand}} \text{ + Byzantine-resilient aggregation } \mathcal{G}
\end{aligned}$$

### Scientific Importance for Manuscript:
Presenting the architecture as a **Hybrid Algorithmic Stack** directly defends against reviewer claims of incrementalism ("just applying SAC"). The novelty lies in the formal mathematical coupling between the tiers:
- Macro DRL (Tier 1) operates over CMDP duals (Tier 2);
- Environment transitions are governed by physical recourse (Tier 3);
- The learning state and reward are driven by Byzantine FL dynamics (Tier 4).

---

# PART L — FINAL GATE

$$\boxed{\Huge\textbf{GREEN — STAGE 3C PASSED}}$$

### Formal Gate Declarations:

1. **Primary Algorithm Selected:** **SAC-Lagrangian** (Off-policy maximum-entropy actor-critic with adaptive dual multipliers).
2. **Secondary Baseline Algorithm:** **PPO-Lagrangian** (On-policy baseline for empirical comparative validation).
3. **Candidate Auxiliary Mechanisms:** Candidate dual updates, cost-separated replay buffer, dual stabilization, running reward normalization (deferred to Stage 3D).
4. **Scope Carried to Stage 3D:**
   - Formal mathematical specification of the SAC-Lagrangian loss functions and dual recursions.
   - Exact neural network architecture design (actor, double critics, cost critics).
   - Training loop timeline and experience replay structure.
   - Final algorithm pseudocode and formulation freeze.
5. **Exact Safe Claims for the Manuscript:**
   - "A hybrid two-timescale framework combining off-policy maximum-entropy DRL with model-based physical recourse."
   - "Long-term WPT energy and outage constraints are addressed via adaptive primal-dual Lagrangian optimization and evaluated empirically."
   - "Physical-layer secrecy under imperfect Eve CSI is enforced whenever feasible recourse is found, with safe fallback on outage."
   - *Prohibited:* No claim of global policy optimality; no claim of guaranteed DRL convergence; no claim of guaranteed asymptotic constraint satisfaction.

> **Stage 3C is closed. The project is cleared to proceed to Stage 3D — Final Algorithmic Stack & Training Formulation Freeze.**

