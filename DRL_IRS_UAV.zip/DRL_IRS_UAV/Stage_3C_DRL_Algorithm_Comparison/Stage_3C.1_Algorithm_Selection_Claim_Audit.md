# Stage 3C.1 — Algorithm Selection Claim Audit

## Surgical Claim Audit and Scientific Calibration of the Provisional DRL Algorithm Selection

---

# 1. EXECUTIVE SUMMARY

This audit performs a surgical calibration of the claims, terminology, and operational assumptions made in the Stage 3C DRL Algorithm Comparison report. 

The provisional selection:
- **Primary Framework:** Soft Actor-Critic (SAC) + adaptive primal-dual Lagrangian constraint handling
- **Secondary Baseline:** Proximal Policy Optimization (PPO) + adaptive primal-dual Lagrangian constraint handling

is **strictly maintained**. 

However, several claims in the initial Stage 3C document exceeded the empirical and mathematical evidence. This audit:
1. Strips all unsupported convergence, optimality, and constraint satisfaction "guarantees" for SAC-Lagrangian.
2. Eliminates all unmeasured runtime, sample-step, and convergence numbers ($20\text{--}150\text{ ms}$, $10^5\text{--}10^6\text{ steps}$, $27.8\text{ hrs}$, etc.).
3. Softens categorical algorithmic judgments (e.g., "DDPG fails catastrophically", "PPO is computationally prohibitive") into evidence-based design trade-offs.
4. Corrects the characterization of entropy regularization, clarifying that entropy promotes exploration but does not guarantee interior solutions or client diversity.
5. Declassifies the operational reward formula, dual projection bounds, and two-timescale learning rates from "frozen requirements" to candidate design choices deferred to Stage 3D.
6. Reaffirms the foundational three-layer constraint architecture and the formal-objective vs. training-reward separation.

---

# 2. CLAIM AUDIT TABLE

| Original Claim / Type | Scientific Deficiency / Vulnerability | Corrected Scientific Interpretation |
|---|---|---|
| **Convergence & Optimality Guarantees**<br>Statements implying SAC-Lagrangian converges to a globally or locally optimal policy, or guarantees policy convergence. | No mathematical convergence proof exists for non-convex neural network actor-critic architectures under non-stationary Markov environments with state-dependent Byzantine behavior. | **Algorithmic mechanism $\ne$ mathematical guarantee.** SAC-Lagrangian is an optimization heuristic. We claim only that the policy is trained using empirical policy optimization, with convergence evaluated empirically via training curves across random seeds. |
| **CMDP Constraint Enforcement**<br>Claims that the Lagrangian framework "natively enforces" or "guarantees asymptotic satisfaction" of $G_1(\pi) \le E_{\text{budget}}$ and $G_2(\pi) \le \epsilon_{\text{out}}$. | Primal-dual gradient updates with non-convex neural function approximators do not possess universal zero-duality-gap or asymptotic constraint-satisfaction theorems. Multiplier oscillations can occur. | SAC with adaptive primal-dual Lagrangian updates is chosen as a mechanism to penalize constraint violations dynamically. **Constraint satisfaction is an empirical evaluation criterion**, measured against prescribed tolerances ($\epsilon_{\text{out}}, E_{\text{budget}}$), not a mathematical guarantee. |
| **Unmeasured Runtime & Sample Counts**<br>Numerical assertions such as: solver runtime ($20\text{--}150\text{ ms}$), PPO step requirements ($2\times 10^6\text{--}5\times 10^6$), SAC step counts ($10^5\text{--}3\times 10^5$), and wall-clock times ($2.8\text{ hrs}$ vs. $27.8\text{ hrs}$). | These numbers were speculative estimations and have not been benchmarked on the actual physical-recourse solver and hardware implementation. Stating unmeasured numbers creates an easy falsification target for reviewers. | **All unmeasured numerical figures are deleted.** Replaced by the qualitative property: Off-policy replay-based sample reuse is advantageous over on-policy rollouts when environment interactions require computationally non-trivial numerical optimization. |
| **Categorical Algorithm Rejections**<br>Absolutist assertions: "DDPG fails catastrophically", "PPO is computationally prohibitive", "deterministic policies fail". | Categorical dismissals sound unscientific and ignore contexts where DDPG or PPO succeed. DDPG simply suffers from known overestimation bias, and PPO typically requires more environment interactions due to on-policy sampling. | Replaced with requirement-based comparative language: DDPG is **less suitable** due to sensitivity to aleatoric fading noise and deterministic exploration limits; PPO has **higher sample demands** due to lack of transition reuse, making it less preferred as the primary method under an iterative solver. |
| **Entropy & Boundary Guarantees**<br>Claims that SAC's entropy objective ($\alpha \mathcal{H}$) "guarantees avoidance of $\eta_t \to 0$ or $1$", "prevents boundary collapse", and "ensures client diversity". | Entropy regularization adds a bonus for action distribution dispersion, but if the Q-gradient toward a boundary is steep (e.g., strong reward for excluding attackers), the policy can and will saturate at boundaries ($\eta_t \to 1$). It guarantees neither interior thresholds nor data diversity. | Entropy regularization promotes stochastic exploration and reduces premature policy concentration, but **does not guarantee interior trust-threshold values, client diversity, or avoidance of boundary solutions**. Client diversity remains an open design issue for Stage 3D. |
| **Premature Freezing of Reward Formulas**<br>Freezing the operational reward as: $R_t^{\text{train}} = \frac{\Delta \mathcal{L}_t}{\sigma_{\mathcal{L},t}}\mathbb{1}[\text{feas}_t=1] - \bar{\lambda}_{\text{out}}\mathbb{1}[\text{feas}_t=0]$. | Stage 3C's mandate is algorithm comparison, not reward hyperparameter freezing. Declaring a specific z-score normalization and penalty structure closes design avenues before testing. | **Specific reward formulas are NOT frozen in Stage 3C.** Loss normalization, reward clipping, and outage penalty scaling are designated as **candidate Stage 3D training-design choices**. Stage 3C establishes only the requirement that $R_t^{\text{train}}$ be compatible with the formal objective $\mathcal{P}_{\text{ctrl}}$. |
| **Dual Projections & Two-Timescale Learning Rates**<br>Asserting that bounded dual projection $[\mu_{\min}, \mu_{\max}]$ and two-timescale learning rates ($\alpha_\mu \ll \alpha_\theta$) are "mathematically required" or guarantee stability. | While standard engineering heuristics, claiming they are "mathematically required" invites a proof obligation that cannot be satisfied for deep RL. | Reclassified as **numerical stabilization and algorithm-design choices** to be tested and evaluated in Stage 3D. |

---

# 3. FINAL ALGORITHM SELECTION (REQUIREMENT-BASED)

The selection is justified exclusively through the operational requirements of the frozen Stage 2D/3B.1 formulation:

$$\boxed{\textbf{Primary Framework: SAC + Adaptive Primal-Dual Lagrangian}}$$

$$\boxed{\textbf{Secondary Baseline: PPO + Adaptive Primal-Dual Lagrangian}}$$

### Justification Summary:

1. **Continuous Action Space:** Both algorithms natively handle $a_t = (\Delta x_t, \Delta y_t, \eta_t) \in [-\delta_{\max}, \delta_{\max}]^2 \times [0, 1]$ via continuous distribution parameterization (e.g., squashed Gaussian via $\tanh$).
2. **Computational Tractability with Recourse Solver:** SAC reuses past transition samples stored in an experience replay buffer. Because each environment step evaluates a numerical non-convex optimization problem ($\mathcal{Y}_t$), replay efficiency is practically attractive. PPO is retained as an on-policy baseline to benchmark whether policy-gradient stability offsets sample efficiency differences.
3. **Exploration under Non-Convex Feasibility:** SAC's maximum-entropy objective encourages broader sampling of the continuous spatial displacement and trust threshold, reducing premature policy concentration during early training.
4. **Constrained Problem Alignment:** Wrapping both algorithms in adaptive primal-dual Lagrangian updates aligns directly with the multi-constraint structure of $\mathcal{P}_{\text{ctrl}}$ ($G_1(\pi) \le E_{\text{budget}}$ and $G_2(\pi) \le \epsilon_{\text{out}}$).

---

# 4. PRESERVATION OF CORE STRUCTURAL PRINCIPLES

### 4.1 The Three-Layer Constraint Architecture (Preserved)

```text
LAYER 1: Physical Hard Constraints (Micro-Layer)
Enforced deterministically by the numerical solver for every candidate recourse solution y_t:
WPCN energy causality (C2), power bounds (C3, C4), bandwidth (C5), CPU bounds (C1, C6),
IRS unit-modulus phases (C7), and robust secrecy under imperfect Eve CSI (C9).
-> Outcome: If feas_t = 1, physical-layer constraints hold for that transmission.

LAYER 2: Per-Round Feasibility & Fallback (Environment Transition)
- feas_t = 1: Micro-layer finds feasible y_t -> execute WPT, secure transmission, FL update.
- feas_t = 0: Structural infeasibility or solver failure -> safe fallback (no RF, zero energy, no FL).
-> Outcome: Outages trigger zero RF transmission, preventing physical security breaches.

LAYER 3: Long-Term Policy Constraints (Macro-Layer CMDP)
Evaluated across the expected trajectory over horizon T_max:
- G_1(π) = E_π[∑ E_WPT,t · 1[feas_t = 1]] ≤ E_budget
- G_2(π) = E_π[1/T_max ∑ (1 - feas_t)] ≤ ε_out
-> Outcome: Evaluated empirically against specified tolerances.
```

### 4.2 Formal Objective vs. Operational Training Reward (Preserved)

$$\boxed{\text{Formal Research Objective } J(\pi) \;\ne\; \text{Operational Training Reward } R_t^{\text{train}}}$$

- **Formal Objective:**
  $$\mathcal{P}_{\text{ctrl}}: \quad \max_\pi \; \mathbb{E}_\pi\left[\sum_{t=1}^{T_{\max}} \gamma^{t-1} \bigl(\mathcal{L}(w_{t-1}) - \mathcal{L}(w_t)\bigr) \cdot \mathbb{1}[\text{feas}_t = 1]\right]$$
  subject to $G_1(\pi) \le E_{\text{budget}}$ and $G_2(\pi) \le \epsilon_{\text{out}}$. This is the definitive scientific evaluation benchmark.
- **Operational Training Reward:** A surrogate numerical signal $R_t^{\text{train}}$ designed to provide effective gradient feedback.
- **Caveat:** High performance on a shaped training reward does not automatically guarantee optimization of the formal objective; this relationship must be verified empirically.

---

# 5. SCOPE EXPLICITLY DEFERRED TO STAGE 3D

The following technical specifications are **not** frozen in Stage 3C/3C.1 and are deferred to **Stage 3D (Final Algorithmic Stack & Training Formulation Freeze)**:

1. **Actor and Critic Neural Architectures:** Number of hidden layers, units per layer, activation functions, and layer normalization.
2. **Exact Training Reward Formulation:** Choice of relative loss scaling, reward clipping intervals, and baseline subtraction.
3. **Outage Penalty Calibration:** Magnitude and mechanism of the service failure signal ($\bar{\lambda}_{\text{out}}$).
4. **Dual Variable Update Dynamics:** Subgradient step sizes ($\alpha_{\mu_1}, \alpha_{\mu_2}$), dampening terms, and dual clipping/projections.
5. **Learning Rate Relationships:** Empirical selection of actor ($\alpha_\theta$), critic ($\alpha_\phi$), temperature ($\alpha$), and dual ($\alpha_\mu$) learning rates.
6. **Replay Buffer Architecture:** Buffer capacity, batch size, and whether prioritized experience replay (PER) or uniform sampling is used.
7. **Client Diversity Mechanisms:** Whether client participation diversity is tracked via auxiliary state features, regularized in the training surrogate, or evaluated as an empirical trade-off.
8. **Trust-Threshold Parameterization:** Squashing functions and initialization bias for $\eta_t$.
9. **Training Protocol:** Warm-up exploration steps, target network soft update rate ($\tau$), update-to-data ratio (UTD), and multi-seed evaluation procedure.

---

# 6. CLAIMS WE MUST NOT MAKE IN THE MANUSCRIPT

The following claims are **strictly prohibited** in any future paper draft or technical documentation:

| # | Prohibited Claim | Why Prohibited | Safe Alternative |
|---|---|---|---|
| 1 | *"The DRL policy is globally optimal."* | Deep RL with non-convex neural policies cannot guarantee global optimality. | *"The trained policy achieves competitive performance compared to baseline heuristics."* |
| 2 | *"The algorithm is provably convergent."* | No general convergence proof exists for deep SAC-Lagrangian in continuous state-action CMDPs. | *"Empirical convergence is demonstrated via learning curves across independent random seeds."* |
| 3 | *"The policy is guaranteed to satisfy CMDP constraints."* | Primal-dual neural methods can experience constraint oscillations or residual violations. | *"Long-term energy and outage constraints are evaluated against tolerance thresholds."* |
| 4 | *"SAC natively guarantees constraint satisfaction."* | Unconstrained SAC ignores constraints; Lagrangian relaxation is an empirical dual optimization. | *"SAC is coupled with an adaptive Lagrangian mechanism to penalize constraint violations."* |
| 5 | *"Entropy regularization guarantees client diversity and prevents boundary collapse."* | Strong gradient signals can overpower entropy and drive actions to boundaries. | *"Entropy regularization encourages stochastic exploration across candidate actions."* |
| 6 | *"Competing algorithms (DDPG, PPO) fail catastrophically or are computationally impossible."* | Overstated and unprovable; competing algorithms simply have different trade-offs. | *"SAC-Lagrangian is preferred for this setting due to superior replay-based sample reuse."* |
| 7 | *"First-ever DRL framework for UAV-IRS FL."* | Factually false; established as a RED claim in Stage 3A literature audit (Wu et al., 2024 exists). | *"A novel cross-layer framework coupling Byzantine trust, robust secrecy recourse, and CMDP control."* |

---

# 7. FINAL GATE VERDICT

$$\boxed{\Huge\textbf{GREEN — STAGE 3C.1 PASSED}}$$

### Formal Gate Statement:

> **Stage 3C.1 is closed. All overextended claims, speculative numbers, and unsupported guarantees have been stripped. The provisional selection of SAC-Lagrangian (primary) and PPO-Lagrangian (secondary baseline) is scientifically defensible. Stage 2D and Stage 3B remain frozen. The project is cleared to proceed to Stage 3D — Final Algorithmic Stack & Training Formulation Freeze.**

