# Stage 3D.3 — Training Reward Formulation & Primal-Dual Mechanism Audit

## Formal Optimization Alignment, Reward Engineering, and Constrained Primal-Dual Framework Specification for Secure UAV–IRS–WPCN Federated Learning

---

# EXECUTIVE SUMMARY

This report audits, establishes, and freezes the mathematical relationship between the **Formal Scientific Control Problem** ($\mathcal{P}_{\text{ctrl}}$) and the **Operational DRL Training Formulation** for the primary SAC-Lagrangian controller.

The governing principles enforced in this audit are:
1. **$\mathcal{P}_{\text{ctrl}} \ne R_t^{\text{train}}$:** The formal research problem is an uncompromised scientific benchmark. The training reward $R_t^{\text{train}}$ is an operational learning surrogate designed to stabilize temporal-difference policy gradients.
2. **Outage Pathology Elimination:** The raw loss-drop reward ($R_t = \Delta \mathcal{L}_t \mathbb{1}[\text{feas}_t=1]$) creates an incentive to intentionally trigger service outages when learning progress is negative ($0 > \Delta \mathcal{L}_t$). We resolve this via a calibrated operational failure penalty $-\bar{\lambda}_{\text{out}} \mathbb{1}[\text{feas}_t=0]$ without asserting invalid theoretical global bounds.
3. **Zero Double-Counting of Energy:** WPT energy $E_{\text{WPT},t}$ enters the optimization strictly through the constraint cost $c_{1,t}$ and remaining energy state $E_{\text{rem},t-1}$. It is **not** subtracted as an arbitrary penalty from the primary training reward.
4. **Resolution of Discounted-Undiscounted CMDP Mismatch:** The objective is discounted ($\gamma \in (0, 1)$), whereas energy and outage constraints are undiscounted finite-horizon trajectory metrics. We resolve this by decoupling the task and constraint returns via separate critic heads (or cost accumulators) and updating dual variables strictly on undiscounted trajectory budget totals.
5. **Absolute Secrecy Invariance:** Robust physical-layer secrecy ($C9$) remains strictly an internal constraint of the micro-layer feasible set $\mathcal{Y}_t$. It is never relaxed or balanced as a soft reward penalty.
6. **No Unsupported Guarantees:** We claim no global optimality, zero duality gap, or asymptotic constraint-satisfaction theorems. Constraint compliance is evaluated empirically against tolerances $(\epsilon_{\text{out}}, E_{\text{budget}})$.

---

# SECTION A — INHERITED FROZEN INPUTS

The quantities inherited from Stage 2D, Stage 3B.1, Stage 3D.1, and Stage 3D.2 are:

1. **Pre-Action Markov State $X_t^-$:**
   $$X_t^- = \bigl(r_{t-1},\; w_{t-1},\; \{\rho_{k,t-1}\}_{k=1}^K,\; \bar{h}_{t-1},\; n_{\text{out},t-1},\; E_{\text{rem},t-1},\; t\bigr)$$
2. **Operational Observation Vector $o_t \in \mathbb{R}^{2K+8}$:**
   $$o_t = \bigl(\tilde{r}_{t-1},\; \tilde{\phi}(w_{t-1}),\; \{\rho_{k,t-1}\}_{k=1}^K,\; \tilde{h}_{t-1},\; \tilde{n}_{\text{out},t-1},\; \tilde{E}_{\text{rem},t-1},\; \tilde{t}\bigr)$$
   with the 3D model summary triplet $\tilde{\phi}(w_{t-1}) = \left[\tilde{\mathcal{L}}(w_{t-1}),\; \Delta \tilde{\mathcal{L}}_{t-1},\; \|\Delta \tilde{w}_{t-1}\|_2\right]^T$.
3. **Macro Action $a_t \in [-\delta_{\max}, \delta_{\max}]^2 \times [0, 1]$:**
   $$a_t = (\Delta x_t, \Delta y_t, \eta_t)$$
4. **Model-Based Physical Recourse Operator:**
   $$(r_t, \xi_t, \mathcal{S}_t^{\text{cand}}) \;\xrightarrow{\text{solver}}\; \mathcal{Y}_t \;\longrightarrow\; (\text{feas}_t, y_t)$$
   where $\text{feas}_t \in \{0, 1\}$, and $y_t = (v_t, E_{\mathrm{WPT},t}, T_t, \{p_{k,t}, b_{k,t}, f_{k,t}\}_{k \in \mathcal{S}_t^{\text{cand}}})$.
5. **Candidate Client Set:**
   $$\mathcal{S}_t^{\text{cand}} = \{k \in \{1, \dots, K\} : \rho_{k,t-1} \ge \eta_t\}, \quad \text{with feasibility requiring } |\mathcal{S}_t^{\text{cand}}| \ge S_{\min}$$

---

# SECTION B — FORMAL SCIENTIFIC CONTROL PROBLEM

The uncompromised research problem $\mathcal{P}_{\text{ctrl}}$ of the paper is formulated as:

$$\boxed{\mathcal{P}_{\text{ctrl}}: \quad \max_\pi \; J(\pi) \quad \text{subject to} \quad G_1(\pi) \le E_{\text{budget}}, \quad G_2(\pi) \le \epsilon_{\text{out}}}$$

### 1. Formal Long-Term Return $J(\pi)$
$$J(\pi) \triangleq \mathbb{E}_\pi\left[\sum_{t=1}^{T_{\max}} \gamma^{t-1} R_t^{\text{formal}}\right]$$
where the formal step reward is defined by the global FL loss reduction on a server-side proxy validation dataset $\mathcal{D}_{\text{val}}$:
$$R_t^{\text{formal}} = \begin{cases} \mathcal{L}(w_{t-1}) - \mathcal{L}(w_t), & \text{if } \text{feas}_t = 1 \\ 0, & \text{if } \text{feas}_t = 0 \end{cases}$$
and $\gamma \in (0, 1)$ is the temporal discount factor over the finite horizon $T_{\max}$.

### 2. Formal Long-Term Constraints
- **Expected WPT Energy Budget:**
  $$G_1(\pi) \triangleq \mathbb{E}_\pi\left[\sum_{t=1}^{T_{\max}} E_{\mathrm{WPT},t} \cdot \mathbb{1}[\text{feas}_t = 1]\right] \le E_{\text{budget}}$$
- **Expected Service Outage Rate:**
  $$G_2(\pi) \triangleq \mathbb{E}_\pi\left[\frac{1}{T_{\max}} \sum_{t=1}^{T_{\max}} (1 - \text{feas}_t)\right] \le \epsilon_{\text{out}}$$

### 3. Absolute Separation Principle:
$$\boxed{\mathcal{P}_{\text{ctrl}} \;\ne\; R_t^{\text{train}}}$$
$\mathcal{P}_{\text{ctrl}}$ defines **what the research paper evaluates**. $R_t^{\text{train}}$ defines **what the DRL agent perceives during gradient ascent**. If reward shaping or penalty adjustments are made during training, they serve purely as numerical optimization vehicles.

---

# SECTION C — AUDIT OF CANDIDATE TRAINING REWARDS

We evaluate three candidate constructions for the operational training reward $R_t^{\text{train}}$:

### 1. Candidate Options Evaluated

- **Option A (Raw Formal Reward):**
  $$R_t^{\text{train}} = R_t^{\text{formal}} = \bigl(\mathcal{L}(w_{t-1}) - \mathcal{L}(w_t)\bigr) \cdot \mathbb{1}[\text{feas}_t = 1]$$
- **Option B (Shaped Reward with Additive Outage Penalty & Scaling):**
  $$R_t^{\text{train}} = \frac{\mathcal{L}(w_{t-1}) - \mathcal{L}(w_t)}{\sigma_{\mathcal{L}}} \cdot \mathbb{1}[\text{feas}_t = 1] - \bar{\lambda}_{\text{out}} \cdot \mathbb{1}[\text{feas}_t = 0]$$
- **Option C (Ad-Hoc Penalty Mashup):**
  $$R_t^{\text{train}} = \Delta \mathcal{L}_t \cdot \mathbb{1}[\text{feas}_t = 1] - \beta_E E_{\mathrm{WPT},t} - \beta_{\text{out}} (1 - \text{feas}_t)$$

### 2. Comparative Hostile Audit

| Criterion | Option A (Raw) | Option B (Shaped Task Reward) | Option C (Ad-Hoc Mashup) |
|---|:---:|:---:|:---:|
| **Outage Gaming Resistance** | ❌ **FAILS.** If $\Delta \mathcal{L}_t < 0$, $R(\text{outage}) = 0 > R(\text{success})$. Agent deliberately crashes. | 🟢 **RESISTANT.** Outage incurs strictly negative penalty $-\bar{\lambda}_{\text{out}}$. | 🟡 Moderate, but distorts objectives. |
| **CMDP Alignment** | 🟢 Exact, but numerically unlearnable. | 🟢 **ALIGNED.** Separates task progress from dual constraint mechanisms. | ❌ **VIOLATED.** Arbitrarily mixes constraint penalties with objective before CMDP duals. |
| **Energy Accounting** | 🟢 Clean (energy in constraint). | 🟢 **CLEAN.** Energy handled exclusively via constraint $c_{1,t}$ and state $E_{\text{rem}}$. | ❌ **DOUBLE-COUNTED.** Subtracts energy in reward AND in constraint. |
| **Gradient Scale Stability** | ❌ **FAILS.** Loss drops collapse from $\sim 1.0$ (early) to $\sim 10^{-4}$ (late). Vanishing policy gradients. | 🟢 **STABLE.** Normalized scaling stabilizes gradients across training rounds. | ❌ Unstable multi-unit gradients. |
| **Reviewer Vulnerability** | Critical (Outage Bug). | 🟢 **DEFENSIBLE.** Standard reward shaping literature (Ng et al., 1999). | High (heuristic weight tuning). |

### 3. Verdict:
**Option B is mathematically selected as the operational task reward.** Option A is fatally flawed due to the outage bug. Option C is rejected due to double-counting and CMDP distortion.

---

# SECTION D — OPERATIONAL TRAINING REWARD SPECIFICATION

We define the operational training reward supplied to the SAC temporal-difference learning pipeline as:

$$\boxed{R_t^{\text{train}} \triangleq \Delta \tilde{\mathcal{L}}_t \cdot \mathbb{1}[\text{feas}_t = 1] - \bar{\lambda}_{\text{out}} \cdot \mathbb{1}[\text{feas}_t = 0]}$$

where:
1. **Normalized Loss Improvement:**
   $$\Delta \tilde{\mathcal{L}}_t = \frac{\mathcal{L}(w_{t-1}) - \mathcal{L}(w_t)}{\sigma_{\mathcal{L}}}$$
   where $\sigma_{\mathcal{L}} > 0$ is a fixed scaling factor based on initial model loss magnitude ($\mathcal{L}(w_0)$) or running empirical spread. This maps typical loss drops into the well-conditioned range $[-1, 1]$.
2. **Operational Outage Penalty $\bar{\lambda}_{\text{out}} > 0$:**
   A calibrated scalar penalty ensuring that a service failure is perceived as strictly undesirable during gradient ascent.
   - *Scientific Calibration Principle:* $\bar{\lambda}_{\text{out}}$ is chosen such that an outage is strictly worse than typical noise-induced minor loss fluctuations, discouraging the policy from treating service failure as a "safe haven" against noisy FL updates.
   - *No Unsupported Global Bound:* We make **no claim** that $\bar{\lambda}_{\text{out}} > \max |\Delta \mathcal{L}_t|$ globally. In extreme adversarial poisoning, temporary negative spikes may occur; long-term stability is maintained by the companion constraint $G_2(\pi) \le \epsilon_{\text{out}}$.

---

# SECTION E — PER-ROUND CONSTRAINT COSTS

To represent the long-term constraints $G_1(\pi) \le E_{\text{budget}}$ and $G_2(\pi) \le \epsilon_{\text{out}}$ within the primal-dual framework, we formally define the instantaneous cost signals:

### 1. WPT Energy Cost ($c_{1,t}$)
$$c_{1,t} \triangleq E_{\mathrm{WPT},t} \cdot \mathbb{1}[\text{feas}_t = 1] \in [0, P_c^{\max} T_{\max}^{\text{slot}}]$$
- If $\text{feas}_t = 1$, the micro-layer allocates WPT energy $E_{\mathrm{WPT},t}$ to power legitimate clients.
- If $\text{feas}_t = 0$, safe fallback dictates zero RF transmission: $c_{1,t} = 0$.
- **Cumulative trajectory cost:** $\sum_{t=1}^{T_{\max}} c_{1,t}$. The formal constraint is $\mathbb{E}[\sum_{t=1}^{T_{\max}} c_{1,t}] \le E_{\text{budget}}$.

### 2. Service Outage Cost ($c_{2,t}$)
$$c_{2,t} \triangleq 1 - \text{feas}_t \in \{0, 1\}$$
- If $\text{feas}_t = 1$, service succeeded: $c_{2,t} = 0$.
- If $\text{feas}_t = 0$, service failed: $c_{2,t} = 1$.
- **Cumulative trajectory cost:** $\sum_{t=1}^{T_{\max}} c_{2,t} = n_{\text{out},T_{\max}}$.
- **Equivalence:** The average outage rate constraint $\mathbb{E}[\frac{1}{T_{\max}} \sum_{t=1}^{T_{\max}} c_{2,t}] \le \epsilon_{\text{out}}$ is identically expressed in cumulative integer form as:
  $$\mathbb{E}\left[\sum_{t=1}^{T_{\max}} c_{2,t}\right] \le T_{\max} \epsilon_{\text{out}} \triangleq N_{\text{out}}^{\max}$$

---

# SECTION F — RESOLUTION OF THE DISCOUNTING VS. CONSTRAINT MISMATCH

A fundamental theoretical challenge in Constrained MDPs is that the **reinforcement learning objective is discounted**, whereas **real-world physical constraints are undiscounted trajectory sums**:
$$J_{\text{SAC}}(\pi) = \mathbb{E}_\pi\left[\sum_{t=1}^{T_{\max}} \gamma^{t-1} R_t^{\text{train}}\right] \quad \text{vs.} \quad G_i(\pi) = \mathbb{E}_\pi\left[\sum_{t=1}^{T_{\max}} c_{i,t}\right] \le b_i$$

### 1. The Peril of Naive Discounted Scalarization
If one naively defines a discounted Lagrangian reward $R_t^L = R_t^{\text{train}} - \mu_1 c_{1,t} - \mu_2 c_{2,t}$ and optimizes it with standard discounted SAC, the critic evaluates:
$$Q^L(o, a) = \mathbb{E}\left[\sum_{\tau=t}^{T_{\max}} \gamma^{\tau-t} \left(R_\tau^{\text{train}} - \mu_1 c_{1,\tau} - \mu_2 c_{2,\tau}\right)\right]$$
- **Mathematical Flaw:** Physical Joules spent at round $t = 50$ would be penalized by $\gamma^{49} \mu_1 \approx 0.08 \mu_1$ (for $\gamma = 0.95$). 
- The policy would learn to burn energy recklessly and trigger outages late in the episode, because late-stage constraint costs are artificially discounted to near zero!
- Meanwhile, the true UAV battery and physical communication network count late-stage Joules and outages with full weight $1.0$.

### 2. The Mathematically Sound Resolution: Decomposed Value Functions

To ensure exact alignment between discounted task optimization and undiscounted physical constraint enforcement, we adopt the canonical Safe RL architecture (Achiam et al., 2017; Ray et al., 2019; Stooke et al., 2020):

1. **Task Value Function (Discounted):**
   The primary twin critics $Q_{\theta_1}^R, Q_{\theta_2}^R$ evaluate the discounted task progress:
   $$Q_{\theta_j}^R(o_t, a_t) \approx \mathbb{E}_\pi\left[\sum_{\tau=t}^{T_{\max}} \gamma^{\tau-t} R_\tau^{\text{train}} \;\middle|\; o_t, a_t\right]$$
2. **Constraint Value Functions (Undiscounted / Unit-Discounted):**
   Dedicated cost critics $Q_{\psi_1}^{c_1}, Q_{\psi_2}^{c_2}$ evaluate the expected remaining cumulative constraint consumption:
   $$Q_{\psi_1}^{c_1}(o_t, a_t) \approx \mathbb{E}_\pi\left[\sum_{\tau=t}^{T_{\max}} c_{1,\tau} \;\middle|\; o_t, a_t\right], \quad Q_{\psi_2}^{c_2}(o_t, a_t) \approx \mathbb{E}_\pi\left[\sum_{\tau=t}^{T_{\max}} c_{2,\tau} \;\middle|\; o_t, a_t\right]$$
   trained with discount factor $\gamma_c = 1.0$ (or $\gamma_c \to 1$ for finite horizon).
3. **Dual Updates Driven by True Undiscounted Trajectory Totals:**
   Lagrange multipliers $\mu_1, \mu_2$ are updated using the **undiscounted cumulative trajectory cost violations** across completed episodes.

---

# SECTION G — PRIMAL-DUAL LAGRANGIAN FORMULATION

### 1. Saddle-Point Formulation
We formulate the constrained policy optimization problem via the Lagrangian:

$$\max_{\pi} \min_{\mu_1 \ge 0, \mu_2 \ge 0} \; \mathcal{L}(\pi, \mu_1, \mu_2) \triangleq J_{\text{SAC}}(\pi) - \mu_1 \left(G_1(\pi) - E_{\text{budget}}\right) - \mu_2 \left(G_2(\pi) - \epsilon_{\text{out}}\right)$$

### 2. Sign Convention Verification
- We seek to **maximize** performance $J_{\text{SAC}}(\pi)$ while satisfying $G_i(\pi) \le b_i \iff G_i(\pi) - b_i \le 0$.
- If constraint $i$ is **violated** ($G_i(\pi) > b_i$), the violation term $(G_i(\pi) - b_i)$ is strictly positive.
- Multiplying by $-\mu_i$ (with $\mu_i \ge 0$) results in a **strictly negative subtraction**, lowering the Lagrangian objective $\mathcal{L}(\pi, \mu)$. The policy gradient forces the actor to adjust actions to reduce $G_i$.
- If constraint $i$ is **strictly satisfied** ($G_i(\pi) < b_i$), dual optimization drives $\mu_i \to 0$ (complementary slackness).
- **Verdict:** 🟢 **Sign conventions are mathematically correct and consistent.**

---

# SECTION H — PRIMAL-DUAL UPDATE DYNAMICS

### 1. Dual Variable Update Rules
Dual variables $\mu_1, \mu_2$ are updated at episode boundaries (or every $K_{\text{dual}}$ episodes) using subgradient descent on the empirical trajectory constraint violations:

$$\boxed{\begin{aligned}
\mu_{1, k+1} &= \mathrm{Proj}_{[0, \mu_{1,\max}]}\left(\mu_{1, k} + \alpha_{\mu_1} \cdot \left(\widehat{G}_1^{(k)} - E_{\text{budget}}\right)\right) \\
\mu_{2, k+1} &= \mathrm{Proj}_{[0, \mu_{2,\max}]}\left(\mu_{2, k} + \alpha_{\mu_2} \cdot \left(\widehat{G}_2^{(k)} - \epsilon_{\text{out}}\right)\right)
\end{aligned}}$$

where:
- $\alpha_{\mu_1}, \alpha_{\mu_2} > 0$ are the dual learning rate step sizes.
- $\widehat{G}_1^{(k)} = \sum_{t=1}^{T_{\max}} E_{\mathrm{WPT},t}^{(k)} \mathbb{1}[\text{feas}_t = 1]$ is the empirical WPT energy spent in episode $k$.
- $\widehat{G}_2^{(k)} = \frac{1}{T_{\max}} \sum_{t=1}^{T_{\max}} (1 - \text{feas}_t^{(k)})$ is the empirical outage rate observed in episode $k$.
- $\mathrm{Proj}_{[0, \mu_{\max}]}(x) = \min(\max(x, 0), \mu_{\max})$ is the bounded projection operator.

### 2. Projection Status Disclaimer:
> **Scientific Caveat:** The upper projection bound $\mu_{i,\max}$ is a **numerical stabilization safeguard** designed to prevent gradient explosion during early exploration when constraint violations are frequent. It is **not** a mathematical theorem guaranteeing constraint satisfaction.

---

# SECTION I — SAC + LAGRANGIAN INTEGRATION

With the decomposed value architecture, how does the Lagrangian enter the SAC actor and critic training loops?

### 1. Replay Buffer Transition Structure
Each transition pushed into experience replay buffer $\mathcal{D}$ stores costs decoupled from reward:
$$\tau_t = \bigl(o_t,\; a_t,\; R_t^{\text{train}},\; c_{1,t},\; c_{2,t},\; o_{t+1},\; d_t\bigr)$$
This enables dynamic evaluation of value functions under evolving dual multipliers.

### 2. Critic Networks
- **Task Reward Critics ($Q_{\theta_1}^R, Q_{\theta_2}^R$):**
  Trained on $R_t^{\text{train}}$ via soft Bellman target:
  $$y_t^R = R_t^{\text{train}} + \gamma (1 - d_t) \left(\min_{j \in \{1, 2\}} Q_{\bar{\theta}_j}^R(o_{t+1}, a_{t+1}) - \alpha \log \pi_\phi(a_{t+1}|o_{t+1})\right)$$
- **Cost Critics ($Q_{\psi_1}^{c_1}, Q_{\psi_2}^{c_2}$):**
  Trained on individual costs $c_{1,t}$ and $c_{2,t}$ via undiscounted Bellman targets:
  $$y_t^{c_1} = c_{1,t} + (1 - d_t) Q_{\bar{\psi}_1}^{c_1}(o_{t+1}, a_{t+1}), \quad y_t^{c_2} = c_{2,t} + (1 - d_t) Q_{\bar{\psi}_2}^{c_2}(o_{t+1}, a_{t+1})$$

### 3. Actor Loss Function (Minimization)
The policy parameter $\phi$ is trained to maximize task return, maximize entropy, and minimize expected constraint costs scaled by the current dual variables:

$$\boxed{J_\pi(\phi) = \mathbb{E}_{o \sim \mathcal{D}, \epsilon}\left[\alpha \log \pi_\phi(a_\phi(o, \epsilon)|o) - \min_{j \in \{1, 2\}} Q_{\theta_j}^R\bigl(o, a_\phi(o, \epsilon)\bigr) + \mu_1 Q_{\psi_1}^{c_1}\bigl(o, a_\phi(o, \epsilon)\bigr) + \mu_2 Q_{\psi_2}^{c_2}\bigl(o, a_\phi(o, \epsilon)\bigr)\right]}$$

- When $\mu_1, \mu_2 = 0$, this reduces identically to standard unconstrained SAC.
- When a constraint is violated, the corresponding $\mu_i$ increases, injecting a strong gradient penalty against actions that lead to high energy consumption or outages.

---

# SECTION J — SECRECY INTEGRITY AUDIT

### Crucial Security Verification:
Does the training reward or primal-dual mechanism allow the agent to sacrifice secrecy for higher FL progress?

$$\boxed{\textbf{NO. Secrecy is an absolute physical barrier, NOT a reward trade-off.}}$$

1. **Micro-Layer Feasible Set $\mathcal{Y}_t$:**
   $$\mathcal{Y}_t = \left\{y : \widetilde{C1}\text{--}C7 \text{ and } C9 \text{ are satisfied}\right\}$$
   where $C9$ is the robust secrecy constraint under worst-case CSI error:
   $$|h_k(r_t, v; \xi_t)|^2 \ge \Gamma_k(b_k)\bigl(|z_k(v; \xi_t)| + \Delta_{E,k,t}\bigr)^2 + \frac{N_0 b_k}{p_k}\bigl(\Gamma_k(b_k) - 1\bigr)$$
2. **Strict Operational Consequence:**
   - If no beamforming vector $v$ and power allocation can satisfy $C9$ under realization $\xi_t$, the solver outputs $\text{feas}_t = 0$.
   - Safe fallback is triggered: **Zero RF transmit power, zero communication, zero WPT**.
   - No transmission occurs. Eavesdropper receives zero signal.
3. **Reward Invariance:**
   - The SAC agent is **never** presented with a choice to transmit with insecure channels in exchange for higher $\Delta \mathcal{L}_t$. Insecurity is physically unroutable.

---

# SECTION K — REWARD-GAMING AUDIT (CONCEPTUAL STRESS TEST)

We evaluate the formulation against 7 candidate pathological policies:

| Pathological Policy | Mechanism of Attempted Gaming | Why It Fails Under Proposed Formulation |
|---|---|---|
| **Policy A: Always Cause Outage ($\text{feas}_t = 0$)** | Policy deliberately flies away or sets impossible $\eta_t$ to avoid learning risk. | **Suppressed.** Outages incur an immediate penalty $-\bar{\lambda}_{\text{out}}$ per step. Furthermore, consecutive outages rapidly violate $G_2(\pi) \le \epsilon_{\text{out}}$, driving $\mu_2 \to \mu_{2,\max}$ and heavily penalizing outage-inducing actions in the actor gradient. |
| **Policy B: Extreme High Trust ($\eta_t \to 1.0$)** | Policy cherry-picks 1–2 easy clients to minimize physical infeasibility. | **Suppressed.** If $|\mathcal{S}_t^{\text{cand}}| < S_{\min}$, the round is deemed infeasible ($\text{feas}_t = 0$). If $S_{\min}$ clients are served, training on a tiny subset causes severe client drift, stagnating global validation loss $\Delta \mathcal{L}_t \approx 0$ and yielding near-zero reward. |
| **Policy C: Extreme Low Trust ($\eta_t \to 0.0$)** | Policy admits all users to maximize data volume. | **Suppressed.** Admitting Byzantine attackers corrupts global weights, driving $\Delta \tilde{\mathcal{L}}_t < 0$. Concurrently, scheduling all $K$ users congests the channel, triggering secrecy ($C9$) or power ($C2$) outages. |
| **Policy D: Burn Energy Aggressively in Early Rounds** | Policy spends maximum WPT power ($P_c^{\max}$) to boost early rates. | **Suppressed.** Depletes $E_{\text{rem},t-1}$ rapidly. The state tracks remaining energy, and cumulative expenditure triggers $G_1(\pi) > E_{\text{budget}}$, driving $\mu_1$ upward and penalizing future high-energy actions. |
| **Policy E: Never Spend Energy ($E_{\mathrm{WPT}} \to 0$)** | Policy minimizes energy cost to guarantee constraint satisfaction. | **Suppressed.** Without WPT energy, client computation and uplink transmission are physically infeasible ($\widetilde{C2}$ violated) $\implies \text{feas}_t = 0$, triggering outage penalty $-\bar{\lambda}_{\text{out}}$ and dual penalty $\mu_2$. |
| **Policy F: Alternate Extreme Actions** | Policy alternates between $\eta_t = 0$ and $\eta_t = 1$ to exploit delayed feedback. | **Suppressed.** The observation contains reputation EMA $\{\rho_{k}\}$ and loss velocity $\Delta \mathcal{L}$, smoothing value estimation and exposing oscillating instability to critics. |
| **Policy G: Exploit Byzantine-Induced Loss Drops** | Attackers craft malicious updates that superficially lower training loss. | **Suppressed.** $\mathcal{L}(w_t)$ is evaluated on a **clean, server-held proxy validation dataset** $\mathcal{D}_{\text{val}}$, not on client-reported training losses. Poisoned models degrade on validation data. |

---

# SECTION L — FORMAL-VS-OPERATIONAL ALIGNMENT DECLARATION

> ### What can be legitimately claimed if SAC-Lagrangian training converges?
>
> 1. **Empirical Optimization:** We can claim that the policy network $\pi_\phi$ has successfully learned to maximize the operational training surrogate while satisfying empirical constraints within tolerance:
>    $$\widehat{G}_1(\pi_\phi) \le E_{\text{budget}} + \delta_1, \quad \widehat{G}_2(\pi_\phi) \le \epsilon_{\text{out}} + \delta_2$$
> 2. **Physical Secrecy Invariance:** We can claim that physical-layer secrecy was strictly maintained in every executed transmission round.
> 3. **Performance Superiority:** We can claim that the learned policy achieves superior validation accuracy and convergence speed compared to baseline heuristics (e.g., static UAV, random trust, unconstrained RL).
>
> ### What CANNOT be claimed:
> - ❌ We do NOT claim that $\pi_\phi$ is the globally optimal policy of $\mathcal{P}_{\text{ctrl}}$.
> - ❌ We do NOT claim zero duality gap or theoretical primal-dual convergence.
> - ❌ We do NOT claim that constraint violations during intermediate training exploration are zero.

---

# SECTION M — DEFERRED NUMERICAL DECISIONS (CARRIED TO STAGE 3D.4)

The following numerical hyperparameters are **intentionally left open** and are NOT frozen in Stage 3D.3:
1. Exact numerical value of outage penalty $\bar{\lambda}_{\text{out}}$ (e.g., $0.5$ vs. $1.0$).
2. Numerical value of loss normalization scale $\sigma_{\mathcal{L}}$.
3. Dual learning rates $\alpha_{\mu_1}, \alpha_{\mu_2}$ (e.g., $10^{-4}$ vs. $10^{-3}$).
4. Maximum dual bounds $\mu_{1,\max}, \mu_{2,\max}$.
5. Dual update interval $K_{\text{dual}}$ (e.g., every 1 episode vs. every 5 episodes).
6. Temporal discount factor $\gamma$ numerical value (e.g., $0.95$ vs. $0.99$).
7. Target entropy $\bar{\mathcal{H}}$ and initial temperature $\alpha$.

---

# SECTION N — HOSTILE REVIEWER AUDIT

The table below catalogs a hostile scrutiny across 15 potential mathematical and formulation failure modes:

| # | Potential Formulation Flaw | Severity | Status | Audit Defense |
|---|---|:---:|:---:|---|
| **1** | **Reward / Objective Mismatch** | High | 🟢 **NO ISSUE** | $\mathcal{P}_{\text{ctrl}} \ne R_t^{\text{train}}$ explicitly formalized. $R_t^{\text{train}}$ is classified as an operational surrogate. |
| **2** | **Outage Gaming ($0 > \text{negative}$)** | Critical | 🟢 **NO ISSUE** | Resolved via operational outage penalty $-\bar{\lambda}_{\text{out}} \mathbb{1}[\text{feas}_t=0]$ and dual penalty $\mu_2$. |
| **3** | **Trust-Threshold Gaming ($\eta_t \to 1$)** | High | 🟢 **NO ISSUE** | Minimum cohort size $S_{\min}$ enforced; server validation loss $\mathcal{L}_{\text{val}}$ detects client drift. |
| **4** | **Double-Counted Energy** | Critical | 🟢 **NO ISSUE** | Energy $E_{\text{WPT}}$ appears exclusively in constraint cost $c_{1,t}$ and state $E_{\text{rem}}$, NOT as a reward penalty. |
| **5** | **Incorrect Lagrangian Sign** | Critical | 🟢 **NO ISSUE** | Formally verified: $\mathcal{L} = J - \sum \mu_i (G_i - b_i)$. Penalizes positive constraint violations. |
| **6** | **Discounted / Undiscounted Mismatch** | Critical | 🟢 **NO ISSUE** | Resolved via decomposed value functions ($Q^R$ discounted, $Q^{c_i}$ undiscounted/unit-discounted). |
| **7** | **Dual Update Inconsistency** | High | 🟢 **NO ISSUE** | Dual updates use undiscounted trajectory sums $\sum c_{i,t}$, matching the true physical constraints. |
| **8** | **Incorrect CMDP Interpretation** | High | 🟢 **NO ISSUE** | Conforms to canonical Altman (1999) saddle-point formulation with empirical subgradient ascent. |
| **9** | **Hard Secrecy Accidentally Softened** | Critical | 🟢 **NO ISSUE** | Condition $C9$ is an absolute constraint in micro-layer $\mathcal{Y}_t$. Zero secrecy terms in SAC reward. |
| **10** | **Reward Manipulation by Byzantine Attackers** | High | 🟢 **NO ISSUE** | Global loss $\mathcal{L}$ is evaluated on server validation set $\mathcal{D}_{\text{val}}$, not on client-reported losses. |
| **11** | **Unsupported Constraint Guarantees** | High | 🟢 **NO ISSUE** | Formally disclaimed. Evaluated empirically against tolerance thresholds. |
| **12** | **Hidden Reward Scaling Assumptions** | Medium | 🟢 **NO ISSUE** | Normalization scale $\sigma_{\mathcal{L}}$ explicitly documented as a Stage 3D.4 hyperparameter. |
| **13** | **Conflict with Stage 2D** | High | 🟢 **NO ISSUE** | $G_1(\pi), G_2(\pi)$, state transitions, and fallback behaviors match Stage 2D verbatim. |
| **14** | **Conflict with Stage 3D.1 SAC Equations** | High | 🟢 **NO ISSUE** | Actor loss $J_\pi(\phi)$ and double-Q critics expand identically with cost critics. |
| **15** | **Conflict with Stage 3D.2 Observation Design** | Medium | 🟢 **NO ISSUE** | Input dimensions ($2K+8$) and feature definitions match Stage 3D.2 specifications exactly. |

---

# SECTION O — FINAL GATE VERDICT

$$\boxed{\Huge\textbf{GREEN — STAGE 3D.3 PASSED}}$$

### Formal Gate Statement:

> **Stage 3D.3 is closed. The operational training reward, per-round constraint costs, decomposed value function architecture, and primal-dual Lagrangian dynamics are mathematically formalized, internally consistent, and rigorously insulated against reward gaming and secrecy softening. The project is cleared to proceed to Stage 3D.4 — Numerical Hyperparameters, Training Protocol & Algorithmic Stack Freeze.**

