# Stage 3D.1 — SAC Mathematical Formulation Audit

## Mathematical Derivation and Hostile Audit of the Soft Actor-Critic (SAC) Component for the Frozen Hybrid Control Architecture

---

# EXECUTIVE SUMMARY

This report constructs and audits the mathematical formulation of the **Soft Actor-Critic (SAC)** component for the primary algorithmic framework selected in Stage 3C/3C.1. 

SAC serves exclusively as the **macro-controller** for the continuous decision vector:
$$a_t = (\Delta x_t, \Delta y_t, \eta_t) \in \mathcal{A} = [-\delta_{\max}, \delta_{\max}]^2 \times [0, 1]$$

This audit strictly adheres to the frozen boundaries established in Stage 2D, Stage 3B.1, and Stage 3C.1:
1. **Physical recourse variables** ($v_t, E_{\mathrm{WPT},t}, T_t, p_k, b_k, f_k$) are handled exclusively by the micro-layer solver; they are NOT part of the SAC action space.
2. **Hard physical secrecy ($C9$)** is enforced by the micro-layer constraint set $\mathcal{Y}_t$, NOT by SAC reward penalties.
3. **The formal objective $\mathcal{P}_{\text{ctrl}}$** remains uncompromised; SAC optimizes an operational training surrogate reward denoted symbolically as $R_t^{\text{train}}$.
4. **No convergence or optimality theorems** are claimed. SAC is formulated as an empirical policy optimization method.

---

# SECTION A — FROZEN INPUTS INHERITED FROM STAGE 2D & 3B.1

The mathematical quantities inherited from the frozen formulation are:

1. **Pre-Action State $X_t^-$ (Markov State):**
   $$X_t^- = \bigl(r_{t-1},\; w_{t-1},\; \{\rho_{k,t-1}\}_{k=1}^K,\; \bar{h}_{t-1},\; n_{\text{out},t-1},\; E_{\text{rem},t-1},\; t\bigr)$$
   where $r_{t-1} \in \mathbb{R}^2$ is the UAV position, $w_{t-1} \in \mathbb{R}^d$ is the global FL model, $\rho_{k,t-1} \in [0, 1]$ are client reputation scores, $\bar{h}_{t-1} \in \mathbb{R}_+^K$ are effective legitimate channel gains, $n_{\text{out},t-1} \in \mathbb{N}$ is the cumulative outage count, $E_{\text{rem},t-1} \in \mathbb{R}_+$ is the remaining WPT energy budget, and $t \in \{1, \dots, T_{\max}\}$ is the round index.

2. **Operational Observation $o_t$:**
   $$o_t = \psi(X_t^-) = \bigl(r_{t-1},\; \phi(w_{t-1}),\; \{\rho_{k,t-1}\}_{k=1}^K,\; \bar{h}_{t-1},\; n_{\text{out},t-1},\; E_{\text{rem},t-1},\; t\bigr)$$
   where $\phi(w_{t-1}) \in \mathbb{R}^{d_\phi}$ is a low-dimensional summary of the FL model (e.g., loss, gradient norms).

3. **Macro Action $a_t$:**
   $$a_t = (\Delta x_t, \Delta y_t, \eta_t) \in \mathcal{A} = [-\delta_{\max}, \delta_{\max}]^2 \times [0, 1]$$
   - $(\Delta x_t, \Delta y_t)$ governs UAV spatial displacement: $r_t = \mathrm{Proj}_{\|r\| \le d}(r_{t-1} + (\Delta x_t, \Delta y_t))$.
   - $\eta_t \in [0, 1]$ sets the trust admission threshold: $\mathcal{S}_t^{\text{cand}} = \{k : \rho_{k,t-1} \ge \eta_t\}$.

4. **Physical Recourse Operator (Micro-Layer):**
   $$(r_t, \xi_t, \mathcal{S}_t^{\text{cand}}) \;\xrightarrow{\text{recourse}}\; \mathcal{Y}_t \;\xrightarrow{\text{solver}}\; (\text{feas}_t, y_t)$$
   where $y_t = (v_t, E_{\mathrm{WPT},t}, T_t, \{p_{k,t}, b_{k,t}, f_{k,t}\}_{k \in \mathcal{S}_t^{\text{cand}}})$ and $\xi_t$ is the small-scale channel fading realization revealed post-action.

5. **Formal Control Problem $\mathcal{P}_{\text{ctrl}}$:**
   $$\max_\pi \; J(\pi) = \mathbb{E}_\pi\left[\sum_{t=1}^{T_{\max}} \gamma^{t-1} \bigl(\mathcal{L}(w_{t-1}) - \mathcal{L}(w_t)\bigr) \cdot \mathbb{1}[\text{feas}_t = 1]\right]$$
   $$\text{s.t.} \quad G_1(\pi) = \mathbb{E}_\pi\left[\sum_{t=1}^{T_{\max}} E_{\mathrm{WPT},t} \cdot \mathbb{1}[\text{feas}_t = 1]\right] \le E_{\text{budget}}$$
   $$G_2(\pi) = \mathbb{E}_\pi\left[\frac{1}{T_{\max}} \sum_{t=1}^{T_{\max}} (1 - \text{feas}_t)\right] \le \epsilon_{\text{out}}$$

---

# SECTION B — FORMAL SAC OBJECTIVE

SAC optimizes an entropy-augmented discounted return. Let $\pi_\phi(a|o)$ denote a parameterized stochastic policy with parameter vector $\phi$.

### 1. Entropy Definition
For a continuous probability density $\pi_\phi(\cdot|o)$, the differential entropy is:
$$\mathcal{H}(\pi_\phi(\cdot|o)) \triangleq \mathbb{E}_{a \sim \pi_\phi(\cdot|o)}\left[-\log \pi_\phi(a|o)\right]$$

### 2. Maximum-Entropy Objective
Under operational training reward $R_t^{\text{train}}$, the formal SAC objective is:
$$J_{\text{SAC}}(\pi_\phi) = \sum_{t=1}^{T_{\max}} \mathbb{E}_{(o_t, a_t) \sim \rho_{\pi_\phi}}\left[\gamma^{t-1} \left(R_t^{\text{train}} + \alpha \mathcal{H}(\pi_\phi(\cdot|o_t))\right)\right]$$
where:
- $\gamma \in (0, 1)$ is the temporal discount factor.
- $\alpha > 0$ is the temperature parameter determining the relative importance of the entropy term against the reward.
- $\rho_{\pi_\phi}$ is the state-action marginal visitation distribution induced by policy $\pi_\phi$ under the environment transition kernel $P(\cdot|X_t^-, a_t)$ and observation mapping $\psi$.

### 3. Observable Process Classification
The underlying physical state $X_t^-$ is Markovian (under the Stage 2D modeling assumptions). However, because $o_t = \psi(X_t^-)$ lossily compresses $w_{t-1} \to \phi(w_{t-1})$, the observed sequence $(o_t, a_t)$ is strictly a **Partially Observable Markov Decision Process (POMDP)**. 
- In this mathematical specification, SAC is formulated over the observation $o_t$.
- Whether $o_t$ is consumed memorylessly ($\pi_\phi(a_t|o_t)$) or augmented with a finite observation history window $h_t = (o_{t-H+1}, \dots, o_t)$ is an architectural design decision deferred to Stage 3D.2.

---

# SECTION C — CONTINUOUS ACTION PARAMETERIZATION

The action space is compact and continuous:
$$\mathcal{A} = [-\delta_{\max}, \delta_{\max}] \times [-\delta_{\max}, \delta_{\max}] \times [0, 1]$$

### 1. Base Distribution & Reparameterization
The policy network outputs the parameters of an unconstrained 3-dimensional diagonal Gaussian distribution:
$$\mu_\phi(o_t) \in \mathbb{R}^3, \quad \sigma_\phi(o_t) \in \mathbb{R}_+^3$$
Let $\epsilon_t \sim \mathcal{N}(0, I_3)$ be an independent standard normal random vector. The unconstrained latent action $u_t = (u_{x,t}, u_{y,t}, u_{\eta,t})^T \in \mathbb{R}^3$ is generated via the reparameterization trick:
$$u_t = f_\phi(o_t, \epsilon_t) = \mu_\phi(o_t) + \sigma_\phi(o_t) \odot \epsilon_t$$

### 2. Squashing Transformation
To strictly enforce the compact action bounds without boundary truncation, we define the component-wise invertible mapping $g: \mathbb{R}^3 \to \mathcal{A}$ via hyperbolic tangent functions:
$$\begin{aligned}
\Delta x_t &= g_x(u_{x,t}) = \delta_{\max} \tanh(u_{x,t}) &\in [-\delta_{\max}, \delta_{\max}] \\
\Delta y_t &= g_y(u_{y,t}) = \delta_{\max} \tanh(u_{y,t}) &\in [-\delta_{\max}, \delta_{\max}] \\
\eta_t &= g_\eta(u_{\eta,t}) = \frac{1}{2}\left(\tanh(u_{\eta,t}) + 1\right) &\in [0, 1]
\end{aligned}$$
Thus, $a_t = g(u_t) \in \mathcal{A}$ is guaranteed feasible by construction.

### 3. Log-Probability Correction
Because $a_t = g(u_t)$ is a non-linear bijective transformation, the probability density $\pi_\phi(a_t|o_t)$ must be computed using the change-of-variables formula:
$$\pi_\phi(a_t|o_t) = \mu(u_t|o_t) \cdot \left| \det \left(\frac{\partial g(u_t)}{\partial u_t}\right) \right|^{-1}$$
Taking the natural logarithm:
$$\log \pi_\phi(a_t|o_t) = \log \mu(u_t|o_t) - \sum_{i \in \{x, y, \eta\}} \log \left| \frac{\partial g_i(u_{i,t})}{\partial u_{i,t}} \right|$$

Computing the partial derivatives:
$$\begin{aligned}
\frac{\partial g_x}{\partial u_{x,t}} &= \delta_{\max} \left(1 - \tanh^2(u_{x,t})\right) \\
\frac{\partial g_y}{\partial u_{y,t}} &= \delta_{\max} \left(1 - \tanh^2(u_{y,t})\right) \\
\frac{\partial g_\eta}{\partial u_{\eta,t}} &= \frac{1}{2} \left(1 - \tanh^2(u_{\eta,t})\right)
\end{aligned}$$

Substituting into the log-density expression:
$$\boxed{\log \pi_\phi(a_t|o_t) = \log \mu(u_t|o_t) - \sum_{i \in \{x, y\}} \left[\log \delta_{\max} + \log(1 - \tanh^2(u_{i,t}))\right] - \left[\log(0.5) + \log(1 - \tanh^2(u_{\eta,t}))\right]}$$
where $\log \mu(u_t|o_t) = -\frac{1}{2}\sum_{i=1}^3 \left[ \left(\frac{u_{i,t} - \mu_{\phi,i}(o_t)}{\sigma_{\phi,i}(o_t)}\right)^2 + 2\log \sigma_{\phi,i}(o_t) + \log(2\pi) \right]$.

*Numerical stability note:* To prevent $\log(0)$ as $\tanh(u) \to \pm 1$, the evaluation employs the standard numerical identity $\log(1 - \tanh^2(u)) = 2\left(\log 2 - u - \text{softplus}(-2u)\right)$ during computation.

---

# SECTION D — ACTOR OBJECTIVE

The policy parameter $\phi$ is trained to maximize expected future return plus entropy. Using the reparameterization trick $a_\phi(o, \epsilon) = g(\mu_\phi(o) + \sigma_\phi(o) \odot \epsilon)$, the actor loss function to be **minimized** is:

$$\boxed{J_\pi(\phi) = \mathbb{E}_{o \sim \mathcal{D},\; \epsilon \sim \mathcal{N}(0, I_3)}\left[\alpha \log \pi_\phi(a_\phi(o, \epsilon)|o) - \min_{j \in \{1, 2\}} Q_{\theta_j}\bigl(o,\; a_\phi(o, \epsilon)\bigr)\right]}$$

where:
- $\mathcal{D}$ is the experience replay buffer.
- $\min_{j \in \{1, 2\}} Q_{\theta_j}(o, a)$ represents the clipped double-Q estimator, which suppresses overestimation bias.
- Minimizing $J_\pi(\phi)$ directly maximizes the soft value function $V(o) = \mathbb{E}_{a \sim \pi}[Q(o, a) - \alpha \log \pi(a|o)]$.

---

# SECTION E — TWIN CRITIC OBJECTIVES & BELLMAN TARGET

To mitigate positive maximization bias during temporal-difference learning, SAC maintains two independent action-value critic networks parameterized by $\theta_1$ and $\theta_2$:
$$Q_{\theta_1}(o_t, a_t), \quad Q_{\theta_2}(o_t, a_t)$$
along with exponentially moving target networks parameterized by $\bar{\theta}_1$ and $\bar{\theta}_2$.

### 1. Target Value Formulation
For an observed transition $(o_t, a_t, R_t^{\text{train}}, o_{t+1}, d_t) \in \mathcal{D}$, the soft temporal-difference target $y_t$ is:
$$\boxed{y_t = R_t^{\text{train}} + \gamma (1 - d_t) \left(\min_{j \in \{1, 2\}} Q_{\bar{\theta}_j}(o_{t+1}, a_{t+1}) - \alpha \log \pi_\phi(a_{t+1}|o_{t+1})\right)}$$
where:
- $a_{t+1} \sim \pi_\phi(\cdot|o_{t+1})$ is sampled from the **current** policy network at the next observation $o_{t+1}$.
- $\log \pi_\phi(a_{t+1}|o_{t+1})$ is the squashed-Gaussian log-probability evaluated at $a_{t+1}$.
- $d_t \in \{0, 1\}$ is the episode termination indicator (see Section K).
- $\gamma \in (0, 1)$ is the discount factor.

### 2. Critic Loss Functions
Each critic network parameter $\theta_j$ ($j \in \{1, 2\}$) is trained by minimizing the mean squared Bellman error:
$$\boxed{J_Q(\theta_j) = \mathbb{E}_{(o_t, a_t, R_t^{\text{train}}, o_{t+1}, d_t) \sim \mathcal{D}}\left[\frac{1}{2}\left(Q_{\theta_j}(o_t, a_t) - y_t\right)^2\right]}$$

### 3. Target Network Polyak Updating
Target network parameters are updated softly after each gradient step:
$$\bar{\theta}_j \leftarrow \tau_Q \theta_j + (1 - \tau_Q) \bar{\theta}_j, \quad \forall j \in \{1, 2\}$$
with tracking rate $\tau_Q \in (0, 1)$.

---

# SECTION F — ENTROPY TEMPERATURE FORMULATION

The temperature parameter $\alpha$ scales the entropy incentive relative to the reward. We distinguish two formulations symbolically:

### Option 1: Fixed Temperature
$\alpha = \text{const} > 0$. The entropy weight remains constant throughout training.

### Option 2: Automatic Dual Entropy Tuning
To avoid manual tuning of $\alpha$ as reward scales evolve across training, $\alpha$ is treated as a dual variable for an entropy constraint $\mathbb{E}_{(o, a)}[-\log \pi(a|o)] \ge \bar{\mathcal{H}}$, where $\bar{\mathcal{H}} \in \mathbb{R}$ is the target minimum entropy.

The loss function for temperature optimization is:
$$\boxed{J(\alpha) = \mathbb{E}_{a \sim \pi_\phi(\cdot|o)}\left[-\alpha \log \pi_\phi(a|o) - \alpha \bar{\mathcal{H}}\right] = \mathbb{E}_{a \sim \pi_\phi(\cdot|o)}\left[-\alpha \left(\log \pi_\phi(a|o) + \bar{\mathcal{H}}\right)\right]}$$

- In practice, to guarantee $\alpha > 0$, we parameterize $\alpha = \exp(\beta)$ where $\beta \in \mathbb{R}$, optimizing:
  $$J(\beta) = \mathbb{E}_{a \sim \pi_\phi(\cdot|o)}\left[-\exp(\beta) \left(\log \pi_\phi(a|o) + \bar{\mathcal{H}}\right)\right]$$
- Standard heuristic baseline: $\bar{\mathcal{H}} = -\dim(\mathcal{A}) = -3.0$.
- *Scientific Disclaimer:* Automatic temperature tuning provides an adaptive scaling mechanism; it does **not** guarantee interior values for $\eta_t$, does not guarantee client diversity, and does not provide an asymptotic convergence proof.

---

# SECTION G — PHYSICAL RECOURSE INTERFACE

A defining feature of this research is that SAC does **not** solve the physical layer directly. The physical layer variables:
$$y_t = \bigl(v_t, E_{\mathrm{WPT},t}, T_t, \{p_{k,t}, b_{k,t}, f_{k,t}\}_{k \in \mathcal{S}_t^{\text{cand}}}\bigr)$$
are computed entirely downstream of SAC by the model-based recourse operator.

```text
┌──────────────────────────────────────────────────────────────────────────────────┐
│ SAC Macro Controller                                                             │
│ Input: Observation o_t                                                           │
│ Output: a_t = (Δx_t, Δy_t, η_t)                                                  │
└────────────────────────────────────────┬─────────────────────────────────────────┘
                                         │ Action commitment
                                         ▼
┌──────────────────────────────────────────────────────────────────────────────────┐
│ Kinematic & Admission Execution                                                  │
│ UAV position updated: r_t = Proj(r_{t-1} + (Δx_t, Δy_t))                         │
│ Candidate cohort filtered: S_t^cand = {k : ρ_{k,t-1} ≥ η_t}                      │
└────────────────────────────────────────┬─────────────────────────────────────────┘
                                         │ Channel fading revealed
                                         ▼
┌──────────────────────────────────────────────────────────────────────────────────┐
│ Post-Action Realization                                                          │
│ Small-scale channel realization: ξ_t ~ P_ξ(·)                                    │
│ Eve uncertainty bound: Δ_{E,k,t} = ε_{UE,k} + ε_{IE} ||h_{UI,k,t}||_2           │
└────────────────────────────────────────┬─────────────────────────────────────────┘
                                         │ Micro-layer invocation
                                         ▼
┌──────────────────────────────────────────────────────────────────────────────────┐
│ Model-Based Physical Recourse Layer (Iterative Optimization Solver)              │
│ Feasible set Y_t(r_t, ξ_t, S_t^cand) defined by C1~C7, C9                       │
│ - Secrecy condition C9 enforced strictly as a hard constraint                    │
│ Output: (feas_t, y_t)                                                            │
└────────────────────────────────────────┬─────────────────────────────────────────┘
                                         │ State transition & FL update
                                         ▼
┌──────────────────────────────────────────────────────────────────────────────────┐
│ Environment Transition                                                           │
│ If feas_t = 1: Execute WPT, local training, Byzantine attack, robust aggregation │
│ If feas_t = 0: Safe fallback (no RF transmission, no FL update)                 │
│ Next state X_{t+1}^- generated -> Transition pushed to Replay Buffer D           │
└──────────────────────────────────────────────────────────────────────────────────┘
```

**Key Boundary:** The actor network $\pi_\phi$ has zero direct gradient pathways to $y_t$. SAC perceives the micro-layer solver as an intrinsic, non-differentiable part of the environment transition function.

---

# SECTION H — FEASIBILITY & FALLBACK TRANSITION INTERFACE

The micro-layer recourse mapping yields three mutually exclusive outcomes for any tuple $(r_t, \xi_t, \mathcal{S}_t^{\text{cand}})$:

| Case | Outcome Name | Mathematical Condition | Physical Meaning | Operational Response | Recorded Transition |
|---|---|---|---|---|---|
| **Case A** | **Service Success** | $\mathcal{Y}_t \ne \emptyset$ AND solver finds $y_t \in \mathcal{Y}_t$ | Physical network can securely serve all candidates in $\mathcal{S}_t^{\text{cand}}$. | Execute WPT ($E_{\mathrm{WPT},t}$), local training, Byzantine attack, aggregation $\mathcal{G} \to w_t$, trust update $\to \rho_{k,t}$. | $\text{feas}_t = 1$, $c_{1,t} = E_{\mathrm{WPT},t}$, $c_{2,t} = 0$, $R_t^{\text{train}} = R_{\text{success}}$ |
| **Case B** | **Structural Infeasibility** | $\mathcal{Y}_t = \emptyset$ | No physically possible configuration satisfies $\widetilde{C1}$–$C9$ under realization $\xi_t$. | Safe fallback: Zero RF power, zero WPT, no local transmission, $w_t = w_{t-1}$, trust unchanged. | $\text{feas}_t = 0$, $c_{1,t} = 0$, $c_{2,t} = 1$, $R_t^{\text{train}} = R_{\text{outage}}$ |
| **Case C** | **Solver Failure** | $\mathcal{Y}_t \ne \emptyset$ BUT solver fails to find $y \in \mathcal{Y}_t$ | Nonconvex numerical solver failed to converge to feasible point. | Safe fallback: Identical to Case B to prevent uncertified transmission. | $\text{feas}_t = 0$, $c_{1,t} = 0$, $c_{2,t} = 1$, $R_t^{\text{train}} = R_{\text{outage}}$ |

### Diagnostic Distinguishability Note:
In the real-time simulation loop, the environment cannot rigorously certify whether a non-convergence outcome belongs to Case B or Case C (nonconvex feasibility is NP-hard). Operationally, both produce $\text{feas}_t = 0$ with identical safe fallback. The two cases are distinguished conceptually to prevent false claims of physical outage when solver algorithmic limits are the cause.

---

# SECTION I — PARTIAL OBSERVABILITY INTERFACE

In the Stage 2D state $X_t^-$, the true global FL model $w_{t-1} \in \mathbb{R}^d$ resides in a high-dimensional parameter space ($d \sim 10^4 - 10^7$). The observation $o_t$ compresses this model into $\phi(w_{t-1}) \in \mathbb{R}^{d_\phi}$ ($d_\phi \ll d$).

### Architectural Options for Policy Conditioning:

$$\begin{aligned}
\textbf{Option A (Memoryless Markov Policy):} & \quad \pi_\phi(a_t \mid o_t) \\
\textbf{Option B (Finite-History Frame Stacking):} & \quad \pi_\phi(a_t \mid h_t), \quad h_t = (o_{t-H+1}, \dots, o_t) \text{ for window } H \ge 2 \\
\textbf{Option C (Recurrent State Architecture):} & \quad \pi_\phi(a_t \mid s_t^{\text{RNN}}), \quad s_t^{\text{RNN}} = \text{RNN}(s_{t-1}^{\text{RNN}}, o_t)
\end{aligned}$$

- **Audit Finding:** The formal SAC equations in Sections B–E are fully mathematically valid under **any** of these three choices, simply by defining the policy conditioning variable as $s_t \in \{o_t, h_t, s_t^{\text{RNN}}\}$.
- **Decision:** The choice between Option A, B, or C is an **architectural neural design decision** and is intentionally deferred to Stage 3D.2.

---

# SECTION J — TERMINATION, HORIZON & DISCOUNTING

The FL process operates over a finite horizon of $T_{\max}$ federated learning rounds:
$$t \in \{1, 2, \dots, T_{\max}\}$$

### 1. Terminal Flag Definition
The termination indicator $d_t$ in the SAC Bellman target is defined as:
$$d_t = \begin{cases} 1, & \text{if } t = T_{\max} \\ 0, & \text{if } t < T_{\max} \end{cases}$$

### 2. Physical Outages Are NOT Episode Terminations
- If $\text{feas}_t = 0$ at round $t < T_{\max}$, the system executes safe fallback and advances to round $t+1$. 
- Therefore, $d_t = 0$ upon outage. Outages must **never** be flagged as terminal ($d_t = 1$), because premature termination would truncate Bellman backups and corrupt value estimation over the remaining FL rounds.

### 3. Bootstrap Truncation
When $t = T_{\max}$, $d_t = 1$. The temporal-difference target reduces to:
$$y_{T_{\max}} = R_{T_{\max}}^{\text{train}}$$
with zero future bootstrapping. For all $t < T_{\max}$, the discount factor $\gamma \in (0, 1)$ governs the horizon weighting.

---

# SECTION K — HOSTILE MATHEMATICAL AUDIT

The table below catalogs a hostile scrutiny across 13 potential failure modes:

| # | Potential Mathematical Flaw | Audit Severity | Status in Formulation | Detailed Finding & Defense |
|---|---|:---:|:---:|---|
| **1** | **Sign errors in actor/critic/temperature objectives** | High | 🟢 **NO ISSUE** | Verified. $J_\pi(\phi)$ minimizes $\alpha \log \pi - Q$ (maximizing $Q + \alpha \mathcal{H}$). Critic minimizes squared TD error. Temperature minimizes $-\alpha(\log \pi + \bar{\mathcal{H}})$. |
| **2** | **Inconsistent max/min conventions** | Medium | 🟢 **NO ISSUE** | All objectives are framed as minimization losses ($J_\pi, J_Q, J_\alpha$) to align with standard gradient descent optimization. |
| **3** | **Incorrect SAC Bellman target** | High | 🟢 **NO ISSUE** | Target $y_t = R + \gamma(1-d)(\min Q_{\bar{\theta}} - \alpha \log \pi)$ correctly subtracts $\alpha \log \pi$ (which adds positive entropy value since $\log \pi < 0$). Double-Q clipping applied. |
| **4** | **Incorrect squashed Gaussian log-prob correction** | High | 🟢 **NO ISSUE** | Exact Jacobian log-determinant derived in Section C. Explicitly handles separate bounding ranges for UAV displacement ($[-\delta_{\max}, \delta_{\max}]$) and trust threshold ($[0, 1]$). |
| **5** | **Confusion between $o_t$ and $X_t^-$** | Medium | 🟢 **NO ISSUE** | Delineated. $X_t^-$ is the Markovian environment state; $o_t = \psi(X_t^-)$ is the observable input to SAC networks. |
| **6** | **Hidden assumption of full observability** | High | 🟢 **NO ISSUE** | Explicitly flagged as a POMDP due to FL model compression $\phi(w_{t-1})$. Memoryless vs. history-augmented policy kept open as architectural decision. |
| **7** | **Incorrect treatment of terminal states** | High | 🟢 **NO ISSUE** | Terminal flag $d_t = 1$ strictly when $t = T_{\max}$. Service outages ($\text{feas}_t=0$) explicitly retain $d_t = 0$. |
| **8** | **Accidental inclusion of physical variables in $a_t$** | Critical | 🟢 **NO ISSUE** | $a_t$ is strictly 3-dimensional: $(\Delta x_t, \Delta y_t, \eta_t)$. Recourse vector $y_t$ is computed exclusively by the micro-layer solver. |
| **9** | **Accidental reward-based relaxation of secrecy** | Critical | 🟢 **NO ISSUE** | Robust secrecy ($C9$) is enforced strictly inside micro-layer feasible set $\mathcal{Y}_t$. No soft secrecy penalty in SAC reward. |
| **10** | **Incorrect handling of infeasible physical recourse** | High | 🟢 **NO ISSUE** | Three outcomes (success, structural infeasibility, solver failure) formalized. Both failure modes invoke safe fallback. |
| **11** | **Unjustified convergence claims** | High | 🟢 **NO ISSUE** | All convergence and global optimality claims are strictly disclaimed. Stated as an empirical optimization method. |
| **12** | **Accidental CMDP guarantees** | High | 🟢 **NO ISSUE** | No claim that SAC natively guarantees $G_1, G_2$. Lagrangian dual handling will be integrated in Stage 3D.3. |
| **13** | **Notation conflicts with Stage 2D / 3B.1** | Medium | 🟢 **NO ISSUE** | All symbols ($r_t, w_t, \rho_{k,t}, \bar{h}_t, n_{\text{out},t}, E_{\text{rem},t}, \xi_t, \mathcal{Y}_t$) match Stage 2D and Stage 3B.1 verbatim. |

---

# SECTION L — DEFERRED DECISIONS (CARRIED TO LATER STAGE 3D SUB-STAGES)

The following design decisions are **intentionally left open** and are NOT frozen in Stage 3D.1:

| Deferred Decision | Target Stage | Rationale for Deferral |
|---|:---:|---|
| **Exact Training Reward $R_t^{\text{train}}$ Formulation** | Stage 3D.3 | Requires formal alignment audit with $\mathcal{P}_{\text{ctrl}}$ and outage penalty calibration. |
| **Outage Penalty Magnitude ($\lambda_{\text{out}}$)** | Stage 3D.3 | Empirical tuning based on normalized reward scaling. |
| **Dual Variable Update Rules & Multipliers ($\mu_1, \mu_2$)** | Stage 3D.3 | Primal-dual Lagrangian formulation is separate from core SAC. |
| **Policy Neural Architecture (MLP vs. History vs. RNN)** | Stage 3D.2 | Specific layer dimensions, activations, and POMDP mitigations belong to network design. |
| **Replay Buffer Capacity & Batch Size** | Stage 3D.4 | Implementation parameter. |
| **Learning Rates ($\alpha_\theta, \alpha_\phi, \alpha_\mu, \tau_Q$)** | Stage 3D.4 | Hyperparameter specification. |
| **Fixed vs. Learned Temperature ($\alpha$)** | Stage 3D.2 | Both formulated symbolically; empirical choice deferred to architecture design. |
| **Client-Diversity Regularization Mechanism** | Stage 3D.3 | Addressed during reward and constraint formulation. |
| **Software Implementation (PyTorch/MATLAB)** | Stage 4 | Implementation occurs only after Stage 3D freeze. |

---

# SECTION M — FINAL GATE VERDICT

$$\boxed{\Huge\textbf{GREEN — STAGE 3D.1 PASSED}}$$

### Formal Gate Statement:

> **Stage 3D.1 is closed. The mathematical formulation of the Soft Actor-Critic (SAC) component is rigorously established, internally consistent with the frozen Stage 2D control problem, and completely free of unsupported optimality, convergence, or secrecy-relaxation claims. The project is cleared to proceed to Stage 3D.2 — Neural Network Architectures & Observation Interface.**

