# Stage 3A — Gate Report

## Verdict

$$\boxed{\textbf{GREEN — STAGE 3A PASSED}}$$

---

## Summary Statistics

| Metric | Value |
|---|---|
| Papers audited (across 9 categories) | ~45 distinct works |
| Literature categories searched | 9 (A through I) |
| Specific competitor papers analyzed | 4 named + ~8 additional close matches |
| Novelty claims evaluated | 5 (A through E) |
| RED claims (cannot make) | 1 (Claim A: "first DRL+IRS+FL") |
| GREEN claims (defensible) | 3 (Claims C, D, E) |
| YELLOW claims (borderline) | 1 (Claim B: "first secure DRL+IRS+FL") |

---

## 5 Closest Competitors

| Rank | Paper | What It Has | What It Lacks vs. Ours |
|---|---|---|---|
| 1 | Wu et al. (STAR-RIS AirFL + DRL, 2024) | UAV + RIS + FL + DRL | WPCN, PLS, imperfect CSI, robust secrecy, Byzantine, trust, model-based micro |
| 2 | Fan et al. (UAV Byzantine AirFL, 2024) | UAV + FL + Byzantine | IRS, WPCN, DRL, PLS, trust threshold |
| 3 | Li et al. (base paper, 2024) | UAV + IRS + WPCN + FL | DRL, PLS, imperfect CSI, Byzantine, cross-layer |
| 4 | IRS-PLS-FL (TVT, 2024) | IRS + FL + PLS | UAV, WPCN, DRL, imperfect CSI, robust secrecy, Byzantine |
| 5 | DRL Robust Secure IRS (TVT, 2024) | IRS + DRL + PLS + imperfect CSI | UAV, WPCN, FL, Byzantine, hard secrecy (uses reward) |

---

## Strongest Defensible Novelty Claim

**Claim E (combined A+B+C):**

> A cross-layer DRL framework that simultaneously couples FL learning progress and Byzantine trust dynamics with UAV mobility and IRS-assisted WPCN control, while enforcing robust worst-case physical-layer secrecy as a hard constraint through a model-based physical-layer recourse mechanism — not as a reward penalty.

**Why defensible:**
1. No paper combines all these dimensions.
2. The hard-constraint secrecy (via micro-layer) vs. reward-penalty distinction is a genuine methodological differentiator.
3. The cross-layer coupling (FL progress + trust → DRL → physical feasibility → FL update) is not found in any existing work.

---

## Weakest / Most Dangerous Novelty Claim

**Claim A: "First DRL-based UAV-IRS FL system"**

**Why dangerous:** Wu et al. (2024) already published DRL + UAV-mounted STAR-RIS + AirFL. Claiming "first" would be factually incorrect.

---

## Exact Research Gap

The gap is at the intersection of:
1. **Problem formulation:** Sequential constrained control with model-based physical recourse (not all-DRL).
2. **Security methodology:** Hard robust secrecy constraint under imperfect CSI enforced structurally, not via reward.
3. **Cross-layer architecture:** FL progress + Byzantine trust feedback into sequential DRL decisions.

---

## Reviewer-2/3 Vulnerability Assessment

| Concern | Status |
|---|---|
| AO convergence (old vulnerability) | ✅ Eliminated — no AO loop |
| Secrecy constraint enforcement | ✅ Preserved — hard C9 in micro-layer |
| DRL convergence (new vulnerability) | ⚠️ Manageable — use standard empirical methodology (multiple seeds, training curves) |
| Hyperparameter sensitivity (new) | ⚠️ Manageable — ablation + sensitivity analysis |
| Reproducibility (new) | ⚠️ Manageable — release code + seeds |

---

## Stage 3B Readiness

**YES — Stage 3B can begin.**

Stage 3B should address:
1. DRL algorithm selection (constrained RL method).
2. Neural network architecture design.
3. Training procedure specification.
4. Baseline selection.
5. Experimental design.

---

## Files Created

| File | Path |
|---|---|
| Literature Audit | `DRL_IRS_UAV/Stage_3A_Literature_Novelty_Audit/Stage_3A_Literature_Audit.md` |
| Gate Report | `DRL_IRS_UAV/Audit_Reports/Stage_3A_Gate_Report.md` |

